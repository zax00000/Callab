import request from 'supertest'
import app from '../app'
import { Business } from '../database/entity/business'
import { License } from '../database/entity/license'
import { Role } from '../database/entity/role'
import { User } from '../database/entity/user'
import { arrayEquals } from '../utils/arrayEquals'

describe('Business', () => {
  jest.setTimeout(30000)
  let newApp: any
  let server: any
  let db: any
  let email: any

  const newUser = {
    email: 'jesttest',
    password: 'tak123',
    firstName: 'John',
    surName: 'Alka',
  }

  const BusinessTest = {
    name: 'JestTest',
    nip: '123321',
    country: 'Test',
    zipCode: '31-232',
    city: 'Test',
    address1: 'Test',
    address2: 'Test',
    email: 'Test',
    phoneNumber: '1234123',
    contactName: 'Test',
    contactLastName: 'Test',
    license: 1,
  }

  const adminUser = {
    email: 'superadmin',
    password: 'Azaq1Dmi',
    firstName: 'admin',
    surName: 'admin',
  }
  let userID: any
  let accessToken: any
  let refreshToken: any
  let accessToken_user: any
  let refreshToken_user: any
  let businessId: any
  let businessId1: any
  let businessId2: any
  let roleId: any
  let licenseId: any
  let powersAppId: any

  beforeAll((done) => {
    const fu = async () => {
      const ret = await app()
      newApp = ret.app
      db = ret.db
      server = ret.server

      email = ret.sendMail
      done()
    }
    fu()
  })

  afterAll((done) => {
    const fu = async () => {
      await db.destroy()
      server.close()
      email.deleteSendMail()

      done()
    }
    fu()
  })

  test('Login user by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/login')
          .set('Content-type', 'application/json')
          .send(adminUser)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
            refreshToken: expect.any(String),
          })
        )

        accessToken = res.body.accessToken
        refreshToken = res.body.refreshToken
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Crate License by Admin', (done) => {
    const fu = async () => {
      const license = {
        startDate: '2022-11-29 10:36:42.425+01',
        endDate: '2023-11-29 10:36:42.425+01',
        maxUsersInBusiness: 10,
        maxUsersRooms: 10,
        name: 'jestTest',
      }
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/license/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send(license)
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            licenseId: expect.any(String),
          })
        )

        licenseId = res.body.licenseId

        const getLicense = await db
          .getRepository(License)
          .createQueryBuilder('license')
          .where('id = :id', { id: licenseId })
          .getOne()

        if (getLicense) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Crate business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ ...BusinessTest, licenseId: licenseId })
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            businessId: expect.any(String),
          })
        )

        businessId = res.body.businessId

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('id = :id', { id: businessId })
          .getOne()

        if (getBusiness) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Crate 2 business by Admin', (done) => {
    const fu = async () => {
      try {
        const res1: request.Response = await request(newApp)
          .post(`/private/business`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            ...BusinessTest,
            name: 'Business1JestTest',
            licenseId: licenseId,
          })
          .expect(200)
        expect(res1.body).toEqual(
          expect.objectContaining({
            status: 0,
            businessId: expect.any(String),
          })
        )
        const res2: request.Response = await request(newApp)
          .post(`/private/business`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            ...BusinessTest,
            name: 'Business2JestTest',
            licenseId: licenseId,
          })
          .expect(200)
        expect(res2.body).toEqual(
          expect.objectContaining({
            status: 0,
            businessId: expect.any(String),
          })
        )

        businessId1 = res1.body.businessId
        businessId2 = res2.body.businessId

        const getBusiness1 = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('id = :id', { id: businessId1 })
          .getOne()

        const getBusiness2 = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('id = :id', { id: businessId2 })
          .getOne()

        if (getBusiness1 && getBusiness2) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Crate business without name by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ ...BusinessTest, name: null, licenseId: licenseId })
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 5,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add PowersApp to business By Admin', (done) => {
    const fu = async () => {
      try {
        const resPowersApp: request.Response = await request(newApp)
          .get('/private/powers-app')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(resPowersApp.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        powersAppId = resPowersApp.body.powersApp.map((power: any) => {
          return power.id
        })
        const res: request.Response = await request(newApp)
          .post('/private/powers-app')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            businessId: businessId,
            powersApp: powersAppId,
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getPowersInBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.powersAppForBusiness', 'powersApp')
          .where('business.id = :id', { id: businessId })
          .getOne()
        if (
          arrayEquals(
            getPowersInBusiness.powersAppForBusiness.map(
              (powers: any) => powers.id
            ),
            powersAppId
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Create Role to business By Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/role')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            businessId: businessId,
            roleName: 'UserRoleJestTest',
            powersAppId,
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            roleId: expect.any(String),
          })
        )
        roleId = res.body.roleId

        const getRole = await db
          .getRepository(Role)
          .createQueryBuilder('role')
          .leftJoinAndSelect('role.business', 'business')
          .where('role.id = :id', { id: roleId })
          .getOne()
        if (getRole.business.id === businessId) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Create User by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/user/new')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ ...newUser, businessId, roleId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({ status: 0, userId: expect.any(String) })
        )
        userID = res.body.userId

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.users', 'user')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (getBusiness.users.some((user: User) => user.id === userID)) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Active user', (done) => {
    const fu = async () => {
      try {
        const getUser = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.id = :id', {
            id: userID,
          })
          .getOne()

        const res: request.Response = await request(newApp)
          .post('/active')
          .set('Content-type', 'application/json')
          .send({
            firstName: newUser.firstName,
            surName: newUser.surName,
            pass: newUser.password,
            active: getUser.activatingHash,
          })
          .expect(200)

        expect(res.body).toEqual(expect.objectContaining({ status: 0 }))

        const getUserActive = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.id = :id', {
            id: userID,
          })
          .getOne()

        if (getUserActive.isActivated) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all user from business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/users/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            userInBusiness: expect.any(Array),
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all user from business by Admin with wrong id', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/users/business/${userID}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 3,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all user from business by Admin with nod exist id', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/users/business/${123}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 6,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all user from business by Admin pagination', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/pagin/users/business/${businessId}/${0}/${1}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            userInBusiness: expect.any(Array),
            count: expect.any(Number),
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all user from business by Admin pagination search', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(
            `/private/pagin/users/business/${businessId}/${0}/${1}/search/${
              newUser.email
            }`
          )
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            userInBusiness: expect.any(Array),
            count: expect.any(Number),
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all user from business by Admin search', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/search/users/business/${businessId}/${'Jest'}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            userInBusiness: expect.any(Array),
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Remove User from business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/business/${businessId}/user/${userID}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(expect.objectContaining({ status: 0 }))
        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.users', 'user')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (!getBusiness.users.some((user: User) => user.id === userID)) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            nip: '12344',
            name: 'editTest',
            country: 'Pol',
            zipCode: '123-31',
            city: 'EditTest',
            address1: 'EditTest',
            address2: 'EditTest',
            email: 'EditTest',
            phoneNumber: '1234123233',
            contactName: 'EditTestName',
            contactLastName: 'EditTestLastName',
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )
        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (
          getBusiness.nip === '12344' &&
          getBusiness.name === 'editTest' &&
          getBusiness.country === 'Pol' &&
          getBusiness.zipCode === '123-31' &&
          getBusiness.city === 'EditTest' &&
          getBusiness.address1 === 'EditTest' &&
          getBusiness.address2 === 'EditTest' &&
          getBusiness.email === 'edittest' &&
          getBusiness.phoneNumber === '1234123233' &&
          getBusiness.contactName === 'EditTestName' &&
          getBusiness.contactLastName === 'EditTestLastName'
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add User for business by Admin with wrong UserId', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business/user/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            businessId: businessId,
            newUserId: 'd099814d-8868-476f-bf7a-3cd4b9d216b2',
            roleId,
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 3,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add User for business by Admin with wrong BusinessId', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business/user/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            businessId: 'd099814d-8868-476f-bf7a-3cd4b9d216b2',
            newUserId: userID,
            roleId,
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 3,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add User for business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business/user/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ businessId: businessId, newUserId: userID, roleId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )
        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.users', 'user')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (getBusiness.users.some((user: User) => user.id === userID)) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Login user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/login')
          .set('Content-type', 'application/json')
          .send({ email: newUser.email, password: newUser.password })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
            refreshToken: expect.any(String),
          })
        )

        accessToken_user = res.body.accessToken
        refreshToken_user = res.body.refreshToken
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get business for user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get('/private/user/business')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            userBusiness: expect.any(Object),
          })
        )
        if (
          res.body.userBusiness.business.some(
            (business: Business) => business.id === businessId
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get business admin pagination', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/pagin/business/0/10`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            business: expect.any(Array),
            count: expect.any(Number),
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get business admin pagination search', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/pagin/business/0/10/search/Jest`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            business: expect.any(Array),
            count: expect.any(Number),
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get business for admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get('/private/user/business')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            userBusiness: expect.any(Object),
          })
        )
        if (
          res.body.userBusiness.business.some(
            (business: Business) => business.id === businessId
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Select business for user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/business/user/select')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
          })
        )
        accessToken_user = res.body.accessToken
        const getUser = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.authentications', 'authentication')
          .leftJoinAndSelect('authentication.activeBusiness', 'business')
          .where('user.id = :id', { id: userID })
          .getOne()

        if (getUser.authentications[0].activeBusiness.id === businessId) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit business by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({
            nip: '12',
            name: 'editTest',
            country: 'Poll',
            zipCode: '133-31',
            city: 'EditTest2',
            address1: 'EditTest2',
            address2: 'EditTest2',
            phoneNumber: '1234123244',
            contactName: 'EditTestName12',
            contactLastName: 'EditTestLastName12',
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getBusiness = (await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.changes', 'changes')
          .where('business.id = :id', { id: businessId })
          .getOne()) as Business

        const changesToken = getBusiness.changes[0].changesToken
        const resAccept: request.Response = await request(newApp)
          .post(`/accept-business-changes`)
          .set('Content-type', 'application/json')
          .send({
            token: changesToken,
          })
          .expect(200)

        expect(resAccept.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getBusinessAccept = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (
          getBusinessAccept.nip === '12' &&
          getBusinessAccept.name === 'editTest' &&
          getBusinessAccept.country === 'Poll' &&
          getBusinessAccept.zipCode === '133-31' &&
          getBusinessAccept.city === 'EditTest2' &&
          getBusinessAccept.address1 === 'EditTest2' &&
          getBusinessAccept.address2 === 'EditTest2' &&
          getBusinessAccept.phoneNumber === '1234123244' &&
          getBusinessAccept.contactName === 'EditTestName12' &&
          getBusinessAccept.contactLastName === 'EditTestLastName12'
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const res1: request.Response = await request(newApp)
          .delete(`/private/business/${businessId1}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res1.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const res2: request.Response = await request(newApp)
          .delete(`/private/business/${businessId2}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res2.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('id = :id', { id: businessId })
          .getOne()
        const getBusiness1 = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('id = :id', { id: businessId })
          .getOne()
        const getBusiness2 = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('id = :id', { id: businessId })
          .getOne()
        if (!(getBusiness && getBusiness1 && getBusiness2)) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete User by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/user/${userID}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .send()
          .expect(200)

        expect(res.body).toEqual({ status: 0 })
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
  test('Delete license by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/license/${licenseId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .send()
          .expect(200)

        expect(res.body).toEqual({ status: 0 })
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
})
