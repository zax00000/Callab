import request from 'supertest'
import app from '../app'
import { Business } from '../database/entity/business'
import { Floors } from '../database/entity/floors'
import { License } from '../database/entity/license'
import { Role } from '../database/entity/role'
import { User } from '../database/entity/user'
import { arrayEquals } from '../utils/arrayEquals'

describe('Floor', () => {
  jest.setTimeout(30000)
  let newApp: any
  let server: any
  let db: any
  let email: any

  const newUser = {
    email: 'jesttest',
    password: 'tak123',
    firstName: 'John',
    surName: 'Alka',
  }

  const BusinessTest = {
    name: 'JestTest',
    nip: '123321',
    country: 'Test',
    zipCode: '31-232',
    city: 'Test',
    address1: 'Test',
    address2: 'Test',
    email: 'Test',
    phoneNumber: '1234123',
    contactName: 'Test',
    contactLastName: 'Test',
    license: 1,
  }

  const adminUser = {
    email: 'superAdmin',
    password: 'Azaq1Dmi',
    firstName: 'admin',
    surName: 'admin',
  }
  let userID: any
  let accessToken: any
  let refreshToken: any
  let accessToken_user: any
  let refreshToken_user: any
  let businessId: any
  let roleId: any
  let powersAppId: any
  let floorId: any
  let floorId2: any
  let licenseId: any
  let dateModified: any
  let dateCreated: any

  beforeAll((done) => {
    const fu = async () => {
      const ret = await app()
      newApp = ret.app
      db = ret.db
      server = ret.server

      email = ret.sendMail
      done()
    }
    fu()
  })

  afterAll((done) => {
    const fu = async () => {
      await db.destroy()
      server.close()
      email.deleteSendMail()

      done()
    }
    fu()
  })

  test('Login user by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/login')
          .set('Content-type', 'application/json')
          .send(adminUser)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
            refreshToken: expect.any(String),
          })
        )

        accessToken = res.body.accessToken
        refreshToken = res.body.refreshToken
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Crate License by Admin', (done) => {
    const fu = async () => {
      const license = {
        startDate: '2022-11-29 10:36:42.425+01',
        endDate: '2023-11-29 10:36:42.425+01',
        maxUsersInBusiness: 10,
        maxUsersRooms: 10,
        name: 'jestTest',
      }
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/license/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send(license)
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            licenseId: expect.any(String),
          })
        )

        licenseId = res.body.licenseId

        const getLicense = await db
          .getRepository(License)
          .createQueryBuilder('license')
          .where('id = :id', { id: licenseId })
          .getOne()

        if (getLicense) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Crate business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ ...BusinessTest, licenseId: licenseId })
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            businessId: expect.any(String),
          })
        )

        businessId = res.body.businessId

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('id = :id', { id: businessId })
          .getOne()

        if (getBusiness) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
  test('Create Role to business By Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/role')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ businessId: businessId, roleName: 'UserRoleJestTest' })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            roleId: expect.any(String),
          })
        )
        roleId = res.body.roleId

        const getRole = await db
          .getRepository(Role)
          .createQueryBuilder('role')
          .leftJoinAndSelect('role.business', 'business')
          .where('role.id = :id', { id: roleId })
          .getOne()
        if (getRole.business.id === businessId) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add Powers to business By Admin', (done) => {
    const fu = async () => {
      try {
        const resPowersApp: request.Response = await request(newApp)
          .get('/private/powers-app')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(resPowersApp.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        powersAppId = resPowersApp.body.powersApp.map((power: any) => {
          return power.id
        })
        const res: request.Response = await request(newApp)
          .post('/private/powers-app')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            businessId: businessId,
            powersApp: powersAppId,
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getPowersInBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.powersAppForBusiness', 'powersApp')
          .where('business.id = :id', { id: businessId })
          .getOne()
        if (
          arrayEquals(
            getPowersInBusiness.powersAppForBusiness.map(
              (powers: any) => powers.id
            ),
            powersAppId
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get Powers to business By Admin', (done) => {
    const fu = async () => {
      try {
        const resPowersApi: request.Response = await request(newApp)
          .get(`/private/powers-app/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(resPowersApi.body).toEqual(
          expect.objectContaining({
            status: 0,
            powersApp: expect.any(Array),
          })
        )

        const getPowersInBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.powersAppForBusiness', 'powersApp')
          .where('business.id = :id', { id: businessId })
          .getOne()
        if (
          arrayEquals(
            getPowersInBusiness.powersAppForBusiness.map(
              (powers: any) => powers.id
            ),
            powersAppId
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add Powers to role in business By Admin', (done) => {
    const fu = async () => {
      try {
        const resPowersApi: request.Response = await request(newApp)
          .post('/private/powers-app/role')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            businessId,
            powersAppId,
            roleId,
          })
          .expect(200)

        expect(resPowersApi.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getPowersInBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.roles', 'role')
          .leftJoinAndSelect('role.powersApp', 'powerApp')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (
          arrayEquals(
            getPowersInBusiness.roles
              .find((role: Role) => role.id === roleId)
              .powersApp.map((powers: any) => powers.id),
            powersAppId
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Create User by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/user/new')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ ...newUser, businessId, roleId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({ status: 0, userId: expect.any(String) })
        )
        userID = res.body.userId

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.users', 'user')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (getBusiness.users.some((user: User) => user.id === userID)) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Active user', (done) => {
    const fu = async () => {
      try {
        const getUser = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.id = :id', {
            id: userID,
          })
          .getOne()

        const res: request.Response = await request(newApp)
          .post('/active')
          .set('Content-type', 'application/json')
          .send({
            firstName: newUser.firstName,
            surName: newUser.surName,
            pass: newUser.password,
            active: getUser.activatingHash,
          })
          .expect(200)

        expect(res.body).toEqual(expect.objectContaining({ status: 0 }))

        const getUserActive = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.id = :id', {
            id: userID,
          })
          .getOne()

        if (getUserActive.isActivated) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Login user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/login')
          .set('Content-type', 'application/json')
          .send({ email: newUser.email, password: newUser.password })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
            refreshToken: expect.any(String),
          })
        )

        accessToken_user = res.body.accessToken
        refreshToken_user = res.body.refreshToken
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Select business for user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/business/user/select')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
          })
        )
        accessToken_user = res.body.accessToken
        const getUser = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.authentications', 'authentication')
          .leftJoinAndSelect('authentication.activeBusiness', 'business')
          .where('user.id = :id', { id: userID })
          .getOne()

        if (getUser.authentications[0].activeBusiness.id === businessId) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add floor to business by user with wrong properties', (done) => {
    const fu = async () => {
      try {
        const properties = 'ala'
        const res: request.Response = await request(newApp)
          .post('/private/floor/new')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessId, properties })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 4,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add floor to business by user', (done) => {
    const fu = async () => {
      try {
        const properties = [0, 0, 0, 0, 0, 0, 0, 0, 16]
        const res: request.Response = await request(newApp)
          .post('/private/floor/new')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessId, properties, width: 10 })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            floorId: expect.any(String),
          })
        )

        floorId = res.body.floorId

        const getFloor = await db
          .getRepository(Floors)
          .createQueryBuilder('floors')
          .leftJoinAndSelect('floors.business', 'business')
          .leftJoinAndSelect('floors.idUserCreated', 'user')
          .where('floors.id = :id', { id: floorId })
          .getOne()
        if (
          getFloor.business.id === businessId &&
          arrayEquals(getFloor.properties, properties) &&
          getFloor.idUserCreated.id === userID
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add floor to business by user 2', (done) => {
    const fu = async () => {
      try {
        const properties = [0, 0, 0, 0, 0, 0, 0, 0, 1]
        const res: request.Response = await request(newApp)
          .post('/private/floor/new')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessId, properties, width: 10 })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            floorId: expect.any(String),
          })
        )
        floorId2 = res.body.floorId
        const getFloor = await db
          .getRepository(Floors)
          .createQueryBuilder('floors')
          .leftJoinAndSelect('floors.business', 'business')
          .leftJoinAndSelect('floors.idUserCreated', 'user')
          .where('floors.id = :id', { id: res.body.floorId })
          .getOne()
        if (
          getFloor.business.id === businessId &&
          arrayEquals(getFloor.properties, properties) &&
          getFloor.idUserCreated.id === userID
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit floor to business by user', (done) => {
    const fu = async () => {
      try {
        const properties = [0, 0, 0, 0, 0, 0, 0, 0, 16, 12, 10]
        const res: request.Response = await request(newApp)
          .post(`/private/floor/${floorId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessId, properties, width: 20 })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            floorId: expect.any(String),
          })
        )

        floorId = res.body.floorId

        const getFloor = await db
          .getRepository(Floors)
          .createQueryBuilder('floors')
          .leftJoinAndSelect('floors.business', 'business')
          .leftJoinAndSelect('floors.idUserCreated', 'user')
          .where('floors.id = :id', { id: floorId })
          .getOne()

        if (
          getFloor.business.id === businessId &&
          arrayEquals(getFloor.properties, properties) &&
          getFloor.idUserCreated.id === userID
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get floor to business by user with wrong id', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/floor/${0}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 3,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get floor from business by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/floor/${floorId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            floor: {
              dateCreated: expect.any(String),
              dateModified: expect.any(String),
              id: expect.any(String),
              properties: expect.any(Array),
              rooms: expect.any(Array),
              floorNumber: 1,
              width: 20,
            },
          })
        )

        const floor = res.body.floor
        dateModified = res.body.floor.dateModified
        dateCreated = res.body.floor.dateCreated

        const getFloor = await db
          .getRepository(Floors)
          .createQueryBuilder('floors')
          .leftJoinAndSelect('floors.business', 'business')
          .leftJoinAndSelect('floors.idUserCreated', 'user')
          .where('floors.id = :id', { id: floorId })
          .getOne()

        if (
          arrayEquals(getFloor.properties, floor.properties) &&
          floorId === floor.id
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get floor from business with time by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/floor/${floorId}/time/${dateModified}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .send({ floorsId: [floorId, floorId2] })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 69,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get floor from business with no actual floor number time by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/floor/${floorId}/time/${dateCreated}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .send({ floorsId: [floorId] })

          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 70,
          })
        )
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get floor from business with time by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/floor/${floorId}/time/${dateCreated}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .send({ floorsId: [floorId, floorId2] })

          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            floor: {
              dateModified: expect.any(String),
              id: expect.any(String),
              properties: expect.any(Array),
              floorNumber: 1,
              width: 20,
            },
          })
        )

        const floor = res.body.floor

        const getFloor = await db
          .getRepository(Floors)
          .createQueryBuilder('floors')
          .leftJoinAndSelect('floors.business', 'business')
          .leftJoinAndSelect('floors.idUserCreated', 'user')
          .where('floors.id = :id', { id: floorId })
          .getOne()

        if (
          arrayEquals(getFloor.properties, floor.properties) &&
          floorId === floor.id
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all floors to business by admin with wong id', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/floor/business/0`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 3,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all floors to business by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/floor/business/0`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            floors: [
              {
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
                id: expect.any(String),
                floorNumber: 1,
                properties: expect.any(Array),
                width: 20,
              },
              {
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
                id: expect.any(String),
                floorNumber: 2,
                properties: expect.any(Array),
                width: 10,
              },
            ],
          })
        )

        const floors = res.body.floors

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.floors', 'floor')
          .where('business.id = :id', {
            id: businessId,
          })
          .getOne()

        if (
          getBusiness.floors.some(
            (floor: any) =>
              arrayEquals(floor.properties, floors[0].properties) &&
              floor.id === floors[0].id
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all floors to business pagination', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/pagin/floor/business/${businessId}/${0}/${1}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            floors: [
              {
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
                userCreated: expect.any(String),
                userModified: expect.any(String),
                id: expect.any(String),
                floorNumber: 1,
                properties: expect.any(Array),
                width: 20,
              },
            ],
            count: 2,
          })
        )

        const floors = res.body.floors

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.floors', 'floor')
          .where('business.id = :id', {
            id: businessId,
          })
          .getOne()

        if (
          getBusiness.floors.some(
            (floor: any) =>
              arrayEquals(floor.properties, floors[0].properties) &&
              floor.id === floors[0].id
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all floors to business pagination with wrong businessId', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/pagin/floor/business/${userID}/${0}/${1}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 3,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all floors to business pagination with not existing id', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/pagin/floor/business/${123}/${0}/${1}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 3,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete User by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/user/${userID}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .send()
          .expect(200)

        expect(res.body).toEqual({ status: 0 })
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Incorrect Delete floor to business by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/floor/${0}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 3,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete floor to business by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/floor/${floorId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getFloor = await db
          .getRepository(Floors)
          .createQueryBuilder('floors')
          .where('floors.id = :id', { id: floorId })
          .getOne()

        if (!getFloor) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
  test('Delete floor to business by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/floor/${floorId2}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getFloor = await db
          .getRepository(Floors)
          .createQueryBuilder('floors')
          .where('floors.id = :id', { id: floorId2 })
          .getOne()

        if (!getFloor) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete license by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/license/${licenseId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .send()
          .expect(200)

        expect(res.body).toEqual({ status: 0 })
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
})
