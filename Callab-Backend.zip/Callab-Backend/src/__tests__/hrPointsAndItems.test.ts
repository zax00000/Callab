import fs from 'fs'
import path from 'path'
import request from 'supertest'
import app from '../app'
import { Business } from '../database/entity/business'
import { Item } from '../database/entity/item'
import { License } from '../database/entity/license'
import { Role } from '../database/entity/role'
import { User } from '../database/entity/user'
import { arrayEquals } from '../utils/arrayEquals'

describe('hrPointsAndItems.test', () => {
  jest.setTimeout(30000)
  let newApp: any
  let server: any
  let db: any
  let email: any

  const newUser = {
    email: 'jesttest',
    password: 'tak123',
    firstName: 'John',
    surName: 'Alka',
  }

  const BusinessTest = {
    name: 'JestTest',
    nip: '123321',
    country: 'Test',
    zipCode: '31-232',
    city: 'Test',
    address1: 'Test',
    address2: 'Test',
    email: 'Test',
    phoneNumber: '1234123',
    contactName: 'Test',
    contactLastName: 'Test',
    license: 1,
  }

  const adminUser = {
    email: 'superadmin',
    password: 'Azaq1Dmi',
    firstName: 'admin',
    surName: 'admin',
  }
  let userID: any
  let accessToken: any
  let refreshToken: any
  let accessToken_user: any
  let refreshToken_user: any
  let businessId: any
  let roleId: any
  let licenseId: any
  let itemId: any
  let itemId2: any
  let itemId3: any
  let businessItemId: any
  let businessItemId2: any
  let businessItemId3: any
  let powersAppId: any
  let userItemId: any
  let userItemId3: any

  beforeAll((done) => {
    const fu = async () => {
      const ret = await app()
      newApp = ret.app
      db = ret.db
      server = ret.server

      email = ret.sendMail
      done()
    }
    fu()
  })

  afterAll((done) => {
    const fu = async () => {
      await db.destroy()
      server.close()
      email.deleteSendMail()
      const filePath = path.join(
        __dirname,
        '/../',
        'routes/private/item/static'
      )

      fs.rmSync(filePath, { recursive: true, force: true })

      done()
    }
    fu()
  })

  test('Login user by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/login')
          .set('Content-type', 'application/json')
          .send(adminUser)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
            refreshToken: expect.any(String),
          })
        )

        accessToken = res.body.accessToken
        refreshToken = res.body.refreshToken
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Crate License by Admin', (done) => {
    const fu = async () => {
      const license = {
        startDate: '2022-11-29 10:36:42.425+01',
        endDate: '2023-11-29 10:36:42.425+01',
        maxUsersInBusiness: 10,
        maxUsersRooms: 10,
        name: 'jestTest',
      }
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/license/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send(license)
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            licenseId: expect.any(String),
          })
        )

        licenseId = res.body.licenseId

        const getLicense = await db
          .getRepository(License)
          .createQueryBuilder('license')
          .where('id = :id', { id: licenseId })
          .getOne()

        if (getLicense) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Crate business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ ...BusinessTest, licenseId: licenseId })
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            businessId: expect.any(String),
          })
        )

        businessId = res.body.businessId

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('id = :id', { id: businessId })
          .getOne()

        if (getBusiness) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add PowersApp to business By Admin', (done) => {
    const fu = async () => {
      try {
        const resPowersApp: request.Response = await request(newApp)
          .get('/private/powers-app')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(resPowersApp.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        powersAppId = resPowersApp.body.powersApp.map((power: any) => {
          return power.id
        })
        const res: request.Response = await request(newApp)
          .post('/private/powers-app')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            businessId: businessId,
            powersApp: powersAppId,
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getPowersInBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.powersAppForBusiness', 'powersApp')
          .where('business.id = :id', { id: businessId })
          .getOne()
        if (
          arrayEquals(
            getPowersInBusiness.powersAppForBusiness.map(
              (powers: any) => powers.id
            ),
            powersAppId
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Create Role to business By Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/role')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            businessId: businessId,
            roleName: 'UserRoleJestTest',
            powersAppId,
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            roleId: expect.any(String),
          })
        )
        roleId = res.body.roleId

        const getRole = await db
          .getRepository(Role)
          .createQueryBuilder('role')
          .leftJoinAndSelect('role.business', 'business')
          .where('role.id = :id', { id: roleId })
          .getOne()
        if (getRole.business.id === businessId) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Create User by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/user/new')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ ...newUser, businessId, roleId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({ status: 0, userId: expect.any(String) })
        )
        userID = res.body.userId

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.users', 'user')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (getBusiness.users.some((user: User) => user.id === userID)) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Active user', (done) => {
    const fu = async () => {
      try {
        const getUser = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.id = :id', {
            id: userID,
          })
          .getOne()

        const res: request.Response = await request(newApp)
          .post('/active')
          .set('Content-type', 'application/json')
          .send({
            firstName: newUser.firstName,
            surName: newUser.surName,
            pass: newUser.password,
            active: getUser.activatingHash,
          })
          .expect(200)

        expect(res.body).toEqual(expect.objectContaining({ status: 0 }))

        const getUserActive = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.id = :id', {
            id: userID,
          })
          .getOne()

        if (getUserActive.isActivated) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Login user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/login')
          .set('Content-type', 'application/json')
          .send({ email: newUser.email, password: newUser.password })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
            refreshToken: expect.any(String),
          })
        )

        accessToken_user = res.body.accessToken
        refreshToken_user = res.body.refreshToken
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get business for user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get('/private/user/business')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            userBusiness: expect.any(Object),
          })
        )
        if (
          res.body.userBusiness.business.some(
            (business: Business) => business.id === businessId
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Select business for user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/business/user/select')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
          })
        )
        accessToken_user = res.body.accessToken
        const getUser = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.authentications', 'authentication')
          .leftJoinAndSelect('authentication.activeBusiness', 'business')
          .where('user.id = :id', { id: userID })
          .getOne()

        if (getUser.authentications[0].activeBusiness.id === businessId) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add hr-points to user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/hr-points/add')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ userId: userID, points: 20, businessId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )
        if (userData.hrPoints === 20) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add hr-points to users', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/hr-points/users/add')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ usersId: [userID], points: 50, businessId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )
        if (userData.hrPoints === 70) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add item', (done) => {
    const fu = async () => {
      try {
        const filePath = path.join(__dirname, 'testImage.png')
        const res: request.Response = await request(newApp)
          .post('/private/item/new')
          .set('Authorization', `Bearer ${accessToken}`)
          .type('form')
          .field('name', 'test')
          .field('type', 0)
          .field('defaultPrice', 10)
          .attach('itemPicture', filePath)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add item2', (done) => {
    const fu = async () => {
      try {
        const filePath = path.join(__dirname, 'testImage.png')
        const res: request.Response = await request(newApp)
          .post('/private/item/new')
          .set('Authorization', `Bearer ${accessToken}`)
          .type('form')
          .field('name', 'lest2')
          .field('type', 0)
          .field('defaultPrice', 10)
          .attach('itemPicture', filePath)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add item3', (done) => {
    const fu = async () => {
      try {
        const filePath = path.join(__dirname, 'testImage.png')
        const res: request.Response = await request(newApp)
          .post('/private/item/new')
          .set('Authorization', `Bearer ${accessToken}`)
          .type('form')
          .field('name', 'next2')
          .field('type', 0)
          .field('defaultPrice', 20)
          .attach('itemPicture', filePath)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get item with pagin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/pagin/items/${0}/${3}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            count: 3,
            items: [
              {
                id: expect.any(String),
                name: expect.any(String),
                pictureUrl: expect.any(String),
                type: expect.any(Number),
                defaultPrice: expect.any(Number),
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
              },
              {
                id: expect.any(String),
                name: expect.any(String),
                pictureUrl: expect.any(String),
                type: expect.any(Number),
                defaultPrice: expect.any(Number),
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
              },
              {
                id: expect.any(String),
                name: expect.any(String),
                pictureUrl: expect.any(String),
                type: expect.any(Number),
                defaultPrice: expect.any(Number),
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
              },
            ],
          })
        )

        itemId = res.body.items[0].id
        itemId2 = res.body.items[1].id
        itemId3 = res.body.items[2].id
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get item', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/item/${itemId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            item: {
              id: expect.any(String),
              name: expect.any(String),
              pictureUrl: expect.any(String),
              type: expect.any(Number),
              defaultPrice: expect.any(Number),
              dateCreated: expect.any(String),
              dateModified: expect.any(String),
            },
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get items', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/items`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            items: [
              {
                id: expect.any(String),
                name: expect.any(String),
                pictureUrl: expect.any(String),
                type: expect.any(Number),
                defaultPrice: expect.any(Number),
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
              },
              {
                id: expect.any(String),
                name: expect.any(String),
                pictureUrl: expect.any(String),
                type: expect.any(Number),
                defaultPrice: expect.any(Number),
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
              },
              {
                id: expect.any(String),
                name: expect.any(String),
                pictureUrl: expect.any(String),
                type: expect.any(Number),
                defaultPrice: expect.any(Number),
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
              },
            ],
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get item with pagin search', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/pagin/items/${0}/${1}/search/te`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            count: 1,
            items: [
              {
                id: expect.any(String),
                name: expect.any(String),
                pictureUrl: expect.any(String),
                type: expect.any(Number),
                defaultPrice: expect.any(Number),
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
              },
            ],
          })
        )

        if (res.body.items[0].name === 'test') {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add item to business', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business-item/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ itemId, businessId, canBeBought: false, price: 20 })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getBusinessWithItem = (await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.items', 'items')
          .leftJoinAndSelect('items.item', 'item')
          .where('item.id = :id', { id: itemId })
          .getOne()) as Business

        businessItemId = getBusinessWithItem.items[0].id

        if (
          getBusinessWithItem.items[0].item.id === itemId &&
          getBusinessWithItem.items[0].price === 20 &&
          getBusinessWithItem.items[0].canBeBought === false
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit item in business', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business-item/${businessItemId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ canBeBought: true })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getBusinessWithItem = (await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.items', 'items')
          .leftJoinAndSelect('items.item', 'item')
          .where('item.id = :id', { id: itemId })
          .getOne()) as Business

        if (
          getBusinessWithItem.items[0].item.id === itemId &&
          getBusinessWithItem.items[0].canBeBought === true
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit item in business', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business-items/edit`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({
            businessItems: [
              { businessItemId: businessItemId, canBeBought: false },
            ],
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getBusinessWithItem = (await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.items', 'items')
          .leftJoinAndSelect('items.item', 'item')
          .where('item.id = :id', { id: itemId })
          .getOne()) as Business

        if (
          getBusinessWithItem.items[0].item.id === itemId &&
          getBusinessWithItem.items[0].canBeBought === false
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit item in business by admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/admin/business-item/${businessItemId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ canBeBought: true, price: 10 })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getBusinessWithItem = (await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.items', 'items')
          .leftJoinAndSelect('items.item', 'item')
          .where('item.id = :id', { id: itemId })
          .getOne()) as Business

        if (
          getBusinessWithItem.items[0].item.id === itemId &&
          getBusinessWithItem.items[0].price === 10 &&
          getBusinessWithItem.items[0].canBeBought === true
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get items from business', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/business-items/${businessId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getBusinessWithItem = (await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.items', 'items')
          .leftJoinAndSelect('items.item', 'item')
          .where('item.id = :id', { id: itemId })
          .getOne()) as Business

        if (
          getBusinessWithItem.items[0].id === res.body.itemInBusiness[0].id &&
          getBusinessWithItem.items[0].price ===
            res.body.itemInBusiness[0].price &&
          getBusinessWithItem.items[0].canBeBought ===
            res.body.itemInBusiness[0].canBeBought
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get items from business pagin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/pagin/business-items/${businessId}/${0}/${1}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getBusinessWithItem = (await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.items', 'items')
          .leftJoinAndSelect('items.item', 'item')
          .where('item.id = :id', { id: itemId })
          .getOne()) as Business

        if (
          getBusinessWithItem.items[0].id === res.body.itemInBusiness[0].id &&
          getBusinessWithItem.items[0].price ===
            res.body.itemInBusiness[0].price &&
          getBusinessWithItem.items[0].canBeBought ===
            res.body.itemInBusiness[0].canBeBought
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add item to user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/user/item/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ businessItemId, businessId, userId: userID })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.items', 'items')
          .leftJoinAndSelect('items.businessItem', 'businessItem')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )

        if (userData.items[0].businessItem.id === businessItemId) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get businessItems from user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/user-items/user/${userID}/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.items', 'items')
          .leftJoinAndSelect('items.businessItem', 'businessItem')
          .leftJoinAndSelect('businessItem.item', 'item')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )
        userItemId = res.body.items[0].id
        if (
          userData.items[0].id === res.body.items[0].id &&
          userData.items[0].businessItem.item.name ===
            res.body.items[0].itemName &&
          userData.items[0].businessItem.item.pictureUrl ===
            res.body.items[0].itemPictureUrl &&
          userData.items[0].businessItem.item.type ===
            res.body.items[0].itemType
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Select businessItems for user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/select-item`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ userItemId, businessId, userId: userID })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.items', 'items')
          .leftJoinAndSelect('items.businessItem', 'businessItem')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )

        if (
          userData.items.filter((item) => item.selected)[0].businessItem.id ===
          businessItemId
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit userItem for user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/user-item/${userItemId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({
            itemPosX: 11,
            itemPosY: 12,
            itemScale: 4,
            selected: true,
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.items', 'items')
          .leftJoinAndSelect('items.businessItem', 'businessItem')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )
        const item = userData.items.filter((item) => item.selected)[0]
        if (
          item.businessItem.id === businessItemId &&
          item.posX === 11 &&
          item.posY === 12 &&
          item.scale === 4
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit userItems for user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/user-items/edit`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({
            items: [
              {
                itemId: userItemId,
                itemPosX: 10,
                itemPosY: 123,
                itemScale: 12,
                selected: true,
              },
            ],
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.items', 'items')
          .leftJoinAndSelect('items.businessItem', 'businessItem')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )
        const item = userData.items.filter((item) => item.selected)[0]
        if (
          item.businessItem.id === businessItemId &&
          item.posX === 10 &&
          item.posY === 123 &&
          item.scale === 12
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('get user selected item for user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(
            `/private/user-selected-item/user/${userID}/business/${businessId}`
          )
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            items: [
              {
                id: expect.any(String),
                itemName: expect.any(String),
                itemPictureUrl: expect.any(String),
                itemType: expect.any(Number),
                itemPosX: expect.any(Number),
                itemPosY: expect.any(Number),
                itemScale: expect.any(Number),
                selected: expect.any(Boolean),
              },
            ],
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.items', 'items')
          .leftJoinAndSelect('items.businessItem', 'businessItem')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )
        const item = userData.items.filter((item) => item.selected)[0]
        if (
          item.businessItem.id === businessItemId &&
          item.posX === 10 &&
          item.posY === 123 &&
          item.scale === 12
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all user from business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/users/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            userInBusiness: expect.any(Array),
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete businessItems from user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/business-item/${userItemId}/user/${userID}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.items', 'items')
          .leftJoinAndSelect('items.businessItem', 'businessItem')
          .leftJoinAndSelect('businessItem.item', 'item')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )

        if (userData.items == null || userData.items.length === 0) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Buy businessItems for user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/buy-item`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessItemsId: [businessItemId] })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.items', 'items')
          .leftJoinAndSelect('items.businessItem', 'businessItem')
          .leftJoinAndSelect('businessItem.item', 'item')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )

        userItemId = userData.items[0].id

        if (
          userData.items[0].businessItem.id === businessItemId &&
          userData.hrPoints === 70
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Buy businessItems for user again', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/buy-item`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessItemsId: [businessItemId] })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.items', 'items')
          .leftJoinAndSelect('items.businessItem', 'businessItem')
          .leftJoinAndSelect('businessItem.item', 'item')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )

        userItemId = userData.items[0].id
        if (
          userData.items[0].businessItem.id === businessItemId &&
          userData.hrPoints === 70
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Buy businessItems for user with no businessItemId', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/buy-item`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessItemsId: [] })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 4,
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.items', 'items')
          .leftJoinAndSelect('items.businessItem', 'businessItem')
          .leftJoinAndSelect('businessItem.item', 'item')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )

        userItemId = userData.items[0].id
        if (
          userData.items[0].businessItem.id === businessItemId &&
          userData.hrPoints === 70
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add item 2 to business', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business-item/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ itemId: itemId2, businessId, canBeBought: false, price: 10 })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getBusinessWithItem = (await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.items', 'items')
          .leftJoinAndSelect('items.item', 'item')
          .where('item.id = :id', { id: itemId2 })
          .getOne()) as Business

        businessItemId2 = getBusinessWithItem.items[0].id

        if (
          getBusinessWithItem.items[0].item.id === itemId2 &&
          getBusinessWithItem.items[0].price === 10 &&
          getBusinessWithItem.items[0].canBeBought === false
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add item2 to user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/user/item/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ businessItemId: businessItemId2, businessId, userId: userID })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.items', 'items')
          .leftJoinAndSelect('items.businessItem', 'businessItem')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )

        if (
          userData.items.some(
            (item) => item.businessItem.id === businessItemId2
          )
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add item 3 to business', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business-item/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ itemId: itemId3, businessId, canBeBought: false })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getBusinessWithItem = (await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.items', 'items')
          .leftJoinAndSelect('items.item', 'item')
          .where('item.id = :id', { id: itemId3 })
          .getOne()) as Business

        businessItemId3 = getBusinessWithItem.items[0].id

        if (
          getBusinessWithItem.items[0].item.id === itemId3 &&
          getBusinessWithItem.items[0].price === 20 &&
          getBusinessWithItem.items[0].canBeBought === false
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add item3 to user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/user/item/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ businessItemId: businessItemId3, businessId, userId: userID })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.items', 'items')
          .leftJoinAndSelect('items.businessItem', 'businessItem')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )
        const item = userData.items.find(
          (item) => item.businessItem.id === businessItemId3
        )
        if (item != null) {
          userItemId3 = item.id
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit userItems for user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/user-items/edit`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({
            items: [
              {
                itemId: userItemId3,
                itemPosX: 10,
                itemPosY: 123,
                itemScale: 12,
                selected: true,
              },
            ],
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.items', 'items')
          .leftJoinAndSelect('items.businessItem', 'businessItem')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )
        const item = userData.items.filter((item) => item.selected)[0]
        if (
          item.businessItem.id === businessItemId3 &&
          item.posX === 10 &&
          item.posY === 123 &&
          item.scale === 12
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all user from business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/users/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            userInBusiness: [
              {
                avatar: null,
                avatarDateModification: null,
                avatarImage: null,
                email: expect.any(String),
                firstName: expect.any(String),
                hrPoints: expect.any(Number),
                id: expect.any(String),
                isDeveloper: false,
                isLogged: false,
                roleId: expect.any(String),
                surName: expect.any(String),
              },
              {
                avatar: null,
                avatarDateModification: null,
                avatarImage: null,
                email: expect.any(String),
                firstName: expect.any(String),
                hrPoints: expect.any(Number),
                id: expect.any(String),
                isDeveloper: false,
                isLogged: true,
                items: [
                  {
                    businessItemId: expect.any(String),
                    id: expect.any(String),
                    itemName: expect.any(String),
                    itemPictureUrl: expect.any(String),
                    itemPosX: expect.any(Number),
                    itemPosY: expect.any(Number),
                    itemScale: expect.any(Number),
                    itemType: expect.any(Number),
                    selected: true,
                  },
                ],
                roleId: expect.any(String),
                surName: expect.any(String),
              },
            ],
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit item', (done) => {
    const fu = async () => {
      try {
        const filePath = path.join(__dirname, 'testImage2.png')
        const res: request.Response = await request(newApp)
          .post(`/private/item/${itemId3}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .type('form')
          .field('name', 'testre')
          .field('type', 1)
          .field('defaultPrice', 13)
          .attach('itemPicture', filePath)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getItem = (await db
          .getRepository(Item)
          .createQueryBuilder('item')
          .where('item.id = :id', { id: itemId3 })
          .getOne()) as Item
        if (
          getItem.name === 'testre' &&
          getItem.type === 1 &&
          getItem.pictureUrl.includes('testImage2') &&
          getItem.defaultPrice === 13
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit item with wrong id', (done) => {
    const fu = async () => {
      try {
        const filePath = path.join(__dirname, 'testImage2.png')
        const res: request.Response = await request(newApp)
          .post(`/private/item/${businessId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .type('form')
          .field('name', 'testre')
          .field('type', 1)
          .field('defaultPrice', 13)
          .attach('itemPicture', filePath)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 4,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit item with wrong image', (done) => {
    const fu = async () => {
      try {
        const filePath = path.join(__dirname, 'test.txt')
        const res: request.Response = await request(newApp)
          .post(`/private/item/${itemId3}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .type('form')
          .field('name', 'testre')
          .field('type', 1)
          .field('defaultPrice', 13)
          .attach('itemPicture', filePath)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete item2', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/item/${itemId2}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getItem = (await db
          .getRepository(Item)
          .createQueryBuilder('item')
          .where('item.id = :id', { id: itemId2 })
          .getOne()) as Item

        if (getItem == null) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete item3 form business', (done) => {
    const fu = async () => {
      try {
        const filePath = path.join(__dirname, 'testImage2.png')
        const res: request.Response = await request(newApp)
          .delete(`/private/business-item/${businessItemId3}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getBusinessWithItem = (await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.items', 'items')
          .leftJoinAndSelect('items.item', 'item')
          .where('business.id = :id', { id: businessId })
          .getOne()) as Business

        if (getBusinessWithItem.items.length === 1) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete item2', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/item/${itemId3}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getItem = (await db
          .getRepository(Item)
          .createQueryBuilder('item')
          .where('item.id = :id', { id: itemId3 })
          .getOne()) as Item

        if (getItem == null) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete businessItems from user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/business-item/${userItemId}/user/${userID}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getUser = (await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.items', 'items')
          .leftJoinAndSelect('items.businessItem', 'businessItem')
          .leftJoinAndSelect('businessItem.item', 'item')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', { id: userID })
          .getOne()) as User

        const userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )

        if (userData.items == null || userData.items.length === 0) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
  test('Delete item form business', (done) => {
    const fu = async () => {
      try {
        const filePath = path.join(__dirname, 'testImage2.png')
        const res: request.Response = await request(newApp)
          .delete(`/private/business-item/${businessItemId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getBusinessWithItem = (await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.items', 'items')
          .leftJoinAndSelect('items.item', 'item')
          .where('business.id = :id', { id: businessId })
          .getOne()) as Business

        if (
          getBusinessWithItem.items === null ||
          getBusinessWithItem.items.length === 0
        ) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete item', (done) => {
    const fu = async () => {
      try {
        const filePath = path.join(__dirname, 'testImage2.png')
        const res: request.Response = await request(newApp)
          .delete(`/private/item/${itemId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getItem = (await db
          .getRepository(Item)
          .createQueryBuilder('item')
          .where('item.id = :id', { id: itemId })
          .getOne()) as Item

        if (getItem == null) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('id = :id', { id: businessId })
          .getOne()

        if (!getBusiness) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete User by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/user/${userID}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .send()
          .expect(200)

        expect(res.body).toEqual({ status: 0 })
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
  test('Delete license by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/license/${licenseId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .send()
          .expect(200)

        expect(res.body).toEqual({ status: 0 })
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
})
