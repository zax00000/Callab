import request from 'supertest'
import app from '../app'
import { Interface } from '../database/entity/interface'
import { Languages } from '../database/entity/languages'

describe('Interface', () => {
  jest.setTimeout(30000)
  let newApp: any
  let server: any
  let db: any
  let email: any

  const adminUser = {
    email: 'superadmin',
    password: 'Azaq1Dmi',
    firstName: 'admin',
    surName: 'admin',
  }
  let accessToken: any
  let refreshToken: any
  let languagesId: any = []
  let interfacesId: any = []

  beforeAll((done) => {
    const fu = async () => {
      const ret = await app()
      newApp = ret.app
      db = ret.db
      server = ret.server

      email = ret.sendMail
      done()
    }
    fu()
  })

  afterAll((done) => {
    const fu = async () => {
      await db.destroy()
      server.close()
      email.deleteSendMail()

      done()
    }
    fu()
  })

  test('Login user by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/login')
          .set('Content-type', 'application/json')
          .send(adminUser)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
            refreshToken: expect.any(String),
          })
        )

        accessToken = res.body.accessToken
        refreshToken = res.body.refreshToken
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add Language', (done) => {
    const fu = async () => {
      try {
        const languages = [
          { name: 'Polski', active: true, languageCode: 'Polski' },
          { name: 'English', active: true, languageCode: 'English' },
        ]

        await Promise.all(
          languages.map(async (language: Languages) => {
            const res: request.Response = await request(newApp)
              .post('/private/language/new')
              .set('Authorization', `Bearer ${accessToken}`)
              .set('Content-type', 'application/json')
              .send(language)
              .expect(200)

            expect(res.body).toEqual(
              expect.objectContaining({
                status: 0,
                languageId: expect.any(String),
              })
            )
            languagesId.push(res.body.languageId)
          })
        )

        const getLanguages = await db
          .getRepository(Languages)
          .createQueryBuilder('language')
          .getMany()

        if (
          getLanguages.every((getLanguage: Languages) =>
            languagesId.some((language: any) => getLanguage.id === language)
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit Language', (done) => {
    const fu = async () => {
      try {
        const language = { name: 'Polskii', active: false }

        const res: request.Response = await request(newApp)
          .post(`/private/language/${languagesId[0]}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send(language)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            languageId: expect.any(String),
          })
        )

        const getLanguages = await db
          .getRepository(Languages)
          .createQueryBuilder('language')
          .where('language.id = :id', { id: languagesId[0] })
          .getOne()

        if (
          language.name === getLanguages.name &&
          language.active === getLanguages.active
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get Language', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/language/${languagesId[0]}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            language: {
              active: false,
              dateCreated: expect.any(String),
              dateModified: expect.any(String),
              id: expect.any(String),
              name: 'Polskii',
              languageCode: 'Polski',
            },
          })
        )

        const { language } = res.body
        const getLanguages = await db
          .getRepository(Languages)
          .createQueryBuilder('language')
          .where('language.id = :id', { id: languagesId[0] })
          .getOne()

        if (
          language.name === getLanguages.name &&
          language.active === getLanguages.active
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get Language pagination', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/pagin/language/0/1`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            languages: [
              {
                active: true,
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
                id: expect.any(String),
                name: expect.any(String),
                languageCode: expect.any(String),
              },
            ],
          })
        )

        const { languages } = res.body
        const getLanguages = await db
          .getRepository(Languages)
          .createQueryBuilder('language')
          .where('language.id = :id', { id: languagesId[1] })
          .getOne()

        if (
          languages[0].name === getLanguages.name &&
          languages[0].active === getLanguages.active
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get Language pagination search', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/pagin/language/0/1/search/Polski`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            count: expect.any(Number),
            languages: [
              {
                active: false,
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
                id: expect.any(String),
                name: expect.any(String),
                languageCode: expect.any(String),
              },
            ],
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all Languages', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/languages`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            languages: [
              {
                active: true,
                id: expect.any(String),
                name: expect.any(String),
                languageCode: expect.any(String),
              },
              {
                active: false,
                id: expect.any(String),
                name: expect.any(String),
                languageCode: expect.any(String),
              },
            ],
          })
        )
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add Interface', (done) => {
    const fu = async () => {
      try {
        const interfaces = [
          {
            name: 'testJest1_tak',
            translations: [
              {
                languageId: languagesId[0],
                translation: 'tak',
              },
              {
                languageId: languagesId[1],
                translation: 'yes',
              },
            ],
          },
          {
            name: 'testJest1_nie',
            translations: [
              {
                languageId: languagesId[0],
                translation: 'nie',
              },
              {
                languageId: languagesId[1],
                translation: 'no',
              },
            ],
          },
        ]

        await Promise.all(
          interfaces.map(async (oneInterface: any) => {
            const res: request.Response = await request(newApp)
              .post('/private/interface/new')
              .set('Authorization', `Bearer ${accessToken}`)
              .set('Content-type', 'application/json')
              .send(oneInterface)
              .expect(200)

            expect(res.body).toEqual(
              expect.objectContaining({
                status: 0,
                interfaceId: expect.any(String),
              })
            )
            interfacesId.push(res.body.interfaceId)
          })
        )

        const getInterfaces = await db
          .getRepository(Interface)
          .createQueryBuilder('interface')
          .getMany()

        if (
          getInterfaces.every((getInterface: any) =>
            interfacesId.some(
              (oneInterface: any) => getInterface.id === oneInterface
            )
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit Interface', (done) => {
    const fu = async () => {
      try {
        const interfaces = [
          {
            name: 'testJest1_tak',
            translations: [
              {
                languageId: languagesId[0],
                translation: 'taktest',
              },
              {
                languageId: languagesId[1],
                translation: 'yestest',
              },
            ],
          },
        ]

        await Promise.all(
          interfaces.map(async (oneInterface: any, index) => {
            const res: request.Response = await request(newApp)
              .post(`/private/interface/${interfacesId[index]}`)
              .set('Authorization', `Bearer ${accessToken}`)
              .set('Content-type', 'application/json')
              .send(oneInterface)
              .expect(200)

            expect(res.body).toEqual(
              expect.objectContaining({
                status: 0,
                interfaceId: expect.any(String),
              })
            )
          })
        )

        const getInterfaces = await db
          .getRepository(Interface)
          .createQueryBuilder('interface')
          .leftJoinAndSelect('interface.translation', 'translation')
          .where('interface.id = :id', { id: interfacesId[0] })
          .getOne()
        if (
          interfaces[0].translations[0].translation ===
          getInterfaces.translation[0].translation
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get Interface', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/interface/${'testJest1_tak'}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            interface: {
              dateCreated: expect.any(String),
              dateModified: expect.any(String),
              id: expect.any(String),
              name: 'testJest1_tak',
              translation: expect.any(Array),
            },
          })
        )

        if (
          res.body.interface.translation.every(
            ({ translation }: { translation: string }) =>
              ['yestest', 'taktest'].some((text) => text === translation)
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get Interfaces with language', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/interfaces/language/${languagesId[0]}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            interfaces: expect.any(Array),
          })
        )

        if (
          res.body.interfaces.every(
            ({ translationString }: { translationString: string }) =>
              ['nie', 'taktest'].some((text) => text === translationString)
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get Interfaces with language search pagination', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/search/interface/${'test'}/0/1`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            interfaces: expect.any(Array),
          })
        )
        if (
          res.body.interfaces.every(({ name }: { name: string }) =>
            ['testJest1_tak', 'testJest1_nie'].some((text) => text === name)
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get Interfaces with language pagination', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/pagin/interface/0/1`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            interfaces: expect.any(Array),
          })
        )

        if (
          res.body.interfaces.every(({ name }: { name: string }) =>
            ['testJest1_tak', 'testJest1_nie'].some((text) => text === name)
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get Interfaces with language translation', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/translation/interface/${interfacesId[0]}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            translations: expect.any(Array),
          })
        )

        if (
          res.body.translations.every(
            ({ translation }: { translation: string }) =>
              ['taktest', 'yestest'].some((text) => text === translation)
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete Interface', (done) => {
    const fu = async () => {
      try {
        await Promise.all(
          interfacesId.map(async (interfaceId: any) => {
            const res: request.Response = await request(newApp)
              .delete(`/private/interface/${interfaceId}`)
              .set('Authorization', `Bearer ${accessToken}`)
              .set('Content-type', 'application/json')
              .expect(200)

            expect(res.body).toEqual(
              expect.objectContaining({
                status: 0,
              })
            )
          })
        )

        const getInterfaces = await db
          .getRepository(Interface)
          .createQueryBuilder('interface')
          .getMany()

        if (getInterfaces.length === 0) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete Language', (done) => {
    const fu = async () => {
      try {
        await Promise.all(
          languagesId.map(async (languageId: Languages) => {
            const res: request.Response = await request(newApp)
              .delete(`/private/language/${languageId}`)
              .set('Authorization', `Bearer ${accessToken}`)
              .set('Content-type', 'application/json')
              .expect(200)

            expect(res.body).toEqual(
              expect.objectContaining({
                status: 0,
              })
            )
          })
        )

        const getLanguages = await db
          .getRepository(Languages)
          .createQueryBuilder('language')
          .getMany()

        if (getLanguages.length === 0) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
})
