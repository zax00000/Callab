import request from 'supertest'
import app from '../app'
import { Business } from '../database/entity/business'
import { License } from '../database/entity/license'
import { Role } from '../database/entity/role'
import { User } from '../database/entity/user'

describe('Business', () => {
  jest.setTimeout(30000)
  let newApp: any
  let server: any
  let db: any
  let email: any

  const newUser = {
    email: 'jesttest',
    password: 'tak123',
    firstName: 'John',
    surName: 'Alka',
  }

  const BusinessTest = {
    name: 'JestTest',
    nip: '123321',
    country: 'Test',
    zipCode: '31-232',
    city: 'Test',
    address1: 'Test',
    address2: 'Test',
    email: 'Test',
    phoneNumber: '1234123',
    contactName: 'Test',
    contactLastName: 'Test',
    license: 1,
  }

  const adminUser = {
    email: 'superAdmin',
    password: 'Azaq1Dmi',
    firstName: 'admin',
    surName: 'admin',
  }
  let userID: any
  let accessToken: any
  let refreshToken: any
  let accessToken_user: any
  let refreshToken_user: any
  let businessId: any
  let businessId1: any
  let businessId2: any
  let roleId: any
  let licenseId: any
  let licenseId2: any
  let usersID: any = []

  beforeAll((done) => {
    const fu = async () => {
      const ret = await app()
      newApp = ret.app
      db = ret.db
      server = ret.server

      email = ret.sendMail
      done()
    }
    fu()
  })

  afterAll((done) => {
    const fu = async () => {
      await db.destroy()
      server.close()
      email.deleteSendMail()

      done()
    }
    fu()
  })

  test('Login user by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/login')
          .set('Content-type', 'application/json')
          .send(adminUser)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
            refreshToken: expect.any(String),
          })
        )

        accessToken = res.body.accessToken
        refreshToken = res.body.refreshToken
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Crate License by Admin', (done) => {
    const fu = async () => {
      const license = {
        startDate: '2022-11-29 10:36:42.425+01',
        endDate: '2023-11-29 10:36:42.425+01',
        maxUsersInBusiness: 10,
        maxUsersRooms: 10,
        name: 'jestTest',
      }
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/license/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send(license)
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            licenseId: expect.any(String),
          })
        )

        licenseId = res.body.licenseId

        const getLicense = await db
          .getRepository(License)
          .createQueryBuilder('license')
          .where('id = :id', { id: licenseId })
          .getOne()

        if (getLicense) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Crate License by Admin with infinity end', (done) => {
    const fu = async () => {
      const license = {
        startDate: '2022-11-29 10:36:42.425+01',
        endDate: '',
        maxUsersInBusiness: 10,
        maxUsersRooms: 10,
        name: 'jestTest',
      }
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/license/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send(license)
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            licenseId: expect.any(String),
          })
        )

        licenseId2 = res.body.licenseId

        const getLicense = await db
          .getRepository(License)
          .createQueryBuilder('license')
          .where('id = :id', { id: licenseId2 })
          .getOne()

        if (getLicense) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get license with pagination by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/pagin/licenses/0/10`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            licenses: expect.any(Array),
            count: expect.any(Number),
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get license with pagination and search by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/pagin/licenses/0/10/search/jest`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            licenses: expect.any(Array),
            count: expect.any(Number),
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Crate business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ ...BusinessTest, licenseId: licenseId })
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            businessId: expect.any(String),
          })
        )

        businessId = res.body.businessId

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('id = :id', { id: businessId })
          .getOne()

        if (getBusiness) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Create Role to business By Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/role')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ businessId: businessId, roleName: 'UserRoleJestTest' })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            roleId: expect.any(String),
          })
        )
        roleId = res.body.roleId

        const getRole = await db
          .getRepository(Role)
          .createQueryBuilder('role')
          .leftJoinAndSelect('role.business', 'business')
          .where('role.id = :id', { id: roleId })
          .getOne()
        if (getRole.business.id === businessId) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Create User by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/user/new')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ ...newUser, businessId, roleId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            userId: expect.any(String),
          })
        )
        userID = res.body.userId

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.users', 'user')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (getBusiness.users.some((user: User) => user.id === userID)) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Create Users by Admin', (done) => {
    const fu = async () => {
      try {
        for (let i = 0; i < 9; i++) {
          const res: request.Response = await request(newApp)
            .post('/private/user/new')
            .set('Authorization', `Bearer ${accessToken}`)
            .set('Content-type', 'application/json')
            .send({ ...newUser, email: newUser.email + i, businessId, roleId })
            .expect(200)

          if (i === 8) {
            expect(res.body).toEqual(
              expect.objectContaining({
                status: 7,
              })
            )
          } else {
            expect(res.body).toEqual(
              expect.objectContaining({
                status: 0,
                userId: expect.any(String),
              })
            )
            usersID.push(res.body.userId)
          }
        }

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Active user', (done) => {
    const fu = async () => {
      try {
        const getUser = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.id = :id', {
            id: userID,
          })
          .getOne()

        const res: request.Response = await request(newApp)
          .post('/active')
          .set('Content-type', 'application/json')
          .send({
            firstName: newUser.firstName,
            surName: newUser.surName,
            pass: newUser.password,
            active: getUser.activatingHash,
          })
          .expect(200)

        expect(res.body).toEqual(expect.objectContaining({ status: 0 }))

        const getUserActive = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.id = :id', {
            id: userID,
          })
          .getOne()

        if (getUserActive.isActivated) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit License by Admin to no active', (done) => {
    const fu = async () => {
      const license = {
        startDate: '2022-11-28 10:36:42.425+01',
        endDate: '2022-11-29 10:36:42.425+01',
        maxUsersInBusiness: 10,
        maxUsersRooms: 10,
      }
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/license/${licenseId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send(license)
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            licenseId: expect.any(String),
          })
        )

        const getLicense = (await db
          .getRepository(License)
          .createQueryBuilder('license')
          .where('id = :id', { id: licenseId })
          .getOne()) as License

        if (
          new Date(getLicense.endDate).getTime() ===
          new Date(license.endDate).getTime()
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add User for business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business/user/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ businessId: businessId, newUserId: userID, roleId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 7,
          })
        )
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Login user with no active license', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/login')
          .set('Content-type', 'application/json')
          .send({ email: newUser.email, password: newUser.password })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
            refreshToken: expect.any(String),
          })
        )

        accessToken_user = res.body.accessToken
        refreshToken_user = res.body.refreshToken
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
  test('Select business for user with no active license', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/business/user/select')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 7,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit License by Admin to active', (done) => {
    const fu = async () => {
      const license = {
        startDate: '2022-11-29 10:36:42.425+01',
        endDate: '2023-11-29 10:36:42.425+01',
        maxUsersInBusiness: 10,
        maxUsersRooms: 10,
      }
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/license/${licenseId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send(license)
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            licenseId: expect.any(String),
          })
        )

        const getLicense = (await db
          .getRepository(License)
          .createQueryBuilder('license')
          .where('id = :id', { id: licenseId })
          .getOne()) as License

        if (
          new Date(getLicense.endDate).getTime() ===
          new Date(license.endDate).getTime()
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit License by Admin to infinity length', (done) => {
    const fu = async () => {
      const license = {
        startDate: '2022-11-29 10:36:42.425+01',
        endDate: '' as any,
        maxUsersInBusiness: 10,
        maxUsersRooms: 10,
      }
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/license/${licenseId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send(license)
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            licenseId: expect.any(String),
          })
        )

        const getLicense = (await db
          .getRepository(License)
          .createQueryBuilder('license')
          .where('id = :id', { id: licenseId })
          .getOne()) as License

        if (getLicense.endDate === null) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get License', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/license/${licenseId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            license: expect.any(Object),
          })
        )

        const license = res.body.license
        const getLicense = (await db
          .getRepository(License)
          .createQueryBuilder('license')
          .where('id = :id', { id: licenseId })
          .getOne()) as License

        if (
          new Date(getLicense.endDate).getTime() ===
            new Date(license.endDate).getTime() &&
          getLicense.maxUsersInBusiness === license.maxUsersInBusiness &&
          getLicense.maxUsersRooms === license.maxUsersRooms &&
          new Date(getLicense.dateCreated).getTime() ===
            new Date(license.dateCreated).getTime() &&
          new Date(getLicense.dateModified).getTime() ===
            new Date(license.dateModified).getTime()
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get License for Business', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/license/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            license: expect.any(Object),
          })
        )

        const license = res.body.license
        const getLicense = (await db
          .getRepository(License)
          .createQueryBuilder('license')
          .where('id = :id', { id: licenseId })
          .getOne()) as License

        if (
          new Date(getLicense.endDate).getTime() ===
            new Date(license.endDate).getTime() &&
          getLicense.maxUsersInBusiness === license.maxUsersInBusiness &&
          getLicense.maxUsersRooms === license.maxUsersRooms &&
          new Date(getLicense.dateCreated).getTime() ===
            new Date(license.dateCreated).getTime() &&
          new Date(getLicense.dateModified).getTime() ===
            new Date(license.dateModified).getTime()
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all License', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/licenses`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            licenses: expect.any(Array),
          })
        )

        const licenses = res.body.licenses as any[]
        const getLicense = (await db
          .getRepository(License)
          .createQueryBuilder('license')
          .where('id = :id', { id: licenseId })
          .getOne()) as License

        if (
          licenses.some(
            (license) =>
              new Date(getLicense.endDate).getTime() ===
                new Date(license.endDate).getTime() &&
              getLicense.maxUsersInBusiness === license.maxUsersInBusiness &&
              getLicense.maxUsersRooms === license.maxUsersRooms &&
              new Date(getLicense.dateCreated).getTime() ===
                new Date(license.dateCreated).getTime() &&
              new Date(getLicense.dateModified).getTime() ===
                new Date(license.dateModified).getTime()
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all user from business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/users/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            userInBusiness: expect.any(Array),
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Remove User from business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/business/${businessId}/user/${userID}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(expect.objectContaining({ status: 0 }))
        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.users', 'user')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (!getBusiness.users.some((user: User) => user.id === userID)) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            nip: '12344',
            name: 'editTest',
            country: 'Pol',
            zipCode: '123-31',
            city: 'EditTest',
            address1: 'EditTest',
            address2: 'EditTest',
            email: 'EditTest',
            phoneNumber: '1234123233',
            contactName: 'EditTestName',
            contactLastName: 'EditTestLastName',
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )
        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (
          getBusiness.nip === '12344' &&
          getBusiness.name === 'editTest' &&
          getBusiness.country === 'Pol' &&
          getBusiness.zipCode === '123-31' &&
          getBusiness.city === 'EditTest' &&
          getBusiness.address1 === 'EditTest' &&
          getBusiness.address2 === 'EditTest' &&
          getBusiness.email === 'edittest' &&
          getBusiness.phoneNumber === '1234123233' &&
          getBusiness.contactName === 'EditTestName' &&
          getBusiness.contactLastName === 'EditTestLastName'
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add User for business by Admin with wrong UserId', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business/user/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            businessId: businessId,
            newUserId: 'd099814d-8868-476f-bf7a-3cd4b9d216b2',
            roleId,
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 3,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add User for business by Admin with wrong BusinessId', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business/user/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            businessId: 'd099814d-8868-476f-bf7a-3cd4b9d216b2',
            newUserId: userID,
            roleId,
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 3,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add User for business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business/user/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ businessId: businessId, newUserId: userID, roleId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )
        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.users', 'user')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (getBusiness.users.some((user: User) => user.id === userID)) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Login user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/login')
          .set('Content-type', 'application/json')
          .send({ email: newUser.email, password: newUser.password })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
            refreshToken: expect.any(String),
          })
        )

        accessToken_user = res.body.accessToken
        refreshToken_user = res.body.refreshToken
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get business for user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get('/private/user/business')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            userBusiness: expect.any(Object),
          })
        )
        if (
          res.body.userBusiness.business.some(
            (business: Business) => business.id === businessId
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Select business for user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/business/user/select')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
          })
        )
        accessToken_user = res.body.accessToken
        const getUser = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.authentications', 'authentication')
          .leftJoinAndSelect('authentication.activeBusiness', 'business')
          .where('user.id = :id', { id: userID })
          .getOne()
        if (
          getUser.authentications.some(
            (authentication: any) =>
              authentication &&
              authentication.activeBusiness &&
              authentication.activeBusiness.id === businessId
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('id = :id', { id: businessId })
          .getOne()
        if (!getBusiness) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete User by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/user/${userID}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .send()
          .expect(200)

        expect(res.body).toEqual({ status: 0 })
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete Users by Admin', (done) => {
    const fu = async () => {
      try {
        const ret = usersID.map(async (userId: String) => {
          const res: request.Response = await request(newApp)
            .delete(`/private/user/${userId}`)
            .set('Authorization', `Bearer ${accessToken}`)
            .send()
            .expect(200)

          expect(res.body).toEqual({ status: 0 })
        })
        await Promise.all(ret)
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete license by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/license/${licenseId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .send()
          .expect(200)

        expect(res.body).toEqual({ status: 0 })
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete license2 by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/license/${licenseId2}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .send()
          .expect(200)

        expect(res.body).toEqual({ status: 0 })
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
})
