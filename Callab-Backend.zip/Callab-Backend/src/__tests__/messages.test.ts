import request from 'supertest'
import app from '../app'
import { Business } from '../database/entity/business'
import { Floors } from '../database/entity/floors'
import { License } from '../database/entity/license'
import { Messages } from '../database/entity/messages'
import { Role } from '../database/entity/role'
import { Rooms } from '../database/entity/rooms'
import { RoomsMembers } from '../database/entity/roomsMembers'
import { RoomsTypes } from '../database/entity/roomsTypes'
import { TemporaryUser } from '../database/entity/temporaryUser'
import { User } from '../database/entity/user'
import { arrayEquals } from '../utils/arrayEquals'

describe('messages', () => {
  jest.setTimeout(30000)
  let newApp: any
  let server: any
  let db: any
  let email: any

  const newUser = {
    email: 'jesttest1',
    password: 'tak123',
    firstName: 'John',
    surName: 'Alka',
  }

  const newUser1 = {
    email: 'jesttest2',
    password: 'tak123',
    firstName: 'John',
    surName: 'Alka',
  }
  const newUser2 = {
    email: 'jesttest3',
    password: 'tak123',
    firstName: 'John',
    surName: 'Alka',
  }

  const BusinessTest = {
    name: 'JestTest',
    nip: '123321',
    country: 'Test',
    zipCode: '31-232',
    city: 'Test',
    address1: 'Test',
    address2: 'Test',
    email: 'Test',
    phoneNumber: '1234123',
    contactName: 'Test',
    contactLastName: 'Test',
    license: 1,
  }

  let messageId: string

  const adminUser = {
    email: 'superAdmin',
    password: 'Azaq1Dmi',
    firstName: 'admin',
    surName: 'admin',
  }
  let userID: any
  let userID1: any
  let userID2: any
  let accessToken: any
  let refreshToken: any
  let accessToken_user: any
  let refreshToken_user: any
  let businessId: any
  let roleId: any
  let powersAppId: any
  let floorId: any
  let roomTypeId: any
  let roomId: any
  let roomMembersId: any
  let licenseId: any

  let meetingLink: string

  beforeAll((done) => {
    const fu = async () => {
      const ret = await app()
      newApp = ret.app
      db = ret.db
      server = ret.server

      email = ret.sendMail
      done()
    }
    fu()
  })

  afterAll((done) => {
    const fu = async () => {
      await db.getRepository(Messages).clear()
      await db.destroy()
      server.close()
      email.deleteSendMail()
      done()
    }
    fu()
  })

  test('Login user by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/login')
          .set('Content-type', 'application/json')
          .send(adminUser)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
            refreshToken: expect.any(String),
          })
        )

        accessToken = res.body.accessToken
        refreshToken = res.body.refreshToken
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Crate License by Admin', (done) => {
    const fu = async () => {
      const license = {
        startDate: '2022-11-29 10:36:42.425+01',
        endDate: '2023-11-29 10:36:42.425+01',
        maxUsersInBusiness: 10,
        maxUsersRooms: 10,
        name: 'jestTest',
      }
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/license/new`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send(license)
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            licenseId: expect.any(String),
          })
        )

        licenseId = res.body.licenseId

        const getLicense = await db
          .getRepository(License)
          .createQueryBuilder('license')
          .where('id = :id', { id: licenseId })
          .getOne()

        if (getLicense) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Crate business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/business`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ ...BusinessTest, licenseId: licenseId })
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            businessId: expect.any(String),
          })
        )

        businessId = res.body.businessId

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('id = :id', { id: businessId })
          .getOne()

        if (getBusiness) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Create Role to business By Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/role')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ businessId: businessId, roleName: 'UserRoleJestTest' })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            roleId: expect.any(String),
          })
        )
        roleId = res.body.roleId

        const getRole = await db
          .getRepository(Role)
          .createQueryBuilder('role')
          .leftJoinAndSelect('role.business', 'business')
          .where('role.id = :id', { id: roleId })
          .getOne()
        if (getRole.business.id === businessId) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add Powers to business By Admin', (done) => {
    const fu = async () => {
      try {
        const resPowersApp: request.Response = await request(newApp)
          .get('/private/powers-app')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(resPowersApp.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        powersAppId = resPowersApp.body.powersApp.map((power: any) => {
          return power.id
        })
        const res: request.Response = await request(newApp)
          .post('/private/powers-app')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            businessId: businessId,
            powersApp: powersAppId,
          })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getPowersInBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.powersAppForBusiness', 'powersApp')
          .where('business.id = :id', { id: businessId })
          .getOne()
        if (
          arrayEquals(
            getPowersInBusiness.powersAppForBusiness.map(
              (powers: any) => powers.id
            ),
            powersAppId
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get Powers to business By Admin', (done) => {
    const fu = async () => {
      try {
        const resPowersApi: request.Response = await request(newApp)
          .get(`/private/powers-app/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(resPowersApi.body).toEqual(
          expect.objectContaining({
            status: 0,
            powersApp: expect.any(Array),
          })
        )

        const getPowersInBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.powersAppForBusiness', 'powersApp')
          .where('business.id = :id', { id: businessId })
          .getOne()
        if (
          arrayEquals(
            getPowersInBusiness.powersAppForBusiness.map(
              (powers: any) => powers.id
            ),
            powersAppId
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add Powers to role in business By Admin', (done) => {
    const fu = async () => {
      try {
        const resPowersApi: request.Response = await request(newApp)
          .post('/private/powers-app/role')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({
            businessId,
            powersAppId,
            roleId,
          })
          .expect(200)

        expect(resPowersApi.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getPowersInBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.roles', 'role')
          .leftJoinAndSelect('role.powersApp', 'powerApp')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (
          arrayEquals(
            getPowersInBusiness.roles
              .find((role: Role) => role.id === roleId)
              .powersApp.map((powers: any) => powers.id),
            powersAppId
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Create User by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/user/new')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ ...newUser, businessId, roleId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({ status: 0, userId: expect.any(String) })
        )
        userID = res.body.userId

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.users', 'user')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (getBusiness.users.some((user: User) => user.id === userID)) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Create User2 by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/user/new')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ ...newUser1, businessId, roleId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({ status: 0, userId: expect.any(String) })
        )
        userID1 = res.body.userId

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.users', 'user')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (getBusiness.users.some((user: User) => user.id === userID)) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Create User3 by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/user/new')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send({ ...newUser2, businessId, roleId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({ status: 0, userId: expect.any(String) })
        )
        userID2 = res.body.userId

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.users', 'user')
          .where('business.id = :id', { id: businessId })
          .getOne()

        if (getBusiness.users.some((user: User) => user.id === userID)) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Active user', (done) => {
    const fu = async () => {
      try {
        const getUser = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.id = :id', {
            id: userID,
          })
          .getOne()

        const res: request.Response = await request(newApp)
          .post('/active')
          .set('Content-type', 'application/json')
          .send({
            firstName: newUser.firstName,
            surName: newUser.surName,
            pass: newUser.password,
            active: getUser.activatingHash,
          })
          .expect(200)

        expect(res.body).toEqual(expect.objectContaining({ status: 0 }))

        const getUserActive = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.id = :id', {
            id: userID,
          })
          .getOne()

        if (getUserActive.isActivated) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Active user1', (done) => {
    const fu = async () => {
      try {
        const getUser = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.id = :id', {
            id: userID1,
          })
          .getOne()

        const res: request.Response = await request(newApp)
          .post('/active')
          .set('Content-type', 'application/json')
          .send({
            firstName: newUser.firstName,
            surName: newUser.surName,
            pass: newUser.password,
            active: getUser.activatingHash,
          })
          .expect(200)

        expect(res.body).toEqual(expect.objectContaining({ status: 0 }))

        const getUserActive = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.id = :id', {
            id: userID,
          })
          .getOne()

        if (getUserActive.isActivated) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Active user', (done) => {
    const fu = async () => {
      try {
        const getUser = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.id = :id', {
            id: userID2,
          })
          .getOne()

        const res: request.Response = await request(newApp)
          .post('/active')
          .set('Content-type', 'application/json')
          .send({
            firstName: newUser.firstName,
            surName: newUser.surName,
            pass: newUser.password,
            active: getUser.activatingHash,
          })
          .expect(200)

        expect(res.body).toEqual(expect.objectContaining({ status: 0 }))

        const getUserActive = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.id = :id', {
            id: userID2,
          })
          .getOne()

        if (getUserActive.isActivated) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Login user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/login')
          .set('Content-type', 'application/json')
          .send({ email: newUser.email, password: newUser.password })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
            refreshToken: expect.any(String),
          })
        )

        accessToken_user = res.body.accessToken
        refreshToken_user = res.body.refreshToken
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Select business for user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post('/private/business/user/select')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessId })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            accessToken: expect.any(String),
          })
        )
        accessToken_user = res.body.accessToken
        const getUser = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.authentications', 'authentication')
          .leftJoinAndSelect('authentication.activeBusiness', 'business')
          .where('user.id = :id', { id: userID })
          .getOne()

        if (getUser.authentications[0].activeBusiness.id === businessId) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add floor to business by user with wrong properties', (done) => {
    const fu = async () => {
      try {
        const properties = 'ala'
        const res: request.Response = await request(newApp)
          .post('/private/floor/new')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessId, properties })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 4,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add floor to business by user', (done) => {
    const fu = async () => {
      try {
        const properties = [0, 0, 0, 0, 0, 0, 0, 0, 16]
        const res: request.Response = await request(newApp)
          .post('/private/floor/new')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessId, properties, width: 20 })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            floorId: expect.any(String),
          })
        )

        floorId = res.body.floorId

        const getFloor = await db
          .getRepository(Floors)
          .createQueryBuilder('floors')
          .leftJoinAndSelect('floors.business', 'business')
          .leftJoinAndSelect('floors.idUserCreated', 'user')
          .where('floors.id = :id', { id: floorId })
          .getOne()
        if (
          getFloor.business.id === businessId &&
          arrayEquals(getFloor.properties, properties) &&
          getFloor.idUserCreated.id === userID
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add room types by admin', (done) => {
    const fu = async () => {
      try {
        const roomTypes = {
          name: 'OneToOneJest',
          maxUsersLicensed: true,
          maxUsers: 2,
          inviteOnly: true,
          hasManager: false,
          hasModerators: false,
          isConference: false,
          enumNumber: 0,
        }
        const res: request.Response = await request(newApp)
          .post('/private/room-type/new')
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send(roomTypes)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            roomTypeId: expect.any(String),
          })
        )

        roomTypeId = res.body.roomTypeId

        const getRoomTypes = (await db
          .getRepository(RoomsTypes)
          .createQueryBuilder('roomTypes')

          .where('roomTypes.id = :id', { id: roomTypeId })
          .getOne()) as RoomsTypes

        if (
          getRoomTypes.name === roomTypes.name &&
          getRoomTypes.maxUsersLicensed === roomTypes.maxUsersLicensed &&
          getRoomTypes.maxUsers === roomTypes.maxUsers &&
          getRoomTypes.inviteOnly === roomTypes.inviteOnly &&
          getRoomTypes.hasManager === roomTypes.hasManager &&
          getRoomTypes.hasModerators === roomTypes.hasModerators &&
          getRoomTypes.isConference === roomTypes.isConference
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit room types by admin', (done) => {
    const fu = async () => {
      try {
        const roomTypes = {
          name: 'OneToOneJestEdit',
          maxUsersLicensed: false,
          maxUsers: 2,
          hasModerators: true,
          isConference: true,
        }
        const res: request.Response = await request(newApp)
          .post(`/private/room-type/${roomTypeId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send(roomTypes)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            roomTypeId: expect.any(String),
          })
        )

        roomTypeId = res.body.roomTypeId

        const getRoomTypes = (await db
          .getRepository(RoomsTypes)
          .createQueryBuilder('roomTypes')

          .where('roomTypes.id = :id', { id: roomTypeId })
          .getOne()) as RoomsTypes

        if (
          getRoomTypes.name === roomTypes.name &&
          getRoomTypes.maxUsersLicensed === roomTypes.maxUsersLicensed &&
          getRoomTypes.maxUsers === roomTypes.maxUsers &&
          getRoomTypes.hasModerators === roomTypes.hasModerators &&
          getRoomTypes.isConference === roomTypes.isConference
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
  test('Get room types by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/room-type/${roomTypeId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            roomType: {
              dateCreated: expect.any(String),
              dateModified: expect.any(String),
              hasManager: false,
              hasModerators: true,
              isConference: true,
              id: roomTypeId,
              inviteOnly: true,
              maxUsers: 2,
              maxUsersLicensed: false,
              name: 'OneToOneJestEdit',
              roomTypeEnum: 0,
            },
          })
        )

        const roomType = res.body.roomType
        const getRoomType = (await db
          .getRepository(RoomsTypes)
          .createQueryBuilder('roomTypes')

          .where('roomTypes.id = :id', { id: roomTypeId })
          .getOne()) as RoomsTypes

        if (
          getRoomType.name === roomType.name &&
          getRoomType.maxUsersLicensed === roomType.maxUsersLicensed &&
          getRoomType.maxUsers === roomType.maxUsers &&
          getRoomType.hasModerators === roomType.hasModerators &&
          getRoomType.isConference === roomType.isConference
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all room types by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/room-types`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            roomTypes: [
              {
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
                hasManager: false,
                hasModerators: true,
                isConference: true,
                id: roomTypeId,
                inviteOnly: true,
                maxUsers: 2,
                maxUsersLicensed: false,
                name: 'OneToOneJestEdit',
                roomTypeEnum: 0,
                userCreated: expect.any(String),
                userModified: expect.any(String),
              },
            ],
          })
        )

        const roomTypes = res.body.roomTypes
        const getRoomType = (await db
          .getRepository(RoomsTypes)
          .createQueryBuilder('roomTypes')

          .where('roomTypes.id = :id', { id: roomTypeId })
          .getOne()) as RoomsTypes

        if (
          getRoomType.name === roomTypes[0].name &&
          getRoomType.maxUsersLicensed === roomTypes[0].maxUsersLicensed &&
          getRoomType.maxUsers === roomTypes[0].maxUsers &&
          getRoomType.hasModerators === roomTypes[0].hasModerators &&
          getRoomType.isConference === roomTypes[0].isConference
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add room to floor by user', (done) => {
    const fu = async () => {
      try {
        const room = {
          floorId: floorId,
          typesId: roomTypeId,
          name: 'roomTestJest',
          isSecured: true,
          password: 'tak',
          coordX: 1,
          coordY: 1,
          width: 1,
          height: 1,
          rotation: 0,
          scale: 1,
          color: '256,25,21',
        }
        const res: request.Response = await request(newApp)
          .post('/private/room/new')
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send(room)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            roomId: expect.any(String),
          })
        )

        roomId = res.body.roomId

        const getRoom = await db
          .getRepository(Rooms)
          .createQueryBuilder('rooms')
          .leftJoinAndSelect('rooms.floor', 'floors')
          .leftJoinAndSelect('rooms.types', 'roomsTypes')
          .where('rooms.id = :id', { id: roomId })
          .getOne()

        if (
          getRoom.floor.id === room.floorId &&
          getRoom.types.id === room.typesId &&
          getRoom.name === room.name &&
          getRoom.isSecured === room.isSecured &&
          getRoom.coordX === room.coordX &&
          getRoom.coordY === room.coordY &&
          getRoom.width === room.width &&
          getRoom.height === room.height &&
          getRoom.rotation === room.rotation &&
          getRoom.scale === room.scale &&
          getRoom.color === room.color
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
  test('Edit License by Admin to no active', (done) => {
    const fu = async () => {
      const license = {
        startDate: '2022-11-28 10:36:42.425+01',
        endDate: '2022-11-29 10:36:42.425+01',
        maxUsersInBusiness: 10,
        maxUsersRooms: 10,
      }
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/license/${licenseId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send(license)
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            licenseId: expect.any(String),
          })
        )

        const getLicense = (await db
          .getRepository(License)
          .createQueryBuilder('license')
          .where('id = :id', { id: licenseId })
          .getOne()) as License

        if (
          new Date(getLicense.endDate).getTime() ===
          new Date(license.endDate).getTime()
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add user to room by user with no active license', (done) => {
    const fu = async () => {
      try {
        const roomMembersAddUserDate = {
          userId: userID,
          roomId,
          roomRole: 1,
        }
        const res: request.Response = await request(newApp)
          .post(`/private/room/user/add`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send(roomMembersAddUserDate)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 7,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit License by Admin to active', (done) => {
    const fu = async () => {
      const license = {
        startDate: '2022-11-29 10:36:42.425+01',
        endDate: '2023-11-29 10:36:42.425+01',
        maxUsersInBusiness: 10,
        maxUsersRooms: 10,
      }
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/license/${licenseId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .send(license)
          .expect(200)
        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            licenseId: expect.any(String),
          })
        )

        const getLicense = (await db
          .getRepository(License)
          .createQueryBuilder('license')
          .where('id = :id', { id: licenseId })
          .getOne()) as License

        if (
          new Date(getLicense.endDate).getTime() ===
          new Date(license.endDate).getTime()
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit room by user with wrong id', (done) => {
    const fu = async () => {
      try {
        const room = {
          typesId: roomTypeId,
          name: 'roomTestJestEdit',
          isSecured: false,
          coordX: 20,
          coordY: 10,
        }
        const res: request.Response = await request(newApp)
          .post(`/private/room/d099814d-8868-476f-bf7a-3cd4b9d216b2`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send(room)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 3,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit room by user with wrong typesId', (done) => {
    const fu = async () => {
      try {
        const room = {
          typesId: 'd099814d-8868-476f-bf7a-3cd4b9d216b2',
          name: 'roomTestJestEdit',
          isSecured: false,
          coordX: 20,
          coordY: 10,
        }
        const res: request.Response = await request(newApp)
          .post(`/private/room/${roomId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send(room)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 3,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit room with pass by user', (done) => {
    const fu = async () => {
      try {
        const room = {
          isSecured: true,
          password: 'password',
        }
        const res: request.Response = await request(newApp)
          .post(`/private/room/${roomId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send(room)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            roomId: expect.any(String),
          })
        )

        roomId = res.body.roomId

        const getRoom = await db
          .getRepository(Rooms)
          .createQueryBuilder('rooms')
          .leftJoinAndSelect('rooms.floor', 'floors')
          .leftJoinAndSelect('rooms.types', 'roomsTypes')
          .where('rooms.id = :id', { id: roomId })
          .getOne()
        if (getRoom.isSecured === room.isSecured) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Check Room password', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/password/room`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ roomId: roomId, password: 'password' })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            access: true,
          })
        )
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Check Room password wit wrong pass', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/password/room`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ roomId: roomId, password: 'pasword' })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            access: false,
          })
        )
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit room by user', (done) => {
    const fu = async () => {
      try {
        const room = {
          typesId: roomTypeId,
          name: 'roomTestJestEdit',
          isSecured: false,
          coordX: 20,
          coordY: 10,
        }
        const res: request.Response = await request(newApp)
          .post(`/private/room/${roomId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send(room)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            roomId: expect.any(String),
          })
        )

        roomId = res.body.roomId

        const getRoom = await db
          .getRepository(Rooms)
          .createQueryBuilder('rooms')
          .leftJoinAndSelect('rooms.floor', 'floors')
          .leftJoinAndSelect('rooms.types', 'roomsTypes')
          .where('rooms.id = :id', { id: roomId })
          .getOne()
        if (
          getRoom.types.id === room.typesId &&
          getRoom.name === room.name &&
          getRoom.isSecured === room.isSecured &&
          getRoom.coordX === room.coordX &&
          getRoom.coordY === room.coordY
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Check Room password wit no required password', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/password/room`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ roomId: roomId, password: 'pasword' })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            access: true,
          })
        )
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get room by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/room/${roomId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            room: {
              color: expect.any(String),
              coordX: expect.any(Number),
              coordY: expect.any(Number),
              dateCreated: expect.any(String),
              dateModified: expect.any(String),
              camDisallowed: false,
              isMuted: false,
              floor: {
                business: {
                  id: expect.any(String),
                },
                id: expect.any(String),
              },
              height: expect.any(Number),
              id: expect.any(String),
              isClosed: false,
              isSecured: false,
              name: 'roomTestJestEdit',
              rotation: expect.any(Number),
              scale: expect.any(Number),
              types: {
                id: expect.any(String),
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
                hasManager: false,
                hasModerators: true,
                isConference: true,
                inviteOnly: true,
                maxUsers: expect.any(Number),
                maxUsersLicensed: false,
                name: expect.any(String),
                roomTypeEnum: expect.any(Number),
              },
              width: expect.any(Number),
              usersId: expect.any(Array),
              moderatorsId: expect.any(Array),
              guestId: expect.any(Array),
            },
          })
        )

        const room = res.body.room

        const getRoom = await db
          .getRepository(Rooms)
          .createQueryBuilder('rooms')
          .leftJoinAndSelect('rooms.floor', 'floors')
          .leftJoinAndSelect('floors.business', 'business')
          .leftJoinAndSelect('rooms.types', 'roomsTypes')
          .select(['floors.id', 'business.id', 'roomsTypes.id', 'rooms'])
          .where('rooms.id = :id', {
            id: roomId,
          })
          .getOne()
        if (
          getRoom.types.id === room.types.id &&
          getRoom.name === room.name &&
          getRoom.isSecured === room.isSecured &&
          getRoom.coordX === room.coordX &&
          getRoom.coordY === room.coordY &&
          getRoom.floor.business.id === room.floor.business.id &&
          getRoom.floor.id === room.floor.id &&
          getRoom.types.id === room.types.id
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all rooms in business by admin with wrong businessId', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/room/business/d099814d-8868-476f-bf7a-3cd4b9d216b2`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 3,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all rooms in business by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/room/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            rooms: [
              {
                color: expect.any(String),
                coordX: expect.any(Number),
                coordY: expect.any(Number),
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
                height: expect.any(Number),
                id: expect.any(String),
                isClosed: false,
                isSecured: false,
                name: 'roomTestJestEdit',
                rotation: expect.any(Number),
                scale: expect.any(Number),
                floorId: expect.any(String),
                roomMembers: expect.any(Array),
                camDisallowed: false,
                isMuted: false,
                types: {
                  id: expect.any(String),
                  dateCreated: expect.any(String),
                  dateModified: expect.any(String),
                  hasManager: false,
                  hasModerators: true,
                  isConference: true,
                  inviteOnly: true,
                  maxUsers: expect.any(Number),
                  maxUsersLicensed: false,
                  roomTypeEnum: expect.any(Number),
                  name: expect.any(String),
                },
                width: expect.any(Number),
              },
            ],
          })
        )

        const rooms = res.body.rooms

        const getRoom = await db
          .getRepository(Rooms)
          .createQueryBuilder('rooms')
          .leftJoinAndSelect('rooms.floor', 'floors')
          .leftJoinAndSelect('floors.business', 'business')
          .leftJoinAndSelect('rooms.types', 'roomsTypes')
          .where('rooms.id = :id', {
            id: roomId,
          })
          .getOne()
        if (
          getRoom.types.id === rooms[0].types.id &&
          getRoom.name === rooms[0].name &&
          getRoom.isSecured === rooms[0].isSecured &&
          getRoom.coordX === rooms[0].coordX &&
          getRoom.coordY === rooms[0].coordY &&
          getRoom.types.id === rooms[0].types.id
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all rooms in floor by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/room/floor/${floorId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            rooms: [
              {
                color: expect.any(String),
                coordX: expect.any(Number),
                coordY: expect.any(Number),
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
                height: expect.any(Number),
                id: expect.any(String),
                isClosed: false,
                isSecured: false,
                name: 'roomTestJestEdit',
                rotation: expect.any(Number),
                scale: expect.any(Number),
                roomMembers: expect.any(Array),
                camDisallowed: false,
                isMuted: false,
                types: {
                  id: expect.any(String),
                  dateCreated: expect.any(String),
                  dateModified: expect.any(String),
                  hasManager: false,
                  hasModerators: true,
                  isConference: true,
                  inviteOnly: true,
                  maxUsers: expect.any(Number),
                  maxUsersLicensed: false,
                  roomTypeEnum: expect.any(Number),
                  name: expect.any(String),
                },
                userCreated: expect.any(String),
                userModified: expect.any(String),
                width: expect.any(Number),
              },
            ],
          })
        )

        const rooms = res.body.rooms

        const getRoom = await db
          .getRepository(Rooms)
          .createQueryBuilder('rooms')
          .leftJoinAndSelect('rooms.floor', 'floors')
          .leftJoinAndSelect('floors.business', 'business')
          .leftJoinAndSelect('rooms.types', 'roomsTypes')
          .where('rooms.id = :id', {
            id: roomId,
          })
          .getOne()
        if (
          getRoom.types.id === rooms[0].types.id &&
          getRoom.name === rooms[0].name &&
          getRoom.isSecured === rooms[0].isSecured &&
          getRoom.coordX === rooms[0].coordX &&
          getRoom.coordY === rooms[0].coordY &&
          getRoom.types.id === rooms[0].types.id
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add user to room by user', (done) => {
    const fu = async () => {
      try {
        const roomMembersAddUserDate = {
          userId: userID,
          roomId,
          roomRole: 0,
        }
        const res: request.Response = await request(newApp)
          .post(`/private/room/user/add`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send(roomMembersAddUserDate)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            roomMembers: expect.any(String),
          })
        )

        roomMembersId = res.body.roomMembers

        const getRoomMembers = await db
          .getRepository(RoomsMembers)
          .createQueryBuilder('roomsMembers')
          .leftJoinAndSelect('roomsMembers.user', 'user')
          .leftJoinAndSelect('roomsMembers.room', 'room')
          .where('roomsMembers.id = :id', {
            id: roomMembersId,
          })
          .getOne()
        if (
          roomMembersAddUserDate.roomId === getRoomMembers.room.id &&
          roomMembersAddUserDate.userId === getRoomMembers.user.id &&
          getRoomMembers.isManager === true
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all rooms in business by user with room members', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/room/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            rooms: [
              {
                color: expect.any(String),
                coordX: expect.any(Number),
                coordY: expect.any(Number),
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
                height: expect.any(Number),
                id: expect.any(String),
                isClosed: false,
                isSecured: false,
                name: 'roomTestJestEdit',
                rotation: expect.any(Number),
                scale: expect.any(Number),
                floorId: expect.any(String),
                roomMembers: expect.any(Array),
                camDisallowed: false,
                isMuted: false,
                types: {
                  id: expect.any(String),
                  dateCreated: expect.any(String),
                  dateModified: expect.any(String),
                  hasManager: false,
                  hasModerators: true,
                  isConference: true,
                  inviteOnly: true,
                  maxUsers: expect.any(Number),
                  maxUsersLicensed: false,
                  roomTypeEnum: expect.any(Number),
                  name: expect.any(String),
                },
                width: expect.any(Number),
              },
            ],
          })
        )

        const getRoom = await db
          .getRepository(Rooms)
          .createQueryBuilder('rooms')
          .leftJoinAndSelect('rooms.roomMembers', 'roomMembers')
          .where('rooms.id = :id', {
            id: roomId,
          })
          .getOne()

        if (getRoom.roomMembers.length === 1) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add temporary user to room by user', (done) => {
    const fu = async () => {
      try {
        const userToAdd = {
          email: newUser.email,
          businessId,
          roomId,
        }
        const res: request.Response = await request(newApp)
          .post(`/private/generate-meeting-link`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send(userToAdd)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getTemporaryUser = await db
          .getRepository(TemporaryUser)
          .createQueryBuilder('temporaryUser')
          .leftJoinAndSelect('temporaryUser.roomMember', 'roomMember')
          .leftJoinAndSelect('roomMember.user', 'user')
          .leftJoinAndSelect('roomMember.room', 'room')
          .where('temporaryUser.email = :email', { email: newUser.email })
          .andWhere('room.id = :roomId', { roomId: roomId })
          .getOne()

        meetingLink = getTemporaryUser.accessHash
        if (
          getTemporaryUser != null &&
          getTemporaryUser.roomMember?.room.id === roomId
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('decode meeting Link to user in business', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/decode-meeting`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ token: meetingLink })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getTemporaryUser = await db
          .getRepository(TemporaryUser)
          .createQueryBuilder('temporaryUser')
          .leftJoinAndSelect('temporaryUser.roomMember', 'roomMember')
          .leftJoinAndSelect('roomMember.user', 'user')
          .leftJoinAndSelect('roomMember.room', 'room')
          .where('temporaryUser.email = :email', { email: newUser.email })
          .andWhere('room.id = :roomId', { roomId: roomId })
          .getOne()

        meetingLink = getTemporaryUser.accessHash
        if (
          getTemporaryUser != null &&
          getTemporaryUser.roomMember?.room.id === roomId &&
          getTemporaryUser.roomMember?.user.id === userID
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all rooms in floor by user with user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/room/floor/${floorId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            rooms: [
              {
                color: expect.any(String),
                coordX: expect.any(Number),
                coordY: expect.any(Number),
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
                height: expect.any(Number),
                id: expect.any(String),
                isClosed: false,
                isSecured: false,
                name: 'roomTestJestEdit',
                rotation: expect.any(Number),
                scale: expect.any(Number),
                types: {
                  id: expect.any(String),
                  dateCreated: expect.any(String),
                  dateModified: expect.any(String),
                  hasManager: false,
                  hasModerators: true,
                  isConference: true,
                  inviteOnly: true,
                  maxUsers: expect.any(Number),
                  maxUsersLicensed: false,
                  roomTypeEnum: expect.any(Number),
                  name: expect.any(String),
                },
                userCreated: expect.any(String),
                userModified: expect.any(String),
                width: expect.any(Number),
                roomMembers: expect.any(Array),
                camDisallowed: false,
                isMuted: false,
              },
            ],
          })
        )

        const rooms = res.body.rooms

        const getRoom = await db
          .getRepository(Rooms)
          .createQueryBuilder('rooms')
          .leftJoinAndSelect('rooms.floor', 'floors')
          .leftJoinAndSelect('floors.business', 'business')
          .leftJoinAndSelect('rooms.types', 'roomsTypes')
          .where('rooms.id = :id', {
            id: roomId,
          })
          .getOne()
        if (
          getRoom.types.id === rooms[0].types.id &&
          getRoom.name === rooms[0].name &&
          getRoom.isSecured === rooms[0].isSecured &&
          getRoom.coordX === rooms[0].coordX &&
          getRoom.coordY === rooms[0].coordY &&
          getRoom.types.id === rooms[0].types.id
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add users to room by user', (done) => {
    const fu = async () => {
      try {
        const roomMembersAddUserDate = {
          roomId,
          users: [
            { userId: userID, roomRole: 1 },
            { userId: userID1, roomRole: 0 },
            { userId: userID2, roomRole: 2 },
          ],
        }
        const res: request.Response = await request(newApp)
          .post(`/private/room/users/add`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send(roomMembersAddUserDate)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getRoom = await db
          .getRepository(Rooms)
          .createQueryBuilder('rooms')
          .leftJoinAndSelect('rooms.roomMembers', 'roomsMembers')
          .leftJoinAndSelect('roomsMembers.user', 'user')
          .where('roomsMembers.id = :id', {
            id: roomMembersId,
          })
          .getOne()
        if (
          getRoom.roomMembers.every((roomMember: RoomsMembers) =>
            roomMembersAddUserDate.users.some(
              ({ userId }) => userId === roomMember.user.id
            )
          )
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get room by user with user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/room/${roomId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            room: {
              color: expect.any(String),
              coordX: expect.any(Number),
              coordY: expect.any(Number),
              dateCreated: expect.any(String),
              dateModified: expect.any(String),
              camDisallowed: false,
              isMuted: false,
              floor: {
                business: {
                  id: expect.any(String),
                },
                id: expect.any(String),
              },
              height: expect.any(Number),
              id: expect.any(String),
              isClosed: false,
              isSecured: false,
              name: 'roomTestJestEdit',
              rotation: expect.any(Number),
              scale: expect.any(Number),
              types: {
                id: expect.any(String),
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
                hasManager: false,
                hasModerators: true,
                isConference: true,
                inviteOnly: true,
                maxUsers: expect.any(Number),
                maxUsersLicensed: false,
                roomTypeEnum: expect.any(Number),
                name: expect.any(String),
              },
              width: expect.any(Number),
              managerId: expect.any(String),
              usersId: expect.any(Array),
              moderatorsId: expect.any(Array),
              guestId: expect.any(Array),
            },
          })
        )

        const room = res.body.room

        const getRoom = await db
          .getRepository(Rooms)
          .createQueryBuilder('rooms')
          .leftJoinAndSelect('rooms.floor', 'floors')
          .leftJoinAndSelect('floors.business', 'business')
          .leftJoinAndSelect('rooms.types', 'roomsTypes')
          .select(['floors.id', 'business.id', 'roomsTypes.id', 'rooms'])
          .where('rooms.id = :id', {
            id: roomId,
          })
          .getOne()
        if (
          getRoom.types.id === room.types.id &&
          getRoom.name === room.name &&
          getRoom.isSecured === room.isSecured &&
          getRoom.coordX === room.coordX &&
          getRoom.coordY === room.coordY &&
          getRoom.floor.business.id === room.floor.business.id &&
          getRoom.floor.id === room.floor.id &&
          getRoom.types.id === room.types.id
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all rooms members by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/user/room/${roomId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            userInRoom: [
              {
                id: expect.any(String),
                userId: expect.any(String),
                roomId: roomId,
                roomRole: expect.any(Number),
                email: expect.any(String),
                firstName: expect.any(String),
                surName: expect.any(String),
              },
              {
                id: expect.any(String),
                userId: expect.any(String),
                roomId: roomId,
                roomRole: expect.any(Number),
                email: expect.any(String),
                firstName: expect.any(String),
                surName: expect.any(String),
              },
              {
                id: expect.any(String),
                userId: expect.any(String),
                roomId: roomId,
                roomRole: expect.any(Number),
                email: expect.any(String),
                firstName: expect.any(String),
                surName: expect.any(String),
              },
            ],
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add new Messages to room', (done) => {
    const fu = async () => {
      try {
        await Promise.all(
          [
            {
              roomId,
              message: 'ala',
              email: 'ala@vel.pl',
              firstName: 'John',
              surName: 'bel',
            },
            {
              roomId,
              message: 'bela',
              email: 'ala@vel.pl',
              firstName: 'John',
              surName: 'bel',
            },
            {
              roomId,
              message: 'cela',
              email: 'ala@vel.pl',
              firstName: 'John',
              surName: 'bel',
            },
            {
              roomId,
              message: 'gela',
              email: 'ala@vel.pl',
              firstName: 'John',
              surName: 'bel',
            },
            {
              roomId,
              message: 'mela',
              email: 'ala@vel.pl',
              firstName: 'John',
              surName: 'bel',
            },
            {
              roomId,
              message: 'tela',
              email: 'ala@vel.pl',
              firstName: 'John',
              surName: 'bel',
            },
            {
              roomId,
              message: 'zela',
              email: 'ala@vel.pl',
              firstName: 'John',
              surName: 'bel',
            },
          ].map(async (message) => {
            const res: request.Response = await request(newApp)
              .post(`/private/message`)
              .set('Authorization', `Bearer ${accessToken_user}`)
              .set('Content-type', 'application/json')
              .send(message)
              .expect(200)

            expect(res.body).toEqual(
              expect.objectContaining({
                status: 0,
                message: {
                  dateCreated: expect.any(String),
                  fullName: expect.any(String),
                  id: expect.any(String),
                  message: expect.any(String),
                  roomId: expect.any(String),
                  userId: expect.any(String),
                  email: expect.any(String),
                  firstName: expect.any(String),
                  surName: expect.any(String),
                },
              })
            )
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get 20 Messages to room', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/messages/room/${roomId}/${0}/${20}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            messages: expect.any(Array),
          })
        )

        messageId = res.body.messages[0].id

        if (res.body.messages.length === 7) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
  test('Get 2 Messages to room', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/messages/room/${roomId}/${0}/${2}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            messages: expect.any(Array),
          })
        )

        messageId = res.body.messages[0].id

        if (res.body.messages.length === 2) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get 1 and skip 1 Messages to room', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/messages/room/${roomId}/${1}/${1}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            messages: [
              {
                dateCreated: expect.any(String),
                fullName: 'John Alka',
                id: expect.any(String),
                message: expect.any(String),
                roomId: expect.any(String),
                userId: expect.any(String),
                email: 'ala@vel.pl',
                firstName: 'John',
                surName: 'bel',
              },
            ],
          })
        )

        if (res.body.messages.length === 1) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
  test('Get Messages to room', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/messages/room/${roomId}/0/0`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            messages: expect.any(Array),
          })
        )

        if (res.body.messages.length === 7) {
          done()
        } else {
          done('error')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete Message', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/message/${messageId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Add the same user to room by user', (done) => {
    const fu = async () => {
      try {
        const roomMembersAddUserDate = {
          userId: userID,
          roomId,
          roomRole: 1,
        }
        const res: request.Response = await request(newApp)
          .post(`/private/room/user/add`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send(roomMembersAddUserDate)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 8,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit user to room by user', (done) => {
    const fu = async () => {
      try {
        const roomMembersAddUserDate = {
          userId: userID,
          roomId,
          roomRole: 0,
        }
        const res: request.Response = await request(newApp)
          .post(`/private/room/user/edit`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send(roomMembersAddUserDate)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getRoomMembers = await db
          .getRepository(RoomsMembers)
          .createQueryBuilder('roomsMembers')
          .leftJoinAndSelect('roomsMembers.user', 'user')
          .leftJoinAndSelect('roomsMembers.room', 'room')
          .where('roomsMembers.id = :id', {
            id: roomMembersId,
          })
          .getOne()
        if (
          roomMembersAddUserDate.roomId === getRoomMembers.room.id &&
          roomMembersAddUserDate.userId === getRoomMembers.user.id &&
          getRoomMembers.isManager === true
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit room isClosed by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/close/room/${roomId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ isClosed: true })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getRoom = await db
          .getRepository(Rooms)
          .createQueryBuilder('rooms')
          .where('rooms.id = :id', {
            id: roomId,
          })
          .getOne()
        if (getRoom.isClosed === true) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit room isClosed by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .post(`/private/MutedAndCamDisallowed/room/${roomId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ isMuted: true, camDisallowed: true })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getRoom = await db
          .getRepository(Rooms)
          .createQueryBuilder('rooms')
          .where('rooms.id = :id', {
            id: roomId,
          })
          .getOne()
        if (getRoom.isMuted === true && getRoom.camDisallowed === true) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Edit floor to business by user', (done) => {
    const fu = async () => {
      try {
        const properties = [0, 0, 0, 0, 0, 0, 0, 0, 16, 12, 10]
        const res: request.Response = await request(newApp)
          .post(`/private/floor/${floorId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .send({ businessId, properties })
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            floorId: expect.any(String),
          })
        )

        floorId = res.body.floorId

        const getFloor = await db
          .getRepository(Floors)
          .createQueryBuilder('floors')
          .leftJoinAndSelect('floors.business', 'business')
          .leftJoinAndSelect('floors.idUserCreated', 'user')
          .where('floors.id = :id', { id: floorId })
          .getOne()

        if (
          getFloor.business.id === businessId &&
          arrayEquals(getFloor.properties, properties) &&
          getFloor.idUserCreated.id === userID
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get floor to business by user with wrong id', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/floor/${0}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 3,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get floor to business by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/floor/${floorId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            floor: {
              dateCreated: expect.any(String),
              dateModified: expect.any(String),
              id: expect.any(String),
              properties: expect.any(Array),
              rooms: expect.any(Array),
              width: 20,
              floorNumber: 1,
            },
          })
        )

        const floor = res.body.floor

        const getFloor = await db
          .getRepository(Floors)
          .createQueryBuilder('floors')
          .leftJoinAndSelect('floors.business', 'business')
          .leftJoinAndSelect('floors.idUserCreated', 'user')
          .where('floors.id = :id', { id: floorId })
          .getOne()

        if (
          arrayEquals(getFloor.properties, floor.properties) &&
          floorId === floor.id
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get all floors to business by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/floor/business/0`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
            floors: [
              {
                dateCreated: expect.any(String),
                dateModified: expect.any(String),
                id: expect.any(String),
                properties: expect.any(Array),
                width: 20,
                floorNumber: 1,
              },
            ],
          })
        )

        const floors = res.body.floors

        const getBusiness = await db
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.floors', 'floor')
          .where('business.id = :id', {
            id: businessId,
          })
          .getOne()

        if (
          arrayEquals(getBusiness.floors[0].properties, floors[0].properties) &&
          getBusiness.floors[0].id === floors[0].id
        ) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Get Statistics', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .get(`/private/statistics`)
          .set('Authorization', `Bearer ${accessToken}`)
          .expect(200)
        expect(res.body).toEqual({
          status: 0,
          allBusinessCount: expect.any(Number),
          allUsersCount: expect.any(Number),
          allUsersLoggedCount: expect.any(Number),
          averageBusinessFloors: expect.any(Number),
          averageBusinessRooms: expect.any(Number),
          averageBusinessUserInRooms: expect.any(Number),
          averageBusinessUsers: expect.any(Number),
        })
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete User by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/user/${userID1}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .send()
          .expect(200)

        expect(res.body).toEqual({ status: 0 })
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete user from room by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/room/${roomId}/user/${userID}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getRoomMembers = await db
          .getRepository(RoomsMembers)
          .createQueryBuilder('roomsMembers')
          .leftJoinAndSelect('roomsMembers.user', 'user')
          .leftJoinAndSelect('roomsMembers.room', 'room')
          .where('roomsMembers.id = :id', {
            id: roomMembersId,
          })
          .getOne()
        if (getRoomMembers == null) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Incorrect Delete floor to business by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/floor/${0}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 3,
          })
        )

        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete room by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/room/${roomId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getRoomTypes = (await db
          .getRepository(Rooms)
          .createQueryBuilder('rooms')
          .where('rooms.id = :id', { id: roomId })
          .getOne()) as RoomsTypes

        if (!getRoomTypes) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete floor to business by user', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/floor/${floorId}`)
          .set('Authorization', `Bearer ${accessToken_user}`)
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getFloor = await db
          .getRepository(Floors)
          .createQueryBuilder('floors')
          .where('floors.id = :id', { id: floorId })
          .getOne()

        if (!getFloor) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete business by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/business/${businessId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete room types by admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/room-type/${roomTypeId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .set('Content-type', 'application/json')
          .expect(200)

        expect(res.body).toEqual(
          expect.objectContaining({
            status: 0,
          })
        )

        const getRoomTypes = (await db
          .getRepository(RoomsTypes)
          .createQueryBuilder('roomTypes')

          .where('roomTypes.id = :id', { id: roomTypeId })
          .getOne()) as RoomsTypes

        if (!getRoomTypes) {
          done()
        } else {
          done('null')
        }
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete User by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/user/${userID}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .send()
          .expect(200)

        expect(res.body).toEqual({ status: 0 })
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
  test('Delete User2 by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/user/${userID2}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .send()
          .expect(200)

        expect(res.body).toEqual({ status: 0 })
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })

  test('Delete license by Admin', (done) => {
    const fu = async () => {
      try {
        const res: request.Response = await request(newApp)
          .delete(`/private/license/${licenseId}`)
          .set('Authorization', `Bearer ${accessToken}`)
          .send()
          .expect(200)

        expect(res.body).toEqual({ status: 0 })
        done()
      } catch (error) {
        done(error)
      }
    }
    fu()
  })
})
