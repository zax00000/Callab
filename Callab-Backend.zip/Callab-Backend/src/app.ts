import cors from 'cors'
import dotenv from 'dotenv'
dotenv.config()

import express, { Express } from 'express'
import RoutsLoader from './routes/RoutesLoader'
import sendMail from './sendMail'
import initDatabase from './utils/initDatabase'
import initEmail from './utils/initEmail'
import powersRoles from './utils/powersRoles'
import swaggerDocs from './utils/swagger'

const start = async () => {
  const app: Express = express()

  const db = await initDatabase()

  const port = process.env.PORT || '3000'

  app.use(cors())

  app.disable('x-powered-by')
  // if (process.env.NODE_ENV === 'production') {
  //   app.use(morgan('combined'))
  // } else {
  //   app.use(morgan('dev'))
  // }

  // app.use(morgan('combined'))

  app.use(express.json({ limit: '25mb' }))
  app.use(express.urlencoded({ extended: true, limit: '25mb' }))

  await powersRoles.init()
  await initEmail()
  RoutsLoader(app)
  await swaggerDocs(app, port)

  const server = app.listen(port, async () => {
    console.log(`⚡️[server]: Server is running at http://localhost:${port}`)
  })
  return { app, db, server, sendMail }
}

export default start
