import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { Business } from './business'
import { Role } from './role'
import { User } from './user'

@Entity('authentication')
export class Authentication {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @ManyToOne(() => User, (user) => user.authentications, {
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  user: User

  @Column()
  refreshToken?: string

  @ManyToOne(() => Role, { nullable: true, onDelete: 'CASCADE' })
  @JoinColumn()
  activeBusinessRole?: Role

  @ManyToOne(() => Business, (business) => business.activeUsers, {
    onDelete: 'CASCADE',
    nullable: true,
  })
  @JoinColumn()
  activeBusiness?: Business

  @Column({ type: 'timestamptz', default: () => 'CURRENT_TIMESTAMP' })
  dateLogin: Date
}
