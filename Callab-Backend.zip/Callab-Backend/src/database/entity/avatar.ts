import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { User } from './user'

@Entity('avatar')
export class Avatar {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @OneToOne(() => User, (user) => user.avatar)
  @JoinColumn()
  user: User

  @Column({ default: '' })
  avatar: string

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserCreated: User

  @Column({ type: 'timestamptz' })
  dateCreated: Date

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserModified: User

  @Column({ type: 'timestamptz' })
  dateModified: Date
}
