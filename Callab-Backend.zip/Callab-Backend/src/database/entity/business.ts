import {
  Column,
  Entity,
  Index,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { Authentication } from './authentication'
import { BusinessChanges } from './businessChanges'
import { BusinessItem } from './businessItem'
import { Floors } from './floors'
import { License } from './license'
import { PowersApp } from './powersApp'
import { Role } from './role'
import { User } from './user'
import { UserData } from './userData'
import { UserSettings } from './userSettings'

@Entity('business')
export class Business {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @OneToMany(() => Role, (role) => role.business)
  roles: Role[]

  @OneToMany(() => Floors, (floors) => floors.business)
  floors: Floors[]

  @ManyToOne(() => License, (license) => license.idBusiness)
  license: License

  @Column()
  nip: string

  @Column()
  name: string

  @Column()
  country: string

  @Column()
  zipCode: string

  @Column()
  city: string

  @Column()
  address1: string

  @Column()
  address2: string

  @Column()
  email: string

  @Column()
  phoneNumber: string

  @Column()
  contactName: string

  @Column()
  contactLastName: string

  @ManyToMany(() => PowersApp)
  @JoinTable()
  powersAppForBusiness: PowersApp[]

  @ManyToMany(() => User, (user) => user.business, {
    onDelete: 'CASCADE',
  })
  users?: User[]

  @OneToMany(() => BusinessItem, (businessItem) => businessItem.business, {
    onDelete: 'CASCADE',
  })
  items?: BusinessItem[]

  @OneToMany(
    () => Authentication,
    (authentication) => authentication.activeBusiness
  )
  activeUsers?: Authentication[]

  @OneToMany(() => UserSettings, (userSettings) => userSettings.defaultBusiness)
  usersDefault?: UserSettings[]

  @OneToMany(
    () => BusinessChanges,
    (businessChanges) => businessChanges.business
  )
  changes?: BusinessChanges[]

  @OneToMany(() => UserData, (userData) => userData.business)
  userData?: UserData[]

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserCreated: User

  @Column({ type: 'timestamptz' })
  dateCreated: Date

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserModified: User

  @Column({ type: 'timestamptz' })
  dateModified: Date
}
