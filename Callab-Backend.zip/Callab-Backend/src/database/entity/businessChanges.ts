import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { Business } from './business'

@Entity('businessChanges')
export class BusinessChanges {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @ManyToOne(() => Business, (business) => business.changes, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  business: Business

  @Column({ nullable: true, default: '' })
  userId: string

  @Column({ nullable: true, default: '' })
  changesToken: string

  @Column({ nullable: true, default: '' })
  userEmail: string

  @Column({ nullable: true, default: '' })
  nip: string

  @Column({ nullable: true, default: '' })
  name: string

  @Column({ nullable: true, default: '' })
  country: string

  @Column({ nullable: true, default: '' })
  zipCode: string

  @Column({ nullable: true, default: '' })
  city: string

  @Column({ nullable: true, default: '' })
  address1: string

  @Column({ nullable: true, default: '' })
  address2: string

  @Column({ nullable: true, default: '' })
  phoneNumber: string

  @Column({ nullable: true, default: '' })
  contactName: string

  @Column({ nullable: true, default: '' })
  contactLastName: string

  @Column({ nullable: true, default: '' })
  email: string

  @Column({ type: 'timestamptz' })
  dateModification: Date
}
