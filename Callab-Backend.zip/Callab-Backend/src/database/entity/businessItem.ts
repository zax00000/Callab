import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { Business } from './business'
import { Item } from './item'
import { User } from './user'
import { UserItem } from './userItem'

@Entity('businessItem')
export class BusinessItem {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true, default: 10, type: 'float' })
  price: number

  @OneToMany(() => UserItem, (userItem) => userItem.businessItem, {
    onDelete: 'CASCADE',
  })
  userItem: UserItem[]

  @Column({ nullable: false, default: true })
  canBeBought: boolean

  @ManyToOne(() => Item, (item) => item.businessItem, {
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  item?: Item

  @ManyToOne(() => Business, (business) => business.items, {
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  business?: Business

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserCreated: User

  @Column({ type: 'timestamptz' })
  dateCreated: Date

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserModified: User

  @Column({ type: 'timestamptz' })
  dateModified: Date
}
