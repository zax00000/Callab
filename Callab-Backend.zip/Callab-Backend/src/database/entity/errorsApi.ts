import {
  Column,
  Entity,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
  Index,
} from 'typeorm'
import { Translation } from './translation'
import { User } from './user'

@Entity('errorsApi')
export class ErrorsApi {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @OneToMany(() => Translation, (translation) => translation.errorsApi)
  translation: Translation[]

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserCreated: User

  @Column({ type: 'timestamptz' })
  dateCreated: Date

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserModified: User

  @Column({ type: 'timestamptz' })
  dateModified: Date
}
