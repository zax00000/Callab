import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { Business } from './business'
import { Rooms } from './rooms'
import { User } from './user'

@Entity('floors')
export class Floors {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @ManyToOne(() => Business, (business) => business.floors, {
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  business: Business

  @OneToMany(() => Rooms, (room) => room.floor)
  rooms: Rooms[]

  @Column('simple-json', { nullable: true })
  properties: number[]

  @Column({ default: 0 })
  floorNumber: number

  @Column()
  width: number

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserCreated: User

  @Column({ type: 'timestamptz' })
  dateCreated: Date

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserModified: User

  @Column({ type: 'timestamptz' })
  dateModified: Date
}
