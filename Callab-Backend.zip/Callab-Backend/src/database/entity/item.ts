import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { BusinessItem } from './businessItem'
import { User } from './user'

@Entity('item')
export class Item {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ nullable: true, default: '' })
  name: string

  @Column({ nullable: true, default: '' })
  description: string

  @Column({ nullable: true, default: null })
  pictureUrl: string

  @Column({ nullable: false, default: 0 })
  type: number

  @Column({ nullable: false, default: 0, type: 'float' })
  defaultPrice: number

  @OneToMany(() => BusinessItem, (businessItem) => businessItem.item, {
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  businessItem?: BusinessItem[]

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserCreated: User

  @Column({ type: 'timestamptz' })
  dateCreated: Date

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserModified: User

  @Column({ type: 'timestamptz' })
  dateModified: Date
}
