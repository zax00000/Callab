import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { Business } from './business'
import { User } from './user'

@Entity('license')
export class License {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column()
  name: string

  @OneToMany(() => Business, (business) => business.license)
  idBusiness: Business[]

  @Column({ type: 'timestamptz' })
  startDate: Date

  @Column({ type: 'timestamptz', nullable: true })
  endDate: Date

  @Column({ default: 100 })
  maxUsersInBusiness: number

  @Column({ default: 100 })
  maxUsersRooms: number

  @Column({ default: 10 })
  maxFloorInBusiness: number

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserCreated: User

  @Column({ type: 'timestamptz' })
  dateCreated: Date

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserModified: User

  @Column({ type: 'timestamptz' })
  dateModified: Date
}
