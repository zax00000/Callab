import { Column, Entity, Index, PrimaryGeneratedColumn } from 'typeorm'

@Entity('messages')
export class Messages {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  // @ManyToOne(() => Rooms, (room) => room.messages, {
  //   onDelete: 'SET NULL',
  // })
  // @JoinColumn()
  // room: Rooms

  @Column({ nullable: false })
  room: string

  @Column({ nullable: true, default: '' })
  userId: string

  @Column({ nullable: true, default: '' })
  message: string

  @Column({ nullable: true, default: '' })
  fullName: string

  @Column({ nullable: true, default: '' })
  email: string

  @Column({ nullable: true, default: '' })
  firstName: string

  @Column({ nullable: true, default: '' })
  surName: string

  @Column({ default: false })
  isDeleted: boolean

  @Column({ type: 'timestamptz' })
  dateCreated: Date
}
