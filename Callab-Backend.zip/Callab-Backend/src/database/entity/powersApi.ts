import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { PowersApp } from './powersApp'

@Entity('powersApi')
export class PowersApi {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column()
  name: string

  @ManyToOne(() => PowersApp, {
    nullable: true,
  })
  @JoinColumn()
  powerApp: PowersApp
}
