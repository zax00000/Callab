import {
  Column,
  Entity,
  OneToMany,
  PrimaryGeneratedColumn,
  Index,
} from 'typeorm'
import { PowersApi } from './powersApi'
import { Translation } from './translation'

@Entity('powersApp')
export class PowersApp {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column()
  name: string

  @Column({ unique: true })
  powerEnum: number

  @OneToMany(() => PowersApi, (powersApi) => powersApi.powerApp)
  powersApi: PowersApi[]

  @OneToMany(() => Translation, (translation) => translation.powersApp, {
    nullable: true,
  })
  translation: Translation[]
}
