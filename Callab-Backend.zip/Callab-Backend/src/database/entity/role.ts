import {
  Column,
  Entity,
  Index,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { Authentication } from './authentication'
import { Business } from './business'
import { PowersApp } from './powersApp'
import { Translation } from './translation'
import { User } from './user'

@Entity('role')
export class Role {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column()
  name: string

  @ManyToOne(() => Business, (business) => business.roles, {
    onDelete: 'CASCADE',
    nullable: true,
  })
  business?: Business

  @ManyToMany(() => PowersApp)
  @JoinTable()
  powersApp: PowersApp[]

  @ManyToOne(() => Translation, (translation) => translation.errorsApi, {
    nullable: true,
  })
  translation: Translation[]

  @Column({ default: false })
  superAdminApp: boolean

  @Column({ default: false })
  superAdminApi: boolean

  @ManyToMany(() => User, (user) => user.businessRoles, {
    onDelete: 'CASCADE',
    nullable: true,
  })
  userWithRole: User[]

  @OneToMany(
    () => Authentication,
    (authentication) => authentication.activeBusinessRole
  )
  activeUsers: Authentication[]

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserCreated: User

  @Column({ type: 'timestamptz' })
  dateCreated: Date

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserModified: User

  @Column({ type: 'timestamptz' })
  dateModified: Date
}
