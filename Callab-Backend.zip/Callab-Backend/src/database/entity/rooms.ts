import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { Floors } from './floors'
import { Messages } from './messages'
import { RoomsMembers } from './roomsMembers'
import { RoomsTypes } from './roomsTypes'
import { User } from './user'

@Entity('rooms')
export class Rooms {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @ManyToOne(() => Floors, (floor) => floor.rooms, {
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  floor: Floors

  @ManyToOne(() => RoomsTypes, (roomsTypes) => roomsTypes.rooms)
  types: RoomsTypes

  @Column()
  name: string

  @Column({ default: false })
  isSecured: boolean

  @Column({ default: false })
  isMuted: boolean

  @Column({ default: false })
  camDisallowed: boolean

  @Column({ default: false })
  isClosed: boolean

  @Column({ nullable: true })
  password: string

  @Column({ type: 'float', default: 0 })
  coordX: number

  @Column({ type: 'float', default: 0 })
  coordY: number

  @Column({ type: 'float', default: 100 })
  width: number

  @Column({ type: 'float', default: 100 })
  height: number

  @Column({ type: 'float', default: 0 })
  rotation: number

  @Column({ type: 'float', default: 1 })
  scale: number

  @OneToMany(() => RoomsMembers, (roomMembers) => roomMembers.room, {
    onDelete: 'SET NULL',
  })
  roomMembers: RoomsMembers[]

  @OneToMany(() => Messages, (messages) => messages.room, {
    onDelete: 'SET NULL',
  })
  messages: Messages[]

  @Column({ length: 100 })
  color: string

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserCreated: User

  @Column({ type: 'timestamptz' })
  dateCreated: Date

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserModified: User

  @Column({ type: 'timestamptz' })
  dateModified: Date
}
