import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { Rooms } from './rooms'
import { TemporaryUser } from './temporaryUser'
import { User } from './user'

@Entity('roomsMembers')
export class RoomsMembers {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @ManyToOne(() => User, (user) => user.roomsMembers, {
    onDelete: 'CASCADE',
    nullable: true,
  })
  @JoinColumn()
  user: User

  @OneToOne(() => TemporaryUser, (user) => user.roomMember, {
    onDelete: 'SET NULL',
    nullable: true,
  })
  temporaryUser: TemporaryUser

  @ManyToOne(() => Rooms, (rooms) => rooms.roomMembers, {
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  room: Rooms

  @Column({ default: false })
  isManager: boolean

  @Column({ default: false })
  isModerator: boolean

  @Column({ default: false })
  isUser: boolean

  @Column({ default: false })
  isGuest: boolean

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserCreated: User

  @Column({ type: 'timestamptz' })
  dateCreated: Date

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserModified: User

  @Column({ type: 'timestamptz' })
  dateModified: Date
}
