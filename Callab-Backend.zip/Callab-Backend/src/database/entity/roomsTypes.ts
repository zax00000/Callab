import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { Rooms } from './rooms'
import { User } from './user'

@Entity('roomsTypes')
export class RoomsTypes {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column({ unique: true })
  name: string

  @Column()
  maxUsersLicensed: boolean

  @Column()
  maxUsers: number

  @Column()
  inviteOnly: boolean

  @Column()
  hasManager: boolean

  @Column({ unique: true })
  roomTypeEnum: number

  @Column()
  hasModerators: boolean

  @Column()
  isConference: boolean

  @OneToMany(() => Rooms, (rooms) => rooms.types)
  rooms: Rooms[]

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserCreated: User

  @Column({ type: 'timestamptz' })
  dateCreated: Date

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserModified: User

  @Column({ type: 'timestamptz' })
  dateModified: Date
}
