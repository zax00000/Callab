import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { RoomsMembers } from './roomsMembers'
import { User } from './user'

@Entity('temporaryUser')
export class TemporaryUser {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Column()
  @Index()
  email: string

  @Column({ default: '' })
  firstName: string

  @Column({ default: '' })
  surName: string

  @Index()
  @Column({ nullable: true })
  accessHash: string

  @OneToOne(() => RoomsMembers, (roomsMembers) => roomsMembers.temporaryUser, {
    onDelete: 'SET NULL',
    nullable: true,
  })
  @JoinColumn()
  roomMember: RoomsMembers

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserCreated: User

  @Column({ type: 'timestamptz' })
  dateCreated: Date

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserModified: User

  @Column({ type: 'timestamptz' })
  dateModified: Date
}
