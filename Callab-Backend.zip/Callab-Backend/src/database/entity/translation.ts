import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { ErrorsApi } from './errorsApi'
import { Interface } from './interface'
import { Languages } from './languages'
import { PowersApp } from './powersApp'
import { Role } from './role'
import { User } from './user'

@Entity('translation')
export class Translation {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @ManyToOne(() => Languages, (language) => language.translations, {
    nullable: true,
    onDelete: 'CASCADE',
  })
  language: Languages

  @ManyToOne(() => ErrorsApi, (errorsApi) => errorsApi.translation, {
    nullable: true,
  })
  errorsApi: ErrorsApi

  @ManyToOne(() => Interface, (interfaces) => interfaces.translation, {
    nullable: true,
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  interfaces: Interface

  @ManyToOne(() => PowersApp, (powersApp) => powersApp.translation, {
    nullable: true,
  })
  powersApp: PowersApp

  @ManyToOne(() => Role, (role) => role.translation, {
    nullable: true,
    onDelete: 'CASCADE',
  })
  roles: Role

  @Column()
  translation: string

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserCreated: User

  @Column({ type: 'timestamptz', nullable: true })
  dateCreated: Date

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserModified: User

  @Column({ type: 'timestamptz', nullable: true })
  dateModified: Date
}
