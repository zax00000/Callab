import {
  Column,
  Entity,
  Index,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { Authentication } from './authentication'
import { Avatar } from './avatar'
import { Business } from './business'
import { Role } from './role'
import { RoomsMembers } from './roomsMembers'
import { UserData } from './userData'
import { UserSettings } from './userSettings'

@Entity('user')
export class User {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @Index()
  @Column({ unique: true })
  email: string

  // @Column({ nullable: true })
  // firstName: string

  // @Column({ nullable: true })
  // surName: string

  @Column({ nullable: true })
  pass: string

  @Column({ default: false })
  passChange: boolean

  @Column({ nullable: true })
  passHash: string

  @Column({ default: false })
  isActivated: boolean

  @Column({ nullable: true })
  activatingHash: string

  @Column({ type: 'timestamptz', nullable: true })
  dateLogIn: Date

  @Column({ type: 'timestamptz', nullable: true })
  dateLogOut: Date

  @ManyToMany(() => Role, (role) => role.userWithRole, {
    onDelete: 'CASCADE',
    nullable: true,
  })
  @JoinTable()
  businessRoles: Role[]

  @OneToOne(() => UserSettings, (userSettings) => userSettings.user)
  @JoinColumn()
  settings: UserSettings

  @OneToMany(() => Authentication, (authentication) => authentication.user)
  authentications: Authentication[]

  @Column({ default: false })
  isLogged: boolean

  @Column({ default: false })
  superAdmin: boolean

  @Column({ default: false })
  isDeveloper: boolean

  @OneToOne(() => Avatar, (avatar) => avatar.user)
  @JoinColumn()
  avatar: Avatar

  @ManyToMany(() => Business, (business) => business.users)
  @JoinTable()
  business?: Business[]

  @OneToMany(() => RoomsMembers, (roomsMembers) => roomsMembers.user)
  roomsMembers: RoomsMembers[]

  @OneToMany(() => UserData, (userData) => userData.user)
  userData: UserData[]

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserCreated: User

  @Column({ type: 'timestamptz' })
  dateCreated: Date

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserModified: User

  @Column({ type: 'timestamptz' })
  dateModified: Date
}
