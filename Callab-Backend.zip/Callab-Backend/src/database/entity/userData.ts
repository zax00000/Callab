import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { Business } from './business'
import { User } from './user'
import { UserItem } from './userItem'

@Entity('userData')
export class UserData {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @ManyToOne(() => User, (user) => user.userData, {
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  user: User

  @Column({ nullable: true, default: '' })
  firstName: string

  @Column({ nullable: true, default: '' })
  surName: string

  @ManyToOne(() => Business, (business) => business.userData, {
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  business?: Business

  @Column({ nullable: false, default: 0, type: 'float' })
  hrPoints: number

  @OneToMany(() => UserItem, (userItem) => userItem.userData, {
    onDelete: 'CASCADE',
  })
  items?: UserItem[]
}
