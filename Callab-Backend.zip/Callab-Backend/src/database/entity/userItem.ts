import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { BusinessItem } from './businessItem'
import { User } from './user'
import { UserData } from './userData'

@Entity('userItem')
export class UserItem {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @ManyToOne(() => BusinessItem, (businessItem) => businessItem.userItem, {
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  businessItem?: BusinessItem

  @ManyToOne(() => UserData, (userData) => userData.items, {
    onDelete: 'CASCADE',
    nullable: false,
  })
  @JoinColumn()
  userData: UserData

  @Column({ nullable: false, default: false })
  selected: boolean

  @Column({ nullable: false, default: 0, type: 'float' })
  posX: number

  @Column({ nullable: false, default: 0, type: 'float' })
  posY: number

  @Column({ nullable: false, default: 1, type: 'float' })
  scale: number

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserCreated: User

  @Column({ type: 'timestamptz' })
  dateCreated: Date

  @ManyToOne(() => User, {
    onDelete: 'SET NULL',
  })
  @JoinColumn()
  idUserModified: User

  @Column({ type: 'timestamptz' })
  dateModified: Date
}
