import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToOne,
  PrimaryGeneratedColumn,
} from 'typeorm'
import { Business } from './business'
import { Languages } from './languages'
import { User } from './user'

@Entity('userSettings')
export class UserSettings {
  @Index()
  @PrimaryGeneratedColumn('uuid')
  id: string

  @OneToOne(() => User, (user) => user.settings, {
    onDelete: 'CASCADE',
  })
  @JoinColumn()
  user: User

  @Column({ nullable: true, default: '' })
  phoneNumber: string

  @Column({ nullable: true, default: 0 })
  afterLoginEnum: number

  @ManyToOne(() => Languages, {
    onDelete: 'SET NULL',
    nullable: true,
  })
  @JoinColumn()
  defaultLanguage: Languages

  @Column({ nullable: true, default: '' })
  alternateEmail: string

  @ManyToOne(() => Business, (business) => business.usersDefault, {
    onDelete: 'SET NULL',
    nullable: true,
  })
  @JoinColumn()
  defaultBusiness?: Business
}
