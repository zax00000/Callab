import 'reflect-metadata'
import { DataSource } from 'typeorm'
import { Authentication } from './entity/authentication'
import { Avatar } from './entity/avatar'
import { Business } from './entity/business'
import { BusinessChanges } from './entity/businessChanges'
import { BusinessItem } from './entity/businessItem'
import { ErrorsApi } from './entity/errorsApi'
import { Floors } from './entity/floors'
import { Interface } from './entity/interface'
import { Item } from './entity/item'
import { Languages } from './entity/languages'
import { License } from './entity/license'
import { Messages } from './entity/messages'
import { PowersApi } from './entity/powersApi'
import { PowersApp } from './entity/powersApp'
import { Role } from './entity/role'
import { Rooms } from './entity/rooms'
import { RoomsMembers } from './entity/roomsMembers'
import { RoomsTypes } from './entity/roomsTypes'
import { TemporaryUser } from './entity/temporaryUser'
import { Translation } from './entity/translation'
import { User } from './entity/user'
import { UserData } from './entity/userData'
import { UserItem } from './entity/userItem'
import { UserSettings } from './entity/userSettings'

const {
  POSTGRES_HOST,
  POSTGRES_PORT,
  POSTGRES_USER,
  POSTGRES_PASSWORD,
  POSTGRES_DB,
} = process.env

export default new DataSource({
  type: 'postgres',
  port: Number(POSTGRES_PORT) || 5432,
  host: POSTGRES_HOST || 'localhost',
  username: POSTGRES_USER || 'callabapi',
  password: POSTGRES_PASSWORD || 'a23db42af2ddfb652632',
  database: POSTGRES_DB || 'callab',
  entities: [
    Business,
    Role,
    User,
    Floors,
    Avatar,
    ErrorsApi,
    Languages,
    Translation,
    Interface,
    License,
    PowersApp,
    PowersApi,
    Rooms,
    RoomsMembers,
    RoomsTypes,
    Authentication,
    UserSettings,
    TemporaryUser,
    UserData,
    Messages,
    BusinessChanges,
    Item,
    BusinessItem,
    UserItem,
  ],
  synchronize: true,
  logging: false,
  extra: {
    poolSize: 20,
    connectionTimeoutMillis: 2000,
    query_timeout: 1000,
    statement_timeout: 1000,
  },
  cache: true,
})
