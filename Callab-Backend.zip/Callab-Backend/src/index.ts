import 'source-map-support/register'
import start from './app'

start()
