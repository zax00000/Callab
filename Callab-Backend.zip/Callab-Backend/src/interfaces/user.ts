export interface UserFromToken {
  id: string
  authId: string
  superAdmin: boolean
  dashboardAdmin: boolean
  role: string
  business: string
}
