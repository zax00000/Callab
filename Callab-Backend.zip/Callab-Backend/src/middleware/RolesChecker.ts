import { NextFunction, Request, Response } from 'express'
import { UserFromToken } from '../interfaces/user'
import powersRoles from '../utils/powersRoles'

export default (powerName: string) =>
  async (req: Request, res: Response, next: NextFunction) => {
    const { superAdmin: userIsSuperAdmin, role: userRole } = <UserFromToken>(
      req.user
    )

    if (
      userIsSuperAdmin ||
      (await powersRoles.checkRolesApi(powerName, userRole))
    ) {
      return next()
    }
    return res.json({
      status: 2,
    })
  }
