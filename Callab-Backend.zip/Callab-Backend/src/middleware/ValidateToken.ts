import { NextFunction, Request, Response } from 'express'
import jwt from 'jsonwebtoken'
import { UserFromToken } from '../interfaces/user'

async function validateToken(req: Request, res: Response, next: NextFunction) {
  const authorizationHeader = req.headers.authorization
  let user

  if (!authorizationHeader) {
    return res.json({
      status: 2,
      // massage: 'User do not have permission',
    })
  }

  const token = req.headers.authorization.split(' ')[1]

  try {
    user = <{ user: UserFromToken | jwt.JwtPayload }>(
      jwt.verify(token, process.env.TOKEN_SECRET)
    )
    ;(<{ user: UserFromToken | jwt.JwtPayload }>req).user = user

    next()
  } catch (error) {
    // console.error(error.name)

    if (error.name === 'TokenExpiredError') {
      return res.json({
        status: 2,
      })
    }

    return res.json({
      status: 6,
    })
  }
}

export default validateToken
