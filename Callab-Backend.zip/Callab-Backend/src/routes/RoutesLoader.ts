import express, { Express } from 'express'
import validateToken from '../middleware/ValidateToken'
import authPublic from './public/auth'
import interfacePublic from './public/interface'
import languagePublic from './public/language'

import businessPrivate from './private/business'
import emailPrivate from './private/email'
import floorPrivate from './private/floor'
import hrPointsPrivate from './private/hrPoints'
import interfacePrivate from './private/interface'
import itemPrivate from './private/item'
import languagePrivate from './private/language'
import licensePrivate from './private/license'
import messages from './private/messages'
import powersApiPrivate from './private/powersApi'
import powersAppPrivate from './private/powersApp'
import rolePrivate from './private/role'
import roomPrivate from './private/room'
import roomTypePrivate from './private/roomType'
import statistics from './private/statistics'
import temporaryUser from './private/temporaryUser'
import userPrivate from './private/user'
import userSettingsPrivate from './private/userSettings'
import businessPublic from './public/business'
import itemPublic from './public/item'
import temporaryUserPublic from './public/temporaryUser'

export default (app: Express) => {
  authPublic(app)
  interfacePublic(app)
  languagePublic(app)
  temporaryUserPublic(app)
  businessPublic(app)
  businessPublic(app)
  itemPublic(app)

  const privateRouts = express.Router()
  privateRouts.use(validateToken)

  userPrivate(privateRouts as Express)
  userSettingsPrivate(privateRouts as Express)
  businessPrivate(privateRouts as Express)
  rolePrivate(privateRouts as Express)
  powersApiPrivate(privateRouts as Express)
  powersAppPrivate(privateRouts as Express)
  floorPrivate(privateRouts as Express)
  roomPrivate(privateRouts as Express)
  roomTypePrivate(privateRouts as Express)
  licensePrivate(privateRouts as Express)
  interfacePrivate(privateRouts as Express)
  languagePrivate(privateRouts as Express)
  statistics(privateRouts as Express)
  temporaryUser(privateRouts as Express)
  messages(privateRouts as Express)
  itemPrivate(privateRouts as Express)
  hrPointsPrivate(privateRouts as Express)
  emailPrivate(privateRouts as Express)

  app.use('/private', privateRouts)
}
