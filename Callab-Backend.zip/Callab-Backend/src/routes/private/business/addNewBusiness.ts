import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { License } from '../../../database/entity/license'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'
import addUserToBusiness from '../../../utils/addUserToBusiness'
import createDefaultsRoleInBusiness from '../../../utils/createDefaultsRoleInBusiness'

export const addNewBusiness = async (req: Request, res: Response) => {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const requireFields = [] as string[]
      ;[
        'name',
        'nip',
        'country',
        'zipCode',
        'city',
        'address1',
        'address2',
        'email',
        'phoneNumber',
        'contactName',
        'contactLastName',
        'licenseId',
      ].forEach((fieldName) => {
        if (
          !(
            req.body[fieldName] != null &&
            req.body[fieldName].toString().length > 0
          )
        ) {
          requireFields.push(fieldName)
        }
      })
      if (requireFields.length > 0) {
        return res.json({
          status: 5,
        })
      }

      const {
        name,
        nip,
        country,
        zipCode,
        city,
        address1,
        address2,
        email,
        phoneNumber,
        contactName,
        contactLastName,
        licenseId,
      } = req.body

      const { id: userId } = <UserFromToken>req.user

      const getUserPromise = transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')

        .where('user.id = :id', { id: userId })
        .getOne()

      const getLicensePromise = transactionalEntityManager
        .getRepository(License)
        .createQueryBuilder('license')
        .where('license.id = :id', { id: licenseId })
        .getOne()

      const [getUser, getLicense] = await Promise.all([
        getUserPromise,
        getLicensePromise,
      ])

      const DateNow = new Date()
      const newBusiness = new Business()
      newBusiness.license = getLicense

      newBusiness.name = name
      newBusiness.nip = nip
      newBusiness.country = country
      newBusiness.zipCode = zipCode
      newBusiness.city = city
      newBusiness.address1 = address1
      newBusiness.address2 = address2
      newBusiness.email = email.toLowerCase()
      newBusiness.phoneNumber = phoneNumber
      newBusiness.contactName = contactName
      newBusiness.contactLastName = contactLastName
      newBusiness.idUserCreated = getUser
      newBusiness.idUserModified = getUser
      newBusiness.dateCreated = DateNow
      newBusiness.dateModified = DateNow

      const newBusinessResponse = await transactionalEntityManager
        .getRepository(Business)
        .save(newBusiness)

      const adminRole = await createDefaultsRoleInBusiness(
        newBusinessResponse,
        getUser,
        transactionalEntityManager
      )

      if (adminRole != null && adminRole != false) {
        const response = await addUserToBusiness({
          businessId: newBusinessResponse.id,
          userId,
          email,
          roleId: adminRole.id,
          transactionalEntityManager,
        })
        if (response.status != 0) {
          throw new Error('invalid data')
        }
      } else {
        throw new Error('invalid data')
      }

      return res.json({
        status: 0,
        businessId: newBusinessResponse.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
