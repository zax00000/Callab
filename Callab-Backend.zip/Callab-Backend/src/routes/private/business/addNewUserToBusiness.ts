import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { User } from '../../../database/entity/user'
import { UserData } from '../../../database/entity/userData'
import { UserFromToken } from '../../../interfaces/user'
import sendMail from '../../../sendMail'
import addUserToBusinessMail from '../../../sendMail/addUserToBusinessMail'
import { checkLicenseTime } from '../../../utils/checkLicenseTime'

export const addNewUserToBusiness = async (req: Request, res: Response) => {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { businessId, newUserId, roleId } = req.body

      const {
        business: UserBusinessId,
        superAdmin: idSuperAdmin,
        id: userId,
      } = <UserFromToken>req.user

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.business', 'business')
        .leftJoinAndSelect('user.businessRoles', 'role')
        .leftJoinAndSelect('user.userData', 'userData')
        .where('user.id = :id', { id: newUserId })
        .getOne()

      if (!getUser) {
        return res.json({
          status: 3,
        })
      }

      if (getUser.superAdmin) {
        return res.json({
          status: 8,
        })
      }

      const getBusiness = await transactionalEntityManager
        .getRepository(Business)
        .createQueryBuilder('business')
        .leftJoinAndSelect('business.roles', 'role')
        .leftJoinAndSelect('business.users', 'user')
        .leftJoinAndSelect('business.license', 'license')
        .where('business.id = :id', {
          id: idSuperAdmin ? businessId : UserBusinessId,
        })
        .getOne()

      if (!getBusiness) {
        return res.json({
          status: 3,
        })
      }

      if (checkLicenseTime(getBusiness.license)) {
        return res.json({
          status: 7,
        })
      }

      if (
        getBusiness.license.maxUsersInBusiness !== 0 &&
        getBusiness.users &&
        getBusiness.users.length >= getBusiness.license.maxUsersInBusiness
      ) {
        return res.json({
          status: 7,
        })
      }

      const roleToAdd = getBusiness.roles.find((role) =>
        role != null ? role.id === roleId : false
      )

      if (!roleToAdd) {
        return res.json({
          status: 3,
        })
      }

      getUser.business = [...getUser.business, getBusiness]
      if (getUser.businessRoles == null) {
        getUser.businessRoles = [roleToAdd]
      } else {
        getUser.businessRoles = [...getUser.businessRoles, roleToAdd]
      }

      const user = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()

      getUser.idUserModified = user
      getUser.dateModified = new Date()

      const newUserData = new UserData()
      newUserData.business = getBusiness
      newUserData.user = getUser

      if (getUser?.userData != null && getUser.userData.length > 0) {
        getUser.userData = [...getUser.userData, newUserData]
      } else {
        getUser.userData = [newUserData]
      }
      const newUserResponse = await transactionalEntityManager
        .getRepository(User)
        .save(getUser)

      sendMail.sendMail({
        to: newUserResponse.email,
        subject: `User has been added to ${getBusiness.name} business`,
        text: `User has been added to ${getBusiness.name} business`,
        html: addUserToBusinessMail(getBusiness.name),
      })
      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
