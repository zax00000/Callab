import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { UserFromToken } from '../../../interfaces/user'

export const deleteBusiness = async (req: Request, res: Response) => {
  try {
    const { businessId } = req.params
    const { business: userBusinessID, superAdmin: idSuperAdmin } = <
      UserFromToken
    >req.user

    await db
      .createQueryBuilder()
      .delete()
      .from(Business)
      .where('id = :id', { id: idSuperAdmin ? businessId : userBusinessID })
      .execute()

    return res.json({
      status: 0,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
