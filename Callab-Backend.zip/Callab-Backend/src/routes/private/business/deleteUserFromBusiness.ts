import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'

export const deleteUserFromBusiness = async (req: Request, res: Response) => {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { id: userId, businessId } = req.params
      const {
        business: userBusinessID,
        superAdmin: idSuperAdmin,
        id: idUserChanger,
      } = <UserFromToken>req.user

      const getUsersBusiness = await transactionalEntityManager
        .getRepository(Business)
        .createQueryBuilder('business')
        .leftJoinAndSelect('business.users', 'user')
        .where('business.id = :id', {
          id: idSuperAdmin ? businessId : userBusinessID,
        })
        .getOne()

      getUsersBusiness.users = getUsersBusiness.users.filter(
        (user) => user.id !== userId
      )

      const user = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: idUserChanger })
        .getOne()

      getUsersBusiness.idUserModified = user
      getUsersBusiness.dateModified = new Date()
      await transactionalEntityManager
        .getRepository(Business)
        .save(getUsersBusiness)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
