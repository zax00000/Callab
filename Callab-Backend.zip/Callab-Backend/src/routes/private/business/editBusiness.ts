import crypto from 'crypto'
import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { BusinessChanges } from '../../../database/entity/businessChanges'
import { License } from '../../../database/entity/license'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'
import sendMail from '../../../sendMail'
import changeBusinessData from '../../../sendMail/changeBusinessData'

export async function editBusiness(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { businessId } = req.params

      const {
        business: userBusinessID,
        superAdmin: idSuperAdmin,
        id: userId,
      } = <UserFromToken>req.user

      const getBusinessBeforeChange = await transactionalEntityManager
        .getRepository(Business)
        .createQueryBuilder('business')
        .where('business.id = :id', {
          id: idSuperAdmin ? businessId : userBusinessID,
        })
        .getOne()

      const getBusiness = { ...getBusinessBeforeChange }

      if (!getBusiness) {
        return res.json({
          status: 3,
        })
      }

      ;[
        'nip',
        'name',
        'country',
        'zipCode',
        'city',
        'address1',
        'address2',
        'phoneNumber',
        'contactName',
        'contactLastName',
      ].forEach((fieldName) => {
        const filed = req.body[fieldName]
        if (filed) {
          getBusiness[fieldName as 'nip'] = filed
        }
      })
      const { license, email } = req.body
      if (req.body.email) {
        getBusiness.email = email.toLowerCase()
      }

      if (license != null) {
        let getLicense = await transactionalEntityManager
          .getRepository(License)
          .createQueryBuilder('license')
          .where('license.id = :id', { id: license })
          .getOne()
        getBusiness.license = getLicense
      }

      const user = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()

      getBusiness.idUserModified = user
      getBusiness.dateModified = new Date()

      if (idSuperAdmin == null) {
        const dataToSave: BusinessChanges = {
          ...getBusiness,
          changesToken: crypto.randomUUID(),
          business: getBusiness,
          userEmail: user.email,
          userId: user.id,
          dateModification: new Date(),
        }

        await transactionalEntityManager
          .getRepository(BusinessChanges)
          .save(dataToSave)

        const { email, name } = getBusinessBeforeChange

        sendMail.sendMail({
          to: email,
          subject: 'Change business data',
          text: 'Change business data',
          html: changeBusinessData(
            dataToSave.userEmail,
            name,
            dataToSave.changesToken
          ),
        })

        return res.json({
          status: 0,
        })
      }
      await transactionalEntityManager.getRepository(Business).save(getBusiness)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
