import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'

export async function getAllBusinessPaginationSearch(
  req: Request,
  res: Response
) {
  try {
    const { skip, take, search } = req.params

    const getAllBusiness = await db
      .getRepository(Business)
      .createQueryBuilder('business')
      .leftJoinAndSelect('business.license', 'license')
      .leftJoinAndSelect('business.idUserCreated', 'idUserCreated')
      .leftJoinAndSelect('business.idUserModified', 'idUserModified')
      .select([
        'business',
        'license',
        'idUserCreated.email',
        'idUserModified.email',
      ])
      .where('business.name ILIKE :searchQuery', { searchQuery: `%${search}%` })
      .skip(Number(skip))
      .take(Number(take))
      .getMany()

    const getBusinessCount = await db
      .getRepository(Business)
      .createQueryBuilder('business')
      .where('business.name ILIKE :searchQuery', { searchQuery: `%${search}%` })
      .getCount()

    return res.json({
      status: 0,
      business: getAllBusiness.map((business) => ({
        ...business,
        license: business.license.name,
        idUserCreated: business.idUserCreated
          ? business.idUserCreated.email
          : '',
        idUserModified: business.idUserModified
          ? business.idUserModified.email
          : '',
      })),
      count: getBusinessCount,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
