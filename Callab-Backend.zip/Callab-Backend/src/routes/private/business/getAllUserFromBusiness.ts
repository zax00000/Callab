import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'

export const getAllUserFromBusiness = async (req: Request, res: Response) => {
  try {
    const { businessId: adminBusinessId } = req.params

    const { business: businessId, superAdmin: idSuperAdmin } = <UserFromToken>(
      req.user
    )

    const businessIdChecked = idSuperAdmin ? adminBusinessId : businessId

    const getUsersBusiness = await db
      .getRepository(Business)
      .createQueryBuilder('business')
      .leftJoinAndSelect('business.users', 'user')
      .leftJoinAndSelect('user.avatar', 'avatar')
      .leftJoinAndSelect('user.userData', 'userData')
      .leftJoinAndSelect('userData.items', 'items')
      .leftJoinAndSelect('items.businessItem', 'businessItem')
      .leftJoinAndSelect('businessItem.item', 'item')
      .leftJoinAndSelect('userData.business', 'businessFormUserData')
      .leftJoinAndSelect('user.businessRoles', 'businessRoles')
      .leftJoinAndSelect('businessRoles.business', 'businessInRole')
      .select([
        'business.id',
        'user.avatar',
        'user.id',
        'user.email',
        'user.isDeveloper',
        'user.isLogged',
        'avatar.id',
        'avatar.avatar',
        'avatar.dateModified',
        'userData.business',
        'businessFormUserData.id',
        'userData.firstName',
        'userData.surName',
        'userData.hrPoints',
        'items.id',
        'items.posX',
        'items.posY',
        'items.scale',
        'items.selected',
        'businessItem.id',
        'item.name',
        'item.pictureUrl',
        'item.type',
        'item.description',
        'businessRoles.id',
        'businessInRole.id',
      ])
      .where('business.id = :id', {
        id: businessIdChecked,
      })
      .getOne()

    if (getUsersBusiness == null) {
      return res.json({
        status: 3,
      })
    }

    const userInBusiness = getUsersBusiness.users
      .map((user: User) => {
        const userData = user.userData.find(
          (userData) => userData.business.id === businessIdChecked
        )

        return {
          id: user.id,
          email: user.email,
          firstName: userData?.firstName || '',
          surName: userData?.surName || '',
          isLogged: user.isLogged,
          isDeveloper: user.isDeveloper,
          avatar: user.avatar?.id || null,
          hrPoints: userData?.hrPoints || 0,
          avatarImage: user.avatar?.avatar || null,
          avatarDateModification: user.avatar?.dateModified || null,
          roleId: (
            user.businessRoles.find((role) =>
              role != null ? role.business.id === businessIdChecked : false
            ) || { id: '' }
          ).id,
          items: userData?.items
            .filter((item) => item.selected)
            .map((item) => ({
              id: item?.id,
              businessItemId: item?.businessItem?.id,
              itemName: item?.businessItem?.item.name,
              itemPictureUrl: item?.businessItem?.item.pictureUrl,
              itemType: item?.businessItem?.item.type,
              itemPosX: item.posX,
              itemPosY: item.posY,
              itemScale: item.scale,
              selected: true,
              description: item?.businessItem?.item.description,
            })),
        }
      })
      .sort((user1, user2) =>
        (user1.firstName + user1.surName).localeCompare(
          user2.firstName + user2.surName
        )
      )

    return res.json({
      status: 0,
      userInBusiness,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
