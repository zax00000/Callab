import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { User } from '../../../database/entity/user'

export const getAllUserFromBusinessPagination = async (
  req: Request,
  res: Response
) => {
  try {
    const { businessId, skip, take } = req.params

    const getUsersBusiness = await db
      .getRepository(Business)
      .createQueryBuilder('business')
      .leftJoinAndSelect('business.users', 'user')
      .leftJoinAndSelect('user.userData', 'userData')
      .leftJoinAndSelect('userData.business', 'businessForUserData')
      .leftJoinAndSelect('user.businessRoles', 'businessRoles')
      .leftJoinAndSelect('businessRoles.business', 'businessFromRoles')
      .where('business.id = :id', {
        id: businessId,
      })
      .select([
        'business.id',
        'user.id',
        'user.email',
        'userData.firstName',
        'userData.surName',
        'userData.hrPoints',
        'businessForUserData.id',
        'businessRoles.id',
        'businessRoles.name',
        'businessFromRoles.id',
      ])
      .getOne()

    if (getUsersBusiness == null) {
      return res.json({
        status: 3,
      })
    }

    const userInBusiness = getUsersBusiness.users
      .map((user: User) => {
        const userData = user.userData.find(
          (userData) => userData.business.id === businessId
        )
        return {
          id: user.id,
          email: user.email,
          firstName: userData?.firstName || '',
          surName: userData?.surName || '',
          hrPoints: userData?.hrPoints || 0,
          role: user.businessRoles.find(
            ({ business }) => business.id === businessId
          ),
        }
      })
      .sort((user1, user2) =>
        (user1.firstName + user1.surName).localeCompare(
          user2.firstName + user2.surName
        )
      )
      .slice(Number(skip), Number(take) + Number(skip))

    return res.json({
      status: 0,
      userInBusiness,
      count: getUsersBusiness.users.length,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
