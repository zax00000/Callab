import { Express } from 'express'
import RolesChecker from '../../../middleware/RolesChecker'
import { addNewBusiness } from './addNewBusiness'
import { addNewUserToBusiness } from './addNewUserToBusiness'
import { deleteBusiness } from './deleteBusiness'
import { deleteUserFromBusiness } from './deleteUserFromBusiness'
import { editBusiness } from './editBusiness'
import { getAllBusinessPagination } from './getAllBusinessPagination'
import { getAllBusinessPaginationSearch } from './getAllBusinessPaginationSearch'
import { getAllUserFromBusiness } from './getAllUserFromBusiness'
import { getAllUserFromBusinessPagination } from './getAllUserFromBusinessPagination'
import { getAllUserFromBusinessPaginationSearch } from './getAllUserFromBusinessPaginationSearch'
import { getAllUserFromBusinessSearch } from './getAllUserFromBusinessSearch'
import { selectBusinessForUser } from './selectBusinessForUser'

export default (app: Express) => {
  /**
   * @openapi
   * /private/business/user/select:
   *  post:
   *    tags:
   *      - business
   *    description: Select user business.
   *    summary: Select user business.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/SelectBusiness'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  SelectBusiness:           # <----------
   *    type: object
   *    required:
   *      - businessId
   *    properties:
   *      businessId:
   *        type: string
   */
  app.post('/business/user/select', selectBusinessForUser)

  /**
   * @openapi
   * /private/business:
   *  post:
   *    tags:
   *      - business
   *    description: Add new business.
   *    summary: Add new business.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/AddBusiness'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  AddBusiness:           # <----------
   *    type: object
   *    required:
   *      - name
   *      - nip
   *      - country
   *      - zipCode
   *      - city
   *      - address1
   *      - address2
   *      - email
   *      - phoneNumber
   *      - contactName
   *      - contactLastName
   *      - licenseId
   *    properties:
   *      name:
   *        type: string
   *      nip:
   *        type: string
   *      country:
   *        type: string
   *      zipCode:
   *        type: string
   *      city:
   *        type: string
   *      address1:
   *        type: string
   *      address2:
   *        type: string
   *      email:
   *        type: string
   *      phoneNumber:
   *        type: string
   *      contactName:
   *        type: string
   *      contactLastName:
   *        type: string
   *      licenseId:
   *        type: string
   */
  app.post('/business', RolesChecker('AddNewBusiness'), addNewBusiness)

  /**
   * @openapi
   * /private/business/user/new:
   *  post:
   *    tags:
   *      - business
   *    description: Add new user to business.
   *    summary: Add new user to business.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/AddUserToBusiness'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  AddUserToBusiness:           # <----------
   *    type: object
   *    required:
   *      - newUserId
   *    properties:
   *      newUserId:
   *        type: string
   *      businessId:
   *        type: string
   *      roleId:
   *        type: string
   */
  app.post(
    '/business/user/new',
    RolesChecker('AddNewUserToBusiness'),
    addNewUserToBusiness
  )

  /**
   * @openapi
   * /private/users/business/{businessId}:
   *  get:
   *    tags:
   *      - business
   *    description: Get all users in business.
   *    summary: Get all users in business.
   *    parameters:
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/users/business/:businessId',
    RolesChecker('GetAllUserFromBusiness'),
    getAllUserFromBusiness
  )

  /**
   * @openapi
   * /private/pagin/users/business/{businessId}/{skip}/{take}:
   *  get:
   *    tags:
   *      - business
   *    description: Get all users in business pagination.
   *    summary: Get all users in business pagination.
   *    parameters:
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *      - in: path
   *        name: skip
   *        schema:
   *          type: string
   *      - in: path
   *        name: take
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/pagin/users/business/:businessId/:skip/:take',
    RolesChecker('GetAllUserFromBusiness'),
    getAllUserFromBusinessPagination
  )

  /**
   * @openapi
   * /private/pagin/users/business/{businessId}/{skip}/{take}/search/{search}:
   *  get:
   *    tags:
   *      - business
   *    description: Get all users in business pagination.
   *    summary: Get all users in business pagination.
   *    parameters:
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *      - in: path
   *        name: skip
   *        schema:
   *          type: string
   *      - in: path
   *        name: take
   *        schema:
   *          type: string
   *      - in: path
   *        name: search
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/pagin/users/business/:businessId/:skip/:take/search/:search',
    RolesChecker('GetAllUserFromBusinessPaginationSearch'),
    getAllUserFromBusinessPaginationSearch
  )

  /**
   * @openapi
   * /private/search/users/business/{businessId}/{search}:
   *  get:
   *    tags:
   *      - business
   *    description: Get all users in business search.
   *    summary: Get all users in business search.
   *    parameters:
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *      - in: path
   *        name: search
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/search/users/business/:businessId/:search',
    RolesChecker('GetAllUserFromBusiness'),
    getAllUserFromBusinessSearch
  )

  /**
   * @openapi
   * /private/business/{businessId}/user/{id}:
   *  delete:
   *    tags:
   *      - business
   *    description: Delete user form business.
   *    summary: Delete user form business.
   *    parameters:
   *      - in: path
   *        name: id
   *        schema:
   *          type: string
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.delete(
    '/business/:businessId/user/:id',
    RolesChecker('DeleteUserFormBusiness'),
    deleteUserFromBusiness
  )

  /**
   * @openapi
   * /private/business/{businessId}:
   *  delete:
   *    tags:
   *      - business
   *    description: Delete business.
   *    summary: Delete business.
   *    parameters:
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.delete(
    '/business/:businessId',
    RolesChecker('DeleteBusiness'),
    deleteBusiness
  )

  /**
   * @openapi
   * /private/business/{businessId}:
   *  post:
   *    tags:
   *      - business
   *    description: Edit business.
   *    summary: Edit business.
   *    parameters:
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/EditBusiness'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  EditBusiness:           # <----------
   *    type: object
   *    properties:
   *      nip:
   *        type: string
   *      name:
   *        type: string
   *      country:
   *        type: string
   *      zipCode:
   *        type: string
   *      city:
   *        type: string
   *      address1:
   *        type: string
   *      address2:
   *        type: string
   *      email:
   *        type: string
   *      phoneNumber:
   *        type: string
   *      contactName:
   *        type: string
   *      contactLastName:
   *        type: string
   *      license:
   *        type: string
   */

  app.post('/business/:businessId', RolesChecker('EditBusiness'), editBusiness)

  /**
   * @openapi
   * /private/pagin/business/{skip}/{take}:
   *  get:
   *    tags:
   *      - business
   *    description: Get all business with pagination.
   *    summary: Get all business with pagination.
   *    parameters:
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/pagin/business/:skip/:take',
    RolesChecker('GetAllBusinessPagination'),
    getAllBusinessPagination
  )

  /**
   * @openapi
   * /private/pagin/business/{skip}/{take}/search/{search}:
   *  get:
   *    tags:
   *      - business
   *    description: Get all business with pagination.
   *    summary: Get all business with pagination.
   *    parameters:
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *      - in: path
   *        name: search
   *        schema:
   *          type: number
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/pagin/business/:skip/:take/search/:search',
    RolesChecker('GetAllBusinessPaginationSearch'),
    getAllBusinessPaginationSearch
  )
}
