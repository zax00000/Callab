import { Request, Response } from 'express'
import jwt from 'jsonwebtoken'
import db from '../../../database'
import { Authentication } from '../../../database/entity/authentication'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'
import { checkLicenseTime } from '../../../utils/checkLicenseTime'

export const selectBusinessForUser = async (req: Request, res: Response) => {
  try {
    const { businessId } = req.body

    const { id: userId, authId } = <UserFromToken>req.user

    const getUser = await db
      .getRepository(User)
      .createQueryBuilder('user')
      .leftJoinAndSelect('user.business', 'business')
      .leftJoinAndSelect('business.license', 'license')
      .leftJoinAndSelect('business.roles', 'role')
      .where('user.id = :id', { id: userId })
      .getOne()

    const getUserBusinessRoles = await db
      .getRepository(User)
      .createQueryBuilder('user')
      .leftJoinAndSelect('user.businessRoles', 'role')
      .where('user.id = :id', { id: userId })
      .getOne()

    const userIsInBusiness = getUser.business.find(({ id }: { id: string }) => {
      return id === businessId
    })

    if (userIsInBusiness == null) {
      return res.json({
        status: 3,
      })
    }

    if (checkLicenseTime(userIsInBusiness.license)) {
      return res.json({
        status: 7,
      })
    }

    const activeRole = userIsInBusiness.roles.find(({ id }) =>
      getUserBusinessRoles.businessRoles.some((role) =>
        role != null ? role.id === id : false
      )
    )

    if (activeRole == null) {
      return res.json({
        status: 3,
      })
    }

    let tokenUser
    if (getUser.superAdmin) {
      return res.json({
        status: 8,
      })
    } else {
      tokenUser = {
        id: getUser.id,
        role: activeRole.id,
        business: businessId,
        authId: authId,
      }
    }
    const accessToken = jwt.sign(tokenUser, process.env.TOKEN_SECRET, {
      expiresIn: 300,
    })

    const UserAuthentication = await db
      .getRepository(Authentication)
      .createQueryBuilder('authentication')
      .where('authentication.id = :id', { id: authId })
      .getOne()

    await db
      .createQueryBuilder()
      .update(Authentication)
      .set({
        activeBusinessRole: activeRole.id,
        activeBusiness: businessId,
      })
      .where('id = :id', { id: authId })
      .execute()

    return res.json({
      status: 0,
      accessToken,
      refreshToken: UserAuthentication.refreshToken,
      roleID: activeRole.id,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
