import { Express } from 'express'
import RolesChecker from '../../../middleware/RolesChecker'
import { sendEmail } from './sendEmail'

export default (app: Express) => {
  /**
   * @openapi
   * /private/email:
   *  post:
   *    tags:
   *      - email
   *    description: Send Email.
   *    summary: Send Email.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/sendEmail'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  sendEmail:           # <----------
   *    type: object
   *    properties:
   *      to:
   *        type: string
   *      replyTo:
   *        type: string
   *      subject:
   *        type: string
   *      text:
   *        type: string
   *      errorLog:
   *        type: string
   *      userMessage:
   *        type: string
   *      userData:
   *        type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.post('/email', RolesChecker('SendEmail'), sendEmail)
}
