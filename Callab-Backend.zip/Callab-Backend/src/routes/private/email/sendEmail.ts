import { Request, Response } from 'express'
import sendMail from '../../../sendMail'
import defaultEmail from '../../../sendMail/defaultEmail'

export async function sendEmail(req: Request, res: Response) {
  const { to, replyTo, subject, text, errorLog, userMessage, userData } =
    req.body
  try {
    sendMail.sendMail({
      to: to,
      replyTo: replyTo,
      subject: subject,
      text: text,
      html: defaultEmail({ errorLog, userMessage, userData }),
    })

    return res.json({
      status: 0,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
