import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Floors } from '../../../database/entity/floors'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'
import { checkLicenseTime } from '../../../utils/checkLicenseTime'

export async function addNewFloor(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const {
        business: UserBusinessId,
        superAdmin: idSuperAdmin,
        id: userId,
      } = <UserFromToken>req.user

      const { businessId, properties, width } = req.body

      const getBusiness = await transactionalEntityManager
        .getRepository(Business)
        .createQueryBuilder('business')
        .leftJoinAndSelect('business.floors', 'floors')
        .leftJoinAndSelect('business.license', 'license')
        .where('business.id = :id', {
          id: idSuperAdmin ? businessId : UserBusinessId,
        })
        .getOne()

      if (checkLicenseTime(getBusiness.license)) {
        return res.json({
          status: 7,
        })
      }

      if (
        getBusiness.license.maxFloorInBusiness !== 0 &&
        getBusiness.floors &&
        getBusiness.floors.length >= getBusiness.license.maxFloorInBusiness
      ) {
        return res.json({
          status: 7,
        })
      }

      if (!getBusiness) {
        return res.json({
          status: 3,
        })
      }

      if (
        !properties ||
        !Array.isArray(properties) ||
        !(properties.length > 0) ||
        Number.isNaN(Number(width))
      ) {
        return res.json({
          status: 4,
        })
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      const newFloor = new Floors()

      const newDate = new Date()
      newFloor.business = getBusiness
      newFloor.width = Number(width)
      newFloor.properties = properties
      newFloor.idUserCreated = getUser
      newFloor.idUserModified = getUser
      newFloor.dateModified = newDate
      newFloor.dateCreated = newDate
      newFloor.floorNumber =
        getBusiness.floors != null ? getBusiness.floors.length + 1 : 1

      const newFloorResponse = await transactionalEntityManager
        .getRepository(Floors)
        .save(newFloor)

      return res.json({
        status: 0,
        floorId: newFloorResponse.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
