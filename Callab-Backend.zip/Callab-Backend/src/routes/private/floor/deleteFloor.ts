import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Floors } from '../../../database/entity/floors'
import { UserFromToken } from '../../../interfaces/user'

export async function deleteFloor(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { floorId: removedFloorId } = req.params

      const { business: businessId, superAdmin: idSuperAdmin } = <
        UserFromToken
      >req.user

      if (!idSuperAdmin) {
        const getBusiness = await transactionalEntityManager
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.floors', 'floor')
          .where('business.id = :id', {
            id: businessId,
          })
          .getOne()
        if (!getBusiness.floors.some((floor) => floor.id === removedFloorId)) {
          return res.json({
            status: 3,
          })
        }
      }

      const getFloor = await transactionalEntityManager
        .getRepository(Floors)
        .createQueryBuilder('floors')
        .leftJoinAndSelect('floors.business', 'business')
        .where('floors.id = :id', {
          id: removedFloorId,
        })
        .getOne()

      const removedFloorBusinessId = getFloor.business.id

      await transactionalEntityManager.getRepository(Floors).remove(getFloor)

      const getBusiness = await transactionalEntityManager
        .getRepository(Business)
        .createQueryBuilder('business')
        .leftJoinAndSelect('business.floors', 'floors')
        .where('business.id = :id', {
          id: removedFloorBusinessId,
        })
        .getOne()

      await Promise.all(
        getBusiness.floors
          .sort(
            (a, b) =>
              new Date(a.dateCreated).getTime() -
              new Date(b.dateCreated).getTime()
          )
          .map(async (floors, index) => {
            floors.floorNumber = index + 1
            return transactionalEntityManager.getRepository(Floors).save(floors)
          })
      )

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
