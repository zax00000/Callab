import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Floors } from '../../../database/entity/floors'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'

export async function editFloor(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const {
        business: UserBusinessId,
        superAdmin: idSuperAdmin,
        id: userId,
      } = <UserFromToken>req.user

      const { properties, width } = req.body

      const { floorId } = req.params

      if (!idSuperAdmin) {
        const getBusiness = await transactionalEntityManager
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.floors', 'floors')
          .where('business.id = :id', {
            id: UserBusinessId,
          })
          .getOne()

        if (!getBusiness.floors.some((floor) => floor.id === floorId)) {
          return res.json({
            status: 3,
          })
        }
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      const getFloor = await transactionalEntityManager
        .getRepository(Floors)
        .createQueryBuilder('floors')
        .where('floors.id = :id', {
          id: floorId,
        })
        .getOne()

      const newDate = new Date()
      if (!Number.isNaN(Number(width))) {
        getFloor.width = Number(width)
      }
      if (
        properties != null ||
        Array.isArray(properties) ||
        properties.length > 0
      ) {
        getFloor.properties = properties
      }
      getFloor.idUserModified = getUser
      getFloor.dateModified = newDate

      const newFloorResponse = await transactionalEntityManager
        .getRepository(Floors)
        .save(getFloor)

      await db.queryResultCache.remove([floorId])

      return res.json({
        status: 0,
        floorId: newFloorResponse.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
