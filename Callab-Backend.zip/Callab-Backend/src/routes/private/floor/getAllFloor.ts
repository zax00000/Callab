import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { UserFromToken } from '../../../interfaces/user'

export async function getAllFloor(req: Request, res: Response) {
  try {
    const { business: UserBusinessId, superAdmin: idSuperAdmin } = <
      UserFromToken
    >req.user

    const { businessId } = req.params

    const getBusiness = await db
      .getRepository(Business)
      .createQueryBuilder('business')
      .leftJoinAndSelect('business.floors', 'floor')
      .where('business.id = :id', {
        id: idSuperAdmin ? businessId : UserBusinessId,
      })
      .getOne()

    if (!getBusiness) {
      return res.json({
        status: 3,
      })
    }
    return res.json({
      status: 0,
      floors: getBusiness.floors.sort(
        (a, b) =>
          new Date(a.dateCreated).getTime() - new Date(b.dateCreated).getTime()
      ),
    })
  } catch (error) {
    if (error.message.includes('invalid input syntax for type uuid')) {
      return res.json({
        status: 3,
      })
    }
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
