import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'

export async function getAllFloorPaginationForBusiness(
  req: Request,
  res: Response
) {
  try {
    const { businessId, skip, take } = req.params

    const getBusiness = await db
      .getRepository(Business)
      .createQueryBuilder('business')
      .leftJoinAndSelect('business.floors', 'floor')
      .leftJoinAndSelect('floor.idUserCreated', 'userCreated')
      .leftJoinAndSelect('floor.idUserModified', 'userModified')
      .where('business.id = :id', {
        id: businessId,
      })
      .getOne()

    if (!getBusiness) {
      return res.json({
        status: 3,
      })
    }
    return res.json({
      status: 0,
      floors: getBusiness.floors
        .sort(
          (a, b) =>
            new Date(a.dateCreated).getTime() -
            new Date(b.dateCreated).getTime()
        )
        .slice(Number(skip), Number(take) + Number(skip))
        .map((floor) => ({
          ...floor,
          idUserCreated: undefined,
          idUserModified: undefined,
          userCreated: floor.idUserCreated ? floor.idUserCreated.email : '',
          userModified: floor.idUserModified ? floor.idUserModified.email : '',
        })),
      count: getBusiness.floors.length,
    })
  } catch (error) {
    if (error.message.includes('invalid input syntax for type uuid')) {
      return res.json({
        status: 3,
      })
    }
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
