import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Floors } from '../../../database/entity/floors'
import { UserFromToken } from '../../../interfaces/user'

export async function getFloor(req: Request, res: Response) {
  try {
    const { business: UserBusinessId, superAdmin: idSuperAdmin } = <
      UserFromToken
    >req.user

    const floorId = req.params.floorId

    if (!idSuperAdmin) {
      const getBusiness = await db
        .getRepository(Business)
        .createQueryBuilder('business')
        .leftJoinAndSelect('business.floors', 'floor')
        .where('business.id = :id', {
          id: UserBusinessId,
        })
        .getOne()
      if (!getBusiness.floors.some((floor) => floor.id === floorId)) {
        return res.json({
          status: 3,
        })
      }
    }

    const getFloor = await db
      .getRepository(Floors)
      .createQueryBuilder('floors')
      .leftJoinAndSelect('floors.rooms', 'rooms')
      .leftJoinAndSelect('rooms.types', 'RoomsTypes')
      .leftJoinAndSelect('rooms.roomMembers', 'RoomsMembers')
      .where('floors.id = :id', {
        id: floorId,
      })
      .getOne()

    return res.json({
      status: 0,
      floor: getFloor,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
