import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Floors } from '../../../database/entity/floors'
import { UserFromToken } from '../../../interfaces/user'

export async function getFloorWithTime(req: Request, res: Response) {
  try {
    const { business: UserBusinessId, superAdmin: idSuperAdmin } = <
      UserFromToken
    >req.user
    const { floorId, time } = req.params
    const { floorsId } = req.body

    const getFloor = await db
      .getRepository(Floors)
      .createQueryBuilder('floors')
      .leftJoinAndSelect('floors.business', 'business')
      .select([
        'floors.dateModified',
        'floors.id',
        'floors.properties',
        'floors.floorNumber',
        'floors.width',
        'business.id',
      ])
      .where('floors.id = :id', {
        id: floorId,
      })
      .cache(floorId, 1000 * 60 * 60)
      .getOne()

    if (!idSuperAdmin && getFloor.business.id !== UserBusinessId) {
      return res.json({
        status: 3,
      })
    }

    const checkNewFloor = await db
      .getRepository(Business)
      .createQueryBuilder('business')
      .leftJoinAndSelect('business.floors', 'floors')
      .select(['business.id', 'floors.id'])
      .where('business.id = :idFloor', {
        idFloor: getFloor.business.id,
      })
      .getOne()

    const UserDoNotHaveFloorsId = checkNewFloor.floors.filter(
      (floor) =>
        !(floorsId != null ? floorsId : []).some(
          (floorId: string) => floorId === floor.id
        )
    )

    const UserHaveToMatchFloorsId = (floorsId != null ? floorsId : []).filter(
      (floorId: string) =>
        !checkNewFloor.floors.some((floor) => floorId === floor.id)
    )

    if (
      (UserDoNotHaveFloorsId != null && UserDoNotHaveFloorsId.length > 0) ||
      (UserHaveToMatchFloorsId != null && UserHaveToMatchFloorsId.length > 0)
    ) {
      return res.json({
        status: 70,
      })
    }

    if (new Date(getFloor.dateModified).getTime() <= new Date(time).getTime()) {
      return res.json({
        status: 69,
      })
    }
    return res.json({
      status: 0,
      floor: { ...getFloor, business: undefined },
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
