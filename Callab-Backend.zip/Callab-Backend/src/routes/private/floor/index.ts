import { Express } from 'express'
import RolesChecker from '../../../middleware/RolesChecker'
import { addNewFloor } from './addNewFloor'
import { deleteFloor } from './deleteFloor'
import { editFloor } from './editFloor'
import { getAllFloor } from './getAllFloor'
import { getAllFloorPaginationForBusiness } from './getAllFloorPaginationForBusiness'
import { getFloor } from './getFloor'
import { getFloorWithTime } from './getFloorWithTime'

export default (app: Express) => {
  /**
   * @openapi
   * /private/floor/{floorId}:
   *  delete:
   *    tags:
   *      - floor
   *    description: Delete floor.
   *    summary: Delete floor.
   *    parameters:
   *      - in: path
   *        name: floorId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.delete('/floor/:floorId', RolesChecker('DeleteFloor'), deleteFloor)

  /**
   * @openapi
   * /private/floor/new:
   *  post:
   *    tags:
   *      - floor
   *    description: Create Floor
   *    summary: Create Floor
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/NewFloor'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  NewFloor:           # <----------
   *    type: object
   *    required:
   *      - properties
   *    properties:
   *      businessId:
   *        type: string
   *      width:
   *        type: number
   *      properties:
   *        type: array
   *        items:
   *          type: integer
   */
  app.post('/floor/new', RolesChecker('AddNewFloor'), addNewFloor)

  /**
   * @openapi
   * /private/floor/{floorId}:
   *  post:
   *    tags:
   *      - floor
   *    description: Edit Floor
   *    summary: Edit Floor
   *    parameters:
   *      - in: path
   *        name: floorId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/EditFloor'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  EditFloor:           # <----------
   *    type: object
   *    properties:
   *      width:
   *        type: number
   *      properties:
   *        type: array
   *        items:
   *          type: integer
   */
  app.post('/floor/:floorId', RolesChecker('EditFloor'), editFloor)

  /**
   * @openapi
   * /private/floor/{floorId}:
   *  get:
   *    tags:
   *      - floor
   *    description: Get Floor.
   *    summary: Get Floor.
   *    parameters:
   *      - in: path
   *        name: floorId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/floor/:floorId', RolesChecker('GetFloor'), getFloor)

  /**
   * @openapi
   * /private/floor/{floorId}/time/{time}:
   *  post:
   *    tags:
   *      - floor
   *    description: Get Floor with check time.
   *    summary: Get Floor with check time.
   *    parameters:
   *      - in: path
   *        name: floorId
   *        schema:
   *          type: string
   *      - in: path
   *        name: time
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/getFloorWithTime'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  getFloorWithTime:           # <----------
   *    type: object
   *    properties:
   *      floorsId:
   *        type: array
   *        items:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.post(
    '/floor/:floorId/time/:time',
    RolesChecker('GetFloorWithTime'),
    getFloorWithTime
  )

  /**
   * @openapi
   * /private/floor/business/{businessId}:
   *  get:
   *    tags:
   *      - floor
   *    description: Get all floor in business.
   *    summary: Get all floor business.
   *    parameters:
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/floor/business/:businessId',
    RolesChecker('GetAllFloor'),
    getAllFloor
  )

  /**
   * @openapi
   * /private/pagin/floor/business/{businessId}/{skip}/{take}:
   *  get:
   *    tags:
   *      - floor
   *    description: Get all floor in business pagination.
   *    summary: Get all floor business pagination.
   *    parameters:
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/pagin/floor/business/:businessId/:skip/:take',
    RolesChecker('GetAllFloorPaginationForBusiness'),
    getAllFloorPaginationForBusiness
  )
}
