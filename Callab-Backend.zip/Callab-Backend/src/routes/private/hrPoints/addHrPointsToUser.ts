import { Request, Response } from 'express'
import { UserData } from '../../../database/entity/userData'

import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { User } from '../../../database/entity/user'

export async function addHrPointsToUser(req: Request, res: Response) {
  try {
    const { userId, points, businessId } = req.body

    return await db.transaction(async (transactionalEntityManager) => {
      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.userData', 'userData')
        .leftJoinAndSelect('userData.business', 'businessForUserData')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      let userData = getUser.userData.find(
        (data) => data.business.id === businessId
      )

      if (Number.isNaN(Number(points))) {
        return res.json({
          status: 4,
        })
      }

      if (userData == null) {
        const getBusiness = await transactionalEntityManager
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('business.id = :id', {
            id: businessId,
          })
          .getOne()

        userData = new UserData()
        userData.business = getBusiness
        userData.user = getUser
        userData.hrPoints = 0
      }

      userData.hrPoints = Number.isFinite(userData.hrPoints + Number(points))
        ? userData.hrPoints + Number(points)
        : userData.hrPoints

      await transactionalEntityManager.getRepository(UserData).save(userData)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
