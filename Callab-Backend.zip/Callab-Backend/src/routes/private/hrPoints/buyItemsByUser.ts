import { Request, Response } from 'express'
import db from '../../../database'
import { BusinessItem } from '../../../database/entity/businessItem'
import { User } from '../../../database/entity/user'
import { UserData } from '../../../database/entity/userData'
import { UserItem } from '../../../database/entity/userItem'
import { UserFromToken } from '../../../interfaces/user'

export async function buyItemsByUser(req: Request, res: Response) {
  try {
    const { businessItemsId } = req.body

    const { business: UserBusinessId, id: userId } = <UserFromToken>req.user
    if (!Array.isArray(businessItemsId) || !(businessItemsId.length > 0)) {
      return res.json({
        status: 4,
      })
    }

    return await db.transaction(async (transactionalEntityManager) => {
      const getUserPromise = transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.userData', 'userData')
        .leftJoinAndSelect('userData.business', 'businessForUserData')
        .leftJoinAndSelect('userData.items', 'items')
        .leftJoinAndSelect('items.businessItem', 'businessItem')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      const getItemsPromise = transactionalEntityManager
        .getRepository(BusinessItem)
        .createQueryBuilder('businessItem')
        .leftJoinAndSelect('businessItem.business', 'business')
        .where('businessItem.id IN (:...ids)', {
          ids: businessItemsId,
        })
        .getMany()

      const [getUser, getItems] = await Promise.all([
        getUserPromise,
        getItemsPromise,
      ])

      const userData = getUser.userData.find(
        (data) => data.business.id === UserBusinessId
      )

      if (userData == null) {
        return res.json({
          status: 5,
        })
      }

      const filteredItems = getItems.filter(
        (item) =>
          !userData.items.some(
            (userItem) => userItem.businessItem.id === item.id
          )
      )

      const sumValueOfItems = filteredItems.reduce(
        (price, item) => price + item.price,
        0
      )

      if (userData.hrPoints < sumValueOfItems) {
        return res.json({
          status: 5,
        })
      }

      userData.hrPoints = userData.hrPoints - sumValueOfItems

      const dateNow = new Date()

      const newItems = await Promise.all(
        filteredItems.map(async (item) => {
          const newUserItem = new UserItem()

          newUserItem.businessItem = item
          newUserItem.userData = userData
          newUserItem.dateCreated = dateNow
          newUserItem.dateModified = dateNow
          newUserItem.idUserCreated = getUser
          newUserItem.idUserModified = getUser
          return await transactionalEntityManager
            .getRepository(UserItem)
            .save(newUserItem)
        })
      )

      if (userData?.items && userData?.items?.length > 0) {
        userData.items = [...userData.items, ...newItems]
      } else {
        userData.items = [...newItems]
      }

      await transactionalEntityManager.getRepository(UserData).save(userData)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
