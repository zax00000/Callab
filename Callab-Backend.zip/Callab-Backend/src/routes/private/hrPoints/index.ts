import { Express } from 'express'
import RolesChecker from '../../../middleware/RolesChecker'
import { addHrPointsToUser } from './addHrPointsToUser'
import { addHrPointsToUsers } from './addHrPointsToUsers'
import { buyItemsByUser } from './buyItemsByUser'

export default (app: Express) => {
  /**
   * @openapi
   * /private/hr-points/add:
   *  post:
   *    tags:
   *      - hrPoints
   *    description: Add hr-points to user.
   *    summary: Add hr-points to user.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/AddHrPoints'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  AddHrPoints:           # <----------
   *    type: object
   *    properties:
   *      userId:
   *        type: string
   *      points:
   *        type: number
   *      businessId:
   *        type: string
   */
  app.post('/hr-points/add', RolesChecker('addHrPoints'), addHrPointsToUser)

  /**
   * @openapi
   * /private/hr-points/users/add:
   *  post:
   *    tags:
   *      - hrPoints
   *    description: Add hr-points to users.
   *    summary: Add hr-points to users.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/AddHrPointsUsers'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  AddHrPointsUsers:           # <----------
   *    type: object
   *    properties:
   *      usersId:
   *        type: array
   *        items:
   *          type: string
   *      points:
   *        type: number
   *      businessId:
   *        type: string
   */
  app.post(
    '/hr-points/users/add',
    RolesChecker('addHrPoints'),
    addHrPointsToUsers
  )

  /**
   * @openapi
   * /private/buy-item:
   *  post:
   *    tags:
   *      - hrPoints
   *    description: Buy item.
   *    summary: Buy item.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/BuyItem'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  BuyItem:           # <----------
   *    type: object
   *    properties:
   *      businessItemsId:
   *        type: array
   *        items:
   *          type: string
   */
  app.post('/buy-item', RolesChecker('buyItem'), buyItemsByUser)
}
