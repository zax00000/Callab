import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Interface } from '../../../database/entity/interface'
import { Languages } from '../../../database/entity/languages'
import { Translation } from '../../../database/entity/translation'
import { User } from '../../../database/entity/user'

export async function addInterface(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { name, translations } = req.body
      const newInterface = new Interface()
      const { id: userId } = <UserFromToken>req.user

      const DateNow = new Date()

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()

      if (translations != null && translations.length > 0) {
        const newTranslation = await Promise.all(
          translations.map(
            async (translation: {
              languageId: number
              translation: string
            }) => {
              const newTranslation = new Translation()

              const getLanguage = await transactionalEntityManager
                .getRepository(Languages)
                .createQueryBuilder('languages')
                .where('languages.id = :id', { id: translation.languageId })
                .getOne()

              if (getLanguage == null) {
                return {
                  error: true,
                }
              }

              newTranslation.dateCreated = DateNow
              newTranslation.dateModified = DateNow
              newTranslation.idUserCreated = getUser
              newTranslation.idUserModified = getUser
              newTranslation.language = getLanguage
              newTranslation.translation = translation.translation
              const editedInterfaceResponsePromise = transactionalEntityManager
                .getRepository(Translation)
                .save(newTranslation)
              return editedInterfaceResponsePromise
            }
          )
        )

        if (newTranslation.some((element) => element.error === true)) {
          return res.json({
            status: 3,
          })
        }
        newInterface.translation = newTranslation
      }
      newInterface.dateCreated = DateNow
      newInterface.dateModified = DateNow
      newInterface.idUserCreated = getUser
      newInterface.idUserModified = getUser
      newInterface.name = name

      const newInterfaceResponse = await transactionalEntityManager
        .getRepository(Interface)
        .save(newInterface)
      return res.json({
        status: 0,
        interfaceId: newInterfaceResponse.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
