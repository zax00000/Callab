import { Request, Response } from 'express'
import db from '../../../database'
import { Interface } from '../../../database/entity/interface'

export async function deleteInterface(req: Request, res: Response) {
  try {
    const { interfaceId } = req.params

    await db
      .createQueryBuilder()
      .delete()
      .from(Interface)
      .where('id = :id', {
        id: interfaceId,
      })
      .execute()

    return res.json({
      status: 0,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
