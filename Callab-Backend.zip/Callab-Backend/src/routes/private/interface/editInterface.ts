import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Interface } from '../../../database/entity/interface'
import { Languages } from '../../../database/entity/languages'
import { Translation } from '../../../database/entity/translation'
import { User } from '../../../database/entity/user'

export async function editInterface(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { name, translations } = req.body
      const { interfaceId } = req.params

      const { id: userId } = <UserFromToken>req.user

      const editedInterface = await transactionalEntityManager
        .getRepository(Interface)
        .createQueryBuilder('interface')
        .leftJoinAndSelect('interface.translation', 'translation')
        .leftJoinAndSelect('translation.language', 'language')
        .where('interface.id = :id', { id: interfaceId })
        .getOne()
      const DateNow = new Date()

      if (editedInterface == null) {
        return res.json({
          status: 3,
        })
      }
      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()

      if (translations != null && translations.length > 0) {
        await Promise.all(
          translations.map(
            async (translation: {
              languageId: string
              translation: string
            }) => {
              const translationIndex = editedInterface.translation.findIndex(
                (element: Translation) => {
                  return element.language.id === translation.languageId
                }
              )
              if (translationIndex === -1) {
                const newTranslation = new Translation()

                const getLanguage = await transactionalEntityManager
                  .getRepository(Languages)
                  .createQueryBuilder('languages')
                  .where('languages.id = :id', {
                    id: translation.languageId,
                  })
                  .getOne()
                if (getLanguage == null) {
                  return
                }
                newTranslation.dateCreated = DateNow
                newTranslation.dateModified = DateNow
                newTranslation.idUserCreated = getUser
                newTranslation.idUserModified = getUser
                newTranslation.language = getLanguage
                newTranslation.interfaces = editedInterface
                newTranslation.translation = translation.translation

                await transactionalEntityManager
                  .getRepository(Translation)
                  .save(newTranslation)

                editedInterface.translation.push(newTranslation)
              } else {
                editedInterface.translation[translationIndex].translation =
                  translation.translation
                await transactionalEntityManager
                  .getRepository(Translation)
                  .save(editedInterface.translation[translationIndex])
              }
            }
          )
        )
      }

      editedInterface.dateModified = DateNow
      editedInterface.idUserModified = getUser
      if (name != null) {
        editedInterface.name = name
      }
      const editedInterfaceResponse = await transactionalEntityManager
        .getRepository(Interface)
        .save(editedInterface)
      return res.json({
        status: 0,
        interfaceId: editedInterfaceResponse.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
