import { Request, Response } from 'express'
import db from '../../../database'
import { Interface } from '../../../database/entity/interface'

export async function getAllInterfacesPagination(req: Request, res: Response) {
  try {
    const { skip, take } = req.params

    const getInterfaces = await db
      .getRepository(Interface)
      .createQueryBuilder('interface')
      .leftJoinAndSelect('interface.translation', 'translation')
      .leftJoinAndSelect('interface.idUserCreated', 'userCreated')
      .leftJoinAndSelect('interface.idUserModified', 'userModified')
      .select([
        'interface.id',
        'interface.name',
        'interface.dateModified',
        'interface.dateCreated',
        'userCreated.email',
        'userModified.email',
      ])
      .orderBy('interface.dateModified', 'DESC')
      .skip(Number(skip))
      .take(Number(take))
      .getMany()

    const count = await db
      .getRepository(Interface)
      .createQueryBuilder('interface')
      .getCount()

    return res.json({
      status: 0,
      interfaces: getInterfaces.map((oneInterface) => ({
        ...oneInterface,
        idUserCreated: undefined,
        idUserModified: undefined,
        userCreated: oneInterface.idUserCreated
          ? oneInterface.idUserCreated.email
          : '',
        userModified: oneInterface.idUserModified
          ? oneInterface.idUserModified.email
          : '',
      })),
      count,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
