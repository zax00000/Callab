import { Request, Response } from 'express'
import db from '../../../database'
import { Interface } from '../../../database/entity/interface'

export async function getAllInterfacesSearch(req: Request, res: Response) {
  try {
    const { search, skip, take } = req.params

    const getInterfaces = await db
      .getRepository(Interface)
      .createQueryBuilder('interface')
      .leftJoinAndSelect('interface.translation', 'translation')
      .leftJoinAndSelect('interface.idUserCreated', 'userCreated')
      .leftJoinAndSelect('interface.idUserModified', 'userModified')
      .leftJoinAndSelect('translation.language', 'language')
      .orderBy('interface.dateModified', 'DESC')
      .where('interface.name ILIKE :searchQuery', {
        searchQuery: `%${search}%`,
      })
      .skip(Number(skip))
      .take(Number(take))
      .getMany()

    const count = await db
      .getRepository(Interface)
      .createQueryBuilder('interface')
      .where('interface.name ILIKE :searchQuery', {
        searchQuery: `%${search}%`,
      })
      .getCount()

    return res.json({
      status: 0,
      interfaces: getInterfaces.map((oneInterface) => ({
        ...oneInterface,
        idUserCreated: undefined,
        idUserModified: undefined,
        userCreated: oneInterface.idUserCreated
          ? oneInterface.idUserCreated.email
          : '',
        userModified: oneInterface.idUserModified
          ? oneInterface.idUserModified.email
          : '',
      })),
      count,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
