import { Request, Response } from 'express'
import db from '../../../database'
import { Interface } from '../../../database/entity/interface'

export async function getInterfaceTranslation(req: Request, res: Response) {
  try {
    const { interfaceId } = req.params

    const getInterface = await db
      .getRepository(Interface)
      .createQueryBuilder('interface')
      .leftJoinAndSelect('interface.translation', 'translation')
      .leftJoinAndSelect('translation.language', 'language')
      .leftJoinAndSelect('translation.idUserCreated', 'userCreated')
      .leftJoinAndSelect('translation.idUserModified', 'userModified')
      .where('interface.id = :id', { id: interfaceId })
      .getOne()

    return res.json({
      status: 0,
      translations: getInterface.translation.map((translation) => ({
        ...translation,
        idUserCreated: undefined,
        idUserModified: undefined,
        userCreated: translation.idUserCreated
          ? translation.idUserCreated.email
          : '',
        userModified: translation.idUserModified
          ? translation.idUserModified.email
          : '',
      })),
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
