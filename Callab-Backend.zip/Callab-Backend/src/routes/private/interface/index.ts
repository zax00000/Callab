import { Express } from 'express'
import RolesChecker from '../../../middleware/RolesChecker'
import { addInterface } from './addInterface'
import { deleteInterface } from './deleteInterface'
import { editInterface } from './editInterface'
import { getAllInterfacesPagination } from './getAllInterfacesPagination'
import { getAllInterfacesSearch } from './getAllInterfacesSearch'
import { getInterfaceTranslation } from './getInterfaceTranslation'

export default (app: Express) => {
  /**
   * @openapi
   * /private/interface/{interfaceId}:
   *  delete:
   *    tags:
   *      - interface
   *    description: Delete Interface.
   *    summary: Delete Interface.
   *    parameters:
   *      - in: path
   *        name: InterfaceId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.delete(
    '/interface/:interfaceId',
    RolesChecker('DeleteInterface'),
    deleteInterface
  )

  /**
   * @openapi
   * /private/interface/new:
   *  post:
   *    tags:
   *      - interface
   *    description: Create Interface
   *    summary:  Create interface
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/NewInterface'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  NewInterface:           # <----------
   *    type: object
   *    required:
   *      - name
   *      - nameEnum
   *    properties:
   *      name:
   *        type: string
   *      nameEnum:
   *        type: number
   *      translations:
   *        type: array
   *        items:
   *          type: object
   *          properties:
   *            languageId:
   *              type: string
   *            translation:
   *              type: string
   */
  app.post('/interface/new', RolesChecker('AddInterface'), addInterface)

  /**
   * @openapi
   * /private/interface/{interfaceId}:
   *  post:
   *    tags:
   *      - interface
   *    description: Edit interface
   *    summary: Edit interface
   *    parameters:
   *      - in: path
   *        name: interfaceId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/EditInterface'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  EditInterface:           # <----------
   *    type: object
   *    properties:
   *      name:
   *        type: string
   *      translations:
   *        type: array
   *        items:
   *          type: object
   *          properties:
   *            languageId:
   *              type: string
   *            translation:
   *              type: string
   */
  app.post(
    '/interface/:interfaceId',
    RolesChecker('EditInterface'),
    editInterface
  )

  /**
   * @openapi
   * /private/pagin/interface/{skip}/{take}:
   *  get:
   *    tags:
   *      - interface
   *    description: Get all interface with pagination.
   *    summary: Get all interface with pagination.
   *    parameters:
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/pagin/interface/:skip/:take',
    RolesChecker('GetAllInterfacePagination'),
    getAllInterfacesPagination
  )

  /**
   * @openapi
   * /private/search/interface/{search}/{skip}/{take}:
   *  get:
   *    tags:
   *      - interface
   *    description: Get all interface with pagination and search.
   *    summary: Get all interface with pagination and search.
   *    parameters:
   *      - in: path
   *        name: search
   *        schema:
   *          type: string
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/search/interface/:search/:skip/:take',
    RolesChecker('GetAllInterfaceSearch'),
    getAllInterfacesSearch
  )

  /**
   * @openapi
   * /private/translation/interface/{interfaceId}:
   *  get:
   *    tags:
   *      - interface
   *    description: Get all translation for interface.
   *    summary: Get all translation for interface.
   *    parameters:
   *      - in: path
   *        name: interfaceId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/translation/interface/:interfaceId',
    RolesChecker('GetInterfaceTranslation'),
    getInterfaceTranslation
  )
}
