import { Request, Response } from 'express'
import fs from 'fs'
import path from 'path'
import { Item } from '../../../database/entity/item'

import db from '../../../database'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'

export async function addItem(req: Request, res: Response) {
  try {
    const { name, type, defaultPrice, description } = req.body

    const tempPath = req.file.path

    const { id: userId } = <UserFromToken>req.user

    const targetPath = path.join(
      __dirname,
      `/static/itemPicture/${new Date().getTime()}-${req.file.originalname}`
    )

    return await db.transaction(async (transactionalEntityManager) => {
      if (
        name == null ||
        name.length === 0 ||
        type == null ||
        Number.isNaN(Number(type)) ||
        defaultPrice == null ||
        Number.isNaN(Number(defaultPrice))
      ) {
        try {
          fs.unlinkSync(tempPath)
          return res.json({
            status: 4,
          })
        } catch (error) {
          console.error(error.message)
        }
      }

      let filePath = ''
      const fileExtname = path.extname(req.file.originalname).toLowerCase()
      if (
        fileExtname === '.png' ||
        fileExtname === '.jpg' ||
        fileExtname === '.gif'
      ) {
        await new Promise((resolve) => {
          fs.rename(tempPath, targetPath, (error) => {
            if (error) {
              console.error(error)
            }
            filePath = targetPath.replace(
              path.join(__dirname, '/static/itemPicture/'),
              ''
            )
            resolve(0)
          })
        })

        if (filePath.length === 0) {
          return res.json({
            status: 6,
          })
        }

        const getUser = await transactionalEntityManager
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.id = :id', { id: userId })
          .getOne()

        const dateNow = new Date()
        const newItem = new Item()
        newItem.name = name
        if (description != null && description.length > 0) {
          newItem.description = description
        }
        newItem.type = Number(type)
        newItem.defaultPrice = Number(defaultPrice)
        newItem.pictureUrl = filePath
        newItem.idUserCreated = getUser
        newItem.dateCreated = dateNow
        newItem.idUserModified = getUser
        newItem.dateModified = dateNow

        await transactionalEntityManager.getRepository(Item).save(newItem)

        return res.json({
          status: 0,
        })
      } else {
        return res.json({
          status: 4,
        })
      }
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
