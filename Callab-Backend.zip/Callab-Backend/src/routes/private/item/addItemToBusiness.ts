import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { BusinessItem } from '../../../database/entity/businessItem'
import { Item } from '../../../database/entity/item'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'

export async function addItemToBusiness(req: Request, res: Response) {
  const { itemId, businessId, canBeBought, price } = req.body

  const { id: userId, business, superAdmin } = <UserFromToken>req.user

  if (!superAdmin && business !== businessId) {
    return res.json({
      status: 4,
    })
  }

  try {
    return await db.transaction(async (transactionalEntityManager) => {
      if (
        businessId == null ||
        businessId.length === 0 ||
        itemId == null ||
        itemId.length === 0
      ) {
        return res.json({
          status: 4,
        })
      }

      const getBusiness = await transactionalEntityManager
        .getRepository(Business)
        .createQueryBuilder('business')
        .leftJoinAndSelect('business.items', 'items')
        .leftJoinAndSelect('items.item', 'item')
        .where('business.id = :id', { id: businessId })
        .getOne()

      const itemIsInBusiness = getBusiness.items?.some(
        (item) => item.item.id === itemId
      )

      if (itemIsInBusiness) {
        return res.json({
          status: 8,
        })
      }

      const getItem = await transactionalEntityManager
        .getRepository(Item)
        .createQueryBuilder('item')
        .where('item.id = :id', { id: itemId })
        .getOne()

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()

      if (getItem == null) {
        return res.json({
          status: 4,
        })
      }

      const dateNow = new Date()
      const newBusinessItem = new BusinessItem()

      newBusinessItem.item = getItem
      newBusinessItem.business = getBusiness
      newBusinessItem.canBeBought = canBeBought
      newBusinessItem.price = Number(price) || getItem.defaultPrice
      newBusinessItem.idUserCreated = getUser
      newBusinessItem.dateCreated = dateNow
      newBusinessItem.idUserModified = getUser
      newBusinessItem.dateModified = dateNow

      await transactionalEntityManager
        .getRepository(BusinessItem)
        .save(newBusinessItem)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
