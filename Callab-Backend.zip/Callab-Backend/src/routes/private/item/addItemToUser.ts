import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { BusinessItem } from '../../../database/entity/businessItem'
import { User } from '../../../database/entity/user'
import { UserData } from '../../../database/entity/userData'
import { UserItem } from '../../../database/entity/userItem'
import { UserFromToken } from '../../../interfaces/user'

export async function addItemToUser(req: Request, res: Response) {
  try {
    const { businessItemId, businessId, userId } = req.body

    const { id: userIdFromToken } = <UserFromToken>req.user

    return await db.transaction(async (transactionalEntityManager) => {
      const getUserModifiedPromise = transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userIdFromToken,
        })
        .getOne()

      const getUserPromise = transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.userData', 'userData')
        .leftJoinAndSelect('userData.business', 'businessForUserData')
        .leftJoinAndSelect('userData.items', 'items')
        .leftJoinAndSelect('items.businessItem', 'businessItem')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      const getItemPromise = transactionalEntityManager
        .getRepository(BusinessItem)
        .createQueryBuilder('businessItem')
        .leftJoinAndSelect('businessItem.business', 'business')
        .where('businessItem.id = :id', {
          id: businessItemId,
        })
        .getOne()

      const [getUser, getItem, getUserModified] = await Promise.all([
        getUserPromise,
        getItemPromise,
        getUserModifiedPromise,
      ])

      let userData = getUser.userData.find(
        (data) => data.business.id === businessId
      )

      if (userData?.items.some((item) => item.businessItem.id === getItem.id)) {
        return res.json({
          status: 8,
        })
      }

      if (userData == null) {
        const getBusiness = await transactionalEntityManager
          .getRepository(Business)
          .createQueryBuilder('business')
          .where('business.id = :id', {
            id: businessId,
          })
          .getOne()

        userData = new UserData()
        userData.business = getBusiness
        userData.user = getUser
        userData.hrPoints = 0

        await transactionalEntityManager.getRepository(UserData).save(userData)
      }

      const dateNow = new Date()
      const newUserItem = new UserItem()

      newUserItem.businessItem = getItem
      newUserItem.userData = userData
      newUserItem.dateCreated = dateNow
      newUserItem.dateModified = dateNow
      newUserItem.idUserCreated = getUserModified
      newUserItem.idUserModified = getUserModified

      await transactionalEntityManager.getRepository(UserItem).save(newUserItem)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
