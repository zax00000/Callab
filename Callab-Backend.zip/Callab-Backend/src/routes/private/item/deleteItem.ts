import console from 'console'
import { Request, Response } from 'express'
import fs from 'fs'
import db from '../../../database'
import { Item } from '../../../database/entity/item'
import { UserData } from '../../../database/entity/userData'

export async function deleteItem(req: Request, res: Response) {
  try {
    const { itemId } = req.params

    return await db.transaction(async (transactionalEntityManager) => {
      const getRemovingItem = await transactionalEntityManager
        .getRepository(Item)
        .createQueryBuilder('item')
        .leftJoinAndSelect('item.businessItem', 'businessItem')
        .leftJoinAndSelect('businessItem.userItem', 'userItem')
        .leftJoinAndSelect('userItem.userData', 'userData')
        .where('item.id = :id', { id: itemId })
        .getOne()

      const userDataToCashBack = getRemovingItem.businessItem.map((item) => ({
        price: item.price,
        userData: item.userItem.map((userItem) => ({
          data: userItem.userData,
        })),
      }))

      await Promise.all(
        userDataToCashBack.map(async ({ userData, price }) => {
          return Promise.all(
            userData.map(async ({ data }) => {
              if (data != null) {
                data.hrPoints += price
                return transactionalEntityManager
                  .getRepository(UserData)
                  .save(data)
              }
            })
          )
        })
      )

      await transactionalEntityManager
        .getRepository(Item)
        .remove(getRemovingItem)

      try {
        fs.unlinkSync(
          __dirname + `/static/itemPicture/${getRemovingItem.pictureUrl}`
        )
      } catch (error) {
        console.error(error.message)
      }

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
