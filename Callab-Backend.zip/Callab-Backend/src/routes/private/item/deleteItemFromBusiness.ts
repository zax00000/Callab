import { Request, Response } from 'express'
import db from '../../../database'
import { BusinessItem } from '../../../database/entity/businessItem'
import { UserData } from '../../../database/entity/userData'

export async function deleteItemFromBusiness(req: Request, res: Response) {
  try {
    const { businessItemId } = req.params

    return await db.transaction(async (transactionalEntityManager) => {
      const getRemovingItemFromBusiness = await transactionalEntityManager
        .getRepository(BusinessItem)
        .createQueryBuilder('businessItem')
        .leftJoinAndSelect('businessItem.userItem', 'userItem')
        .leftJoinAndSelect('userItem.userData', 'userData')
        .where('businessItem.id = :id', { id: businessItemId })
        .getOne()

      const userDataToCashBack = {
        price: getRemovingItemFromBusiness.price,
        userData: getRemovingItemFromBusiness.userItem.map((userItem) => ({
          data: userItem.userData,
        })),
      }

      await Promise.all(
        userDataToCashBack.userData.map(async ({ data }) => {
          if (data != null) {
            data.hrPoints += userDataToCashBack.price
            return transactionalEntityManager.getRepository(UserData).save(data)
          }
        })
      )

      await transactionalEntityManager
        .getRepository(BusinessItem)
        .remove(getRemovingItemFromBusiness)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
