import { Request, Response } from 'express'
import db from '../../../database'
import { UserData } from '../../../database/entity/userData'
import { UserItem } from '../../../database/entity/userItem'

export async function deleteItemFromUser(req: Request, res: Response) {
  try {
    const { userId, userItemId } = req.params

    return await db.transaction(async (transactionalEntityManager) => {
      const getRemovingItemFromUser = await transactionalEntityManager
        .getRepository(UserItem)
        .createQueryBuilder('userItem')
        .leftJoinAndSelect('userItem.businessItem', 'businessItem')
        .leftJoinAndSelect('userItem.userData', 'userData')
        .where('userItem.id = :id', { id: userItemId })
        .select([
          'userItem.id',
          'businessItem.id',
          'businessItem.price',
          'userData.id',
          'userData.hrPoints',
        ])
        .getOne()

      const userData = getRemovingItemFromUser.userData
      userData.hrPoints += getRemovingItemFromUser.businessItem.price

      await transactionalEntityManager.getRepository(UserData).save(userData)

      await transactionalEntityManager
        .getRepository(UserItem)
        .remove(getRemovingItemFromUser)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
