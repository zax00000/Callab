import { Request, Response } from 'express'
import fs from 'fs'
import path from 'path'
import db from '../../../database'
import { BusinessItem } from '../../../database/entity/businessItem'
import { Item } from '../../../database/entity/item'
import { User } from '../../../database/entity/user'
import { UserData } from '../../../database/entity/userData'
import { UserFromToken } from '../../../interfaces/user'

export async function editItem(req: Request, res: Response) {
  try {
    const { name, type, defaultPrice, description } = req.body
    const { itemId } = req.params

    const tempPath = req.file?.path
    const originalname = req.file?.originalname

    const { id: userId } = <UserFromToken>req.user

    return await db.transaction(async (transactionalEntityManager) => {
      const getItem = await transactionalEntityManager
        .getRepository(Item)
        .createQueryBuilder('item')
        .leftJoinAndSelect('item.businessItem', 'businessItem')
        .leftJoinAndSelect('businessItem.userItem', 'userItem')
        .leftJoinAndSelect('userItem.userData', 'userData')
        .where('item.id = :id', { id: itemId })
        .getOne()

      if (getItem == null) {
        return res.json({
          status: 4,
        })
      }
      let filePath = ''
      if (tempPath != null) {
        const targetPath = path.join(
          __dirname,
          `./static/itemPicture/${new Date().getTime()}-${originalname}`
        )
        const fileExtname = path.extname(originalname).toLowerCase()
        if (
          fileExtname === '.png' ||
          fileExtname === '.jpg' ||
          fileExtname === '.gif'
        ) {
          await new Promise((resolve) => {
            fs.rename(tempPath, targetPath, (error) => {
              if (error) {
                throw error
              }
              filePath = targetPath.replace(
                path.join(__dirname, '/static/itemPicture/'),
                ''
              )
              resolve(0)
            })
          })
          if (filePath.length === 0) {
            return res.json({
              status: 6,
            })
          }
        } else {
          try {
            fs.unlinkSync(tempPath)
          } catch (error) {
            console.error(error.message)
          }
        }
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()
      const dateNow = new Date()

      if (name != null && name.length > 0) {
        getItem.name = name
      }

      if (type != null && !Number.isNaN(Number(type))) {
        getItem.type = Number(type)
      }

      if (defaultPrice != null && !Number.isNaN(Number(defaultPrice))) {
        const oldDefaultPrice = getItem.defaultPrice
        getItem.defaultPrice = Number(defaultPrice)
        await Promise.all(
          getItem.businessItem.map(async (item) => {
            item.price = defaultPrice
            return transactionalEntityManager
              .getRepository(BusinessItem)
              .save(item)
          })
        )

        if (oldDefaultPrice > getItem.defaultPrice) {
          const userDataToCashBack = getItem.businessItem.map((item) => ({
            price: oldDefaultPrice - getItem.defaultPrice,
            userData: item.userItem.map((userItem) => ({
              data: userItem.userData,
            })),
          }))

          await Promise.all(
            userDataToCashBack.map(async ({ userData, price }) => {
              return Promise.all(
                userData.map(async ({ data }) => {
                  if (data != null) {
                    data.hrPoints += price
                    return transactionalEntityManager
                      .getRepository(UserData)
                      .save(data)
                  }
                })
              )
            })
          )
        }
      }

      if (filePath.length > 0) {
        try {
          fs.unlinkSync(
            path.join(__dirname + `/static/itemPicture/${getItem.pictureUrl}`)
          )
        } catch (error) {
          console.error(error.message)
        }

        getItem.pictureUrl = filePath
      }

      if (description != null) {
        getItem.description = description
      }

      getItem.idUserModified = getUser
      getItem.dateModified = dateNow

      const editedItem = await transactionalEntityManager
        .getRepository(Item)
        .save(getItem)

      return res.json({
        status: 0,
        item: editedItem,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
