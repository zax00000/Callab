import { Request, Response } from 'express'
import db from '../../../database'
import { BusinessItem } from '../../../database/entity/businessItem'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'

export async function editItemInBusiness(req: Request, res: Response) {
  const { canBeBought } = req.body
  const { businessItemId } = req.params

  const { id: userId, business, superAdmin } = <UserFromToken>req.user

  try {
    return await db.transaction(async (transactionalEntityManager) => {
      if (businessItemId == null || businessItemId.length === 0) {
        return res.json({
          status: 4,
        })
      }

      const getItemInBusiness = await transactionalEntityManager
        .getRepository(BusinessItem)
        .createQueryBuilder('businessItem')
        .leftJoinAndSelect('businessItem.business', 'business')
        .where('businessItem.id = :id', { id: businessItemId })
        .getOne()

      if (!superAdmin && business !== getItemInBusiness.business.id) {
        return res.json({
          status: 4,
        })
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()

      if (getItemInBusiness == null) {
        return res.json({
          status: 4,
        })
      }

      const dateNow = new Date()

      if (canBeBought != null) {
        getItemInBusiness.canBeBought = canBeBought
      }

      getItemInBusiness.idUserModified = getUser
      getItemInBusiness.dateModified = dateNow

      await transactionalEntityManager
        .getRepository(BusinessItem)
        .save(getItemInBusiness)
      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
