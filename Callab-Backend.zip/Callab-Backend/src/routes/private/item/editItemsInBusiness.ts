import { Request, Response } from 'express'
import db from '../../../database'
import { BusinessItem } from '../../../database/entity/businessItem'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'

export async function editItemsInBusiness(req: Request, res: Response) {
  const { businessItems } = req.body as {
    businessItems: [{ businessItemId: string; canBeBought: boolean }]
  }

  const { id: userId, business, superAdmin } = <UserFromToken>req.user

  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const itemsId = businessItems.map((item) => item.businessItemId)
      const getItemsInBusiness = await transactionalEntityManager
        .getRepository(BusinessItem)
        .createQueryBuilder('businessItem')
        .leftJoinAndSelect('businessItem.business', 'business')
        .where('businessItem.id IN (:...ids)', { ids: itemsId })
        .getMany()

      if (
        getItemsInBusiness == null ||
        getItemsInBusiness.length === 0 ||
        (!superAdmin && business !== getItemsInBusiness[0].business.id)
      ) {
        return res.json({
          status: 4,
        })
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()

      const dateNow = new Date()

      await Promise.all(
        getItemsInBusiness.map(async (item) => {
          const itemCanBeBought = businessItems.find(
            (businessItem) => businessItem.businessItemId === item.id
          )

          if (
            itemCanBeBought.canBeBought === true ||
            itemCanBeBought.canBeBought === false
          ) {
            item.canBeBought = itemCanBeBought.canBeBought
            item.idUserModified = getUser
            item.dateModified = dateNow

            await transactionalEntityManager
              .getRepository(BusinessItem)
              .save(item)
          }
        })
      )

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
