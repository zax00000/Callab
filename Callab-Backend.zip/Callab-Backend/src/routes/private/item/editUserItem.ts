import { Request, Response } from 'express'
import db from '../../../database'
import { User } from '../../../database/entity/user'
import { UserItem } from '../../../database/entity/userItem'
import { UserFromToken } from '../../../interfaces/user'

export async function editUserItem(req: Request, res: Response) {
  const { itemPosX, itemPosY, itemScale, selected } = req.body
  const { userItemId } = req.params

  const { id: userId, business, superAdmin } = <UserFromToken>req.user

  try {
    return await db.transaction(async (transactionalEntityManager) => {
      if (userItemId == null || userItemId.length === 0) {
        return res.json({
          status: 4,
        })
      }

      const getUserItem = await transactionalEntityManager
        .getRepository(UserItem)
        .createQueryBuilder('userItem')
        .leftJoinAndSelect('userItem.businessItem', 'businessItem')
        .leftJoinAndSelect('businessItem.business', 'business')
        .where('userItem.id = :id', { id: userItemId })
        .getOne()

      if (!superAdmin && business !== getUserItem.businessItem.business.id) {
        return res.json({
          status: 4,
        })
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()

      if (getUser == null) {
        return res.json({
          status: 4,
        })
      }

      const dateNow = new Date()

      if (itemPosX != null && !Number.isNaN(Number(itemPosX))) {
        getUserItem.posX = Number(itemPosX)
      }

      if (itemPosY != null && !Number.isNaN(Number(itemPosY))) {
        getUserItem.posY = Number(itemPosY)
      }
      if (itemScale != null && !Number.isNaN(Number(itemScale))) {
        getUserItem.scale = Number(itemScale)
      }

      if (selected === false || selected === true) {
        getUserItem.selected = selected
      }

      await transactionalEntityManager.getRepository(UserItem).save(getUserItem)
      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
