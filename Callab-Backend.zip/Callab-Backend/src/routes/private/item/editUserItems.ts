import { Request, Response } from 'express'
import db from '../../../database'
import { User } from '../../../database/entity/user'
import { UserItem } from '../../../database/entity/userItem'
import { UserFromToken } from '../../../interfaces/user'

export async function editUserItems(req: Request, res: Response) {
  const { items } = req.body as {
    items: {
      itemId: string
      itemPosX: number
      itemPosY: number
      itemScale: number
      selected: boolean
    }[]
  }

  const { id: userId, business, superAdmin } = <UserFromToken>req.user

  try {
    return await db.transaction(async (transactionalEntityManager) => {
      if (items == null || items.length === 0) {
        return res.json({
          status: 4,
        })
      }

      const userItemId = items.map(({ itemId }) => itemId)
      const getUserItems = await transactionalEntityManager
        .getRepository(UserItem)
        .createQueryBuilder('userItem')
        .leftJoinAndSelect('userItem.businessItem', 'businessItem')
        .leftJoinAndSelect('businessItem.business', 'business')
        .where('userItem.id IN (:...ids)', { ids: userItemId })
        .getMany()

      if (
        getUserItems?.length === 0 ||
        (!superAdmin && business !== getUserItems[0].businessItem.business.id)
      ) {
        return res.json({
          status: 4,
        })
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()

      if (getUser == null) {
        return res.json({
          status: 4,
        })
      }

      const dateNow = new Date()

      await Promise.all(
        getUserItems.map(async (item) => {
          const { itemPosX, itemPosY, itemScale, selected } = items.find(
            (itemToFind) => itemToFind.itemId === item.id
          )

          if (itemPosX != null && !Number.isNaN(Number(itemPosX))) {
            item.posX = Number(itemPosX)
          }

          if (itemPosY != null && !Number.isNaN(Number(itemPosY))) {
            item.posY = Number(itemPosY)
          }
          if (itemScale != null && !Number.isNaN(Number(itemScale))) {
            item.scale = Number(itemScale)
          }

          if (selected === false || selected === true) {
            item.selected = selected
          }

          item.dateModified = dateNow
          item.idUserModified = getUser

          return transactionalEntityManager.getRepository(UserItem).save(item)
        })
      )

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
