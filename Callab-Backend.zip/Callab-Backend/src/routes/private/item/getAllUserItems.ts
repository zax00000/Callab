import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'

import db from '../../../database'
import { User } from '../../../database/entity/user'

export async function getAllUserItems(req: Request, res: Response) {
  try {
    const { userId, businessId } = req.params

    const {
      id: userIdFromToken,
      business: businessIdFromToken,
      superAdmin,
    } = <UserFromToken>req.user

    if (
      !superAdmin &&
      userId != userIdFromToken &&
      businessId != businessIdFromToken
    ) {
      return res.json({
        status: 4,
      })
    }

    return await db.transaction(async (transactionalEntityManager) => {
      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.userData', 'userData')
        .leftJoinAndSelect('userData.business', 'business')
        .leftJoinAndSelect('userData.items', 'items')
        .leftJoinAndSelect('items.businessItem', 'businessItem')
        .leftJoinAndSelect('businessItem.item', 'item')
        .where('user.id = :id', { id: userId })
        .getOne()

      const userData = getUser.userData.find(
        (data) => data.business.id === businessId
      )

      const items = userData?.items.map((item) => ({
        id: item.id,
        businessItemId: item.businessItem.id,
        itemName: item.businessItem.item.name,
        itemPictureUrl: item.businessItem.item.pictureUrl,
        itemType: item.businessItem.item.type,
        selected: item.selected,
        itemPosX: item.posX,
        itemPosY: item.posY,
        itemScale: item.scale,
      }))

      if (items == null) {
        return res.json({
          status: 4,
        })
      }

      return res.json({
        status: 0,
        items: items ?? [],
        hrPoints: userData?.hrPoints || 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
