import { Request, Response } from 'express'
import { Item } from '../../../database/entity/item'

import db from '../../../database'

export async function getItem(req: Request, res: Response) {
  try {
    const { itemId } = req.params

    return await db.transaction(async (transactionalEntityManager) => {
      const getItem = await transactionalEntityManager
        .getRepository(Item)
        .createQueryBuilder('item')
        .where('item.id = :id', { id: itemId })
        .getOne()

      if (getItem == null) {
        return res.json({
          status: 4,
        })
      }

      return res.json({
        status: 0,
        item: getItem,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
