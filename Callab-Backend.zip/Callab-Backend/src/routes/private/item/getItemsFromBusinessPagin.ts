import { Request, Response } from 'express'
import db from '../../../database'
import { BusinessItem } from '../../../database/entity/businessItem'
import { UserFromToken } from '../../../interfaces/user'

export async function getItemsFromBusinessPagin(req: Request, res: Response) {
  try {
    const { businessId, skip, take } = req.params

    const { business, superAdmin } = <UserFromToken>req.user

    if (!superAdmin && business !== businessId) {
      return res.json({
        status: 4,
      })
    }

    return await db.transaction(async (transactionalEntityManager) => {
      const getItemInBusiness = await transactionalEntityManager
        .getRepository(BusinessItem)
        .createQueryBuilder('businessItem')
        .leftJoinAndSelect('businessItem.business', 'business')
        .leftJoinAndSelect('businessItem.item', 'item')
        .where('business.id = :id', { id: businessId })
        .orderBy('item.name', 'ASC')
        .skip(Number(skip))
        .take(Number(take))
        .getMany()

      const getItemInBusinessCount = await transactionalEntityManager
        .getRepository(BusinessItem)
        .createQueryBuilder('businessItem')
        .getCount()

      if (getItemInBusiness == null) {
        return res.json({
          status: 4,
        })
      }

      return res.json({
        status: 0,
        count: getItemInBusinessCount,
        itemInBusiness: (getItemInBusiness ?? []).map((itemInBusiness) => ({
          id: itemInBusiness.id,
          price: itemInBusiness.price,
          canBeBought: itemInBusiness.canBeBought,
          itemName: itemInBusiness.item.name,
          itemPictureUrl: itemInBusiness.item.pictureUrl,
          itemType: itemInBusiness.item.type,
          idUserCreated: itemInBusiness.idUserCreated,
          dateCreated: itemInBusiness.dateCreated,
          idUserModified: itemInBusiness.idUserModified,
          dateModified: itemInBusiness.dateModified,
          description: itemInBusiness.item.description,
        })),
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
