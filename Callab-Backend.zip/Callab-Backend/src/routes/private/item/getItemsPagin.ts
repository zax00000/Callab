import { Request, Response } from 'express'
import { Item } from '../../../database/entity/item'

import db from '../../../database'

export async function getItemsPagin(req: Request, res: Response) {
  try {
    const { skip, take } = req.params

    return await db.transaction(async (transactionalEntityManager) => {
      const getItems = await transactionalEntityManager
        .getRepository(Item)
        .createQueryBuilder('item')
        .orderBy('item.name', 'ASC')
        .skip(Number(skip))
        .take(Number(take))
        .getMany()

      const itemCount = await transactionalEntityManager
        .getRepository(Item)
        .createQueryBuilder('item')
        .getCount()

      return res.json({
        status: 0,
        items: getItems ?? [],
        count: itemCount,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
