import { Express } from 'express'
import { addItem } from './addItem'
import { editItem } from './editItem'

import multer from 'multer'
import RolesChecker from '../../../middleware/RolesChecker'
import { addAllItemToBusiness } from './addAllItemToBusiness'
import { addItemToBusiness } from './addItemToBusiness'
import { addItemToUser } from './addItemToUser'
import { deleteItem } from './deleteItem'
import { deleteItemFromBusiness } from './deleteItemFromBusiness'
import { deleteItemFromUser } from './deleteItemFromUser'
import { editItemInBusiness } from './editItemInBusiness'
import { editItemInBusinessForAdmin } from './editItemInBusinessForAdmin'
import { editItemsInBusiness } from './editItemsInBusiness'
import { editUserItem } from './editUserItem'
import { editUserItems } from './editUserItems'
import { getAllUserItems } from './getAllUserItems'
import { getItem } from './getItem'
import { getItems } from './getItems'
import { getItemsFromBusiness } from './getItemsFromBusiness'
import { getItemsFromBusinessPagin } from './getItemsFromBusinessPagin'
import { getItemsPagin } from './getItemsPagin'
import { getItemsPaginSearch } from './getItemsPaginSearch'
import { getUserSelectedItems } from './getUserSelectedItems'
import { selectItemFromUser } from './selectItemFromUser'

const upload = multer({ dest: `${__dirname}/static/itemPicture` })

export default (app: Express) => {
  /**
   * @openapi
   * /private/item/{itemId}:
   *  delete:
   *    tags:
   *      - item
   *    description: Delete Item.
   *    summary: Delete Item.
   *    parameters:
   *      - in: path
   *        name: itemId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.delete('/item/:itemId', RolesChecker('DeleteItem'), deleteItem)

  /**
   * @openapi
   * /private/business-item/{businessItemId}:
   *  delete:
   *    tags:
   *      - item
   *    description: Delete Item from business.
   *    summary: Delete Item from business.
   *    parameters:
   *      - in: path
   *        name: businessItemId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.delete(
    '/business-item/:businessItemId',
    RolesChecker('DeleteBusinessItem'),
    deleteItemFromBusiness
  )

  /**
   * @openapi
   * /private/business-item/{userItemId}/user/{userId}:
   *  delete:
   *    tags:
   *      - item
   *    description: Delete Item from user.
   *    summary: Delete Item from user.
   *    parameters:
   *      - in: path
   *        name: userItemId
   *        schema:
   *          type: string
   *      - in: path
   *        name: userId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.delete(
    '/business-item/:userItemId/user/:userId',
    RolesChecker('DeleteBusinessItemFromUser'),
    deleteItemFromUser
  )

  /**
   * @openapi
   * /private/item/new:
   *  post:
   *    tags:
   *      - item
   *    description: Add new item.
   *    summary: Add new item.
   *    requestBody:
   *      content:
   *        multipart/form-data:
   *          schema:
   *            $ref: '#/definitions/AddItem'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  AddItem:           # <----------
   *    type: object
   *    properties:
   *      name:
   *        type: string
   *      description:
   *        type: string
   *      type:
   *        type: number
   *      defaultPrice:
   *        type: number
   *      itemPicture:
   *        type: string
   *        format: binary
   */
  app.post(
    '/item/new',
    upload.single('itemPicture'),
    RolesChecker('addItem'),
    addItem
  )

  /**
   * @openapi
   * /private/user/item/new:
   *  post:
   *    tags:
   *      - item
   *    description: Add item to user.
   *    summary: Add item to user.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/AddItemToUser'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  AddItemToUser:           # <----------
   *    type: object
   *    properties:
   *      businessItemId:
   *        type: string
   *      businessId:
   *        type: string
   *      userId:
   *        type: string
   */
  app.post('/user/item/new', RolesChecker('AddItemToUser'), addItemToUser)

  /**
   * @openapi
   * /private/item/{itemId}:
   *  post:
   *    tags:
   *      - item
   *    description: Edit item.
   *    summary: Edit item.
   *    parameters:
   *      - in: path
   *        name: itemId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        multipart/form-data:
   *          schema:
   *            $ref: '#/definitions/editItem'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  editItem:           # <----------
   *    type: object
   *    properties:
   *      name:
   *        type: string
   *      description:
   *        type: string
   *      type:
   *        type: number
   *      defaultPrice:
   *        type: number
   *      itemPicture:
   *        type: string
   *        format: binary
   */
  app.post(
    '/item/:itemId',
    upload.single('itemPicture'),
    RolesChecker('editItem'),
    editItem
  )

  /**
   * @openapi
   * /private/business-item/new:
   *  post:
   *    tags:
   *      - item
   *    description: Add item to Business.
   *    summary: Add item to Business.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/addItemToBusiness'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  addItemToBusiness:           # <----------
   *    type: object
   *    properties:
   *      itemId:
   *        type: string
   *      businessId:
   *        type: string
   *      canBeBought:
   *        type: boolean
   *      price:
   *        type: number
   */
  app.post(
    '/business-item/new',
    RolesChecker('addItemToBusiness'),
    addItemToBusiness
  )

  /**
   * @openapi
   * /private/business-items/new:
   *  post:
   *    tags:
   *      - item
   *    description: Add all item to Business.
   *    summary: Add all item to Business.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/addAllItemToBusiness'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  addAllItemToBusiness:           # <----------
   *    type: object
   *    properties:
   *      businessId:
   *        type: string
   */
  app.post(
    '/business-items/new',
    RolesChecker('addAllItemToBusiness'),
    addAllItemToBusiness
  )

  /**
   * @openapi
   * /private/select-item:
   *  post:
   *    tags:
   *      - item
   *    description: Select item for user.
   *    summary: Select item for user.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/selectItemForUser'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  selectItemForUser:           # <----------
   *    type: object
   *    properties:
   *      userId:
   *        type: string
   *      businessItemId:
   *        type: string
   *      businessId:
   *        type: string
   */
  app.post(
    '/select-item',
    RolesChecker('selectItemFromUser'),
    selectItemFromUser
  )

  /**
   * @openapi
   * /private/admin/business-item/{businessItemId}:
   *  post:
   *    tags:
   *      - item
   *    description: Edit item in Business form admin.
   *    summary: Edit item in Business form admin.
   *    parameters:
   *      - in: path
   *        name: businessItemId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/EditItemToBusinessForAdmin'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  EditItemToBusinessForAdmin:           # <----------
   *    type: object
   *    properties:
   *      canBeBought:
   *        type: boolean
   *      price:
   *        type: number
   */
  app.post(
    '/admin/business-item/:businessItemId',
    RolesChecker('EditItemToBusinessForAdmin'),
    editItemInBusinessForAdmin
  )

  /**
   * @openapi
   * /private/business-item/{businessItemId}:
   *  post:
   *    tags:
   *      - item
   *    description: Edit item in Business (canBeBought).
   *    summary: Edit item in Business (canBeBought).
   *    parameters:
   *      - in: path
   *        name: businessItemId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/editItemToBusiness'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  editItemToBusiness:           # <----------
   *    type: object
   *    properties:
   *      canBeBought:
   *        type: boolean
   */
  app.post(
    '/business-item/:businessItemId',
    RolesChecker('EditItemToBusiness'),
    editItemInBusiness
  )

  /**
   * @openapi
   * /private/business-items/edit:
   *  post:
   *    tags:
   *      - item
   *    description: Edit items in Business (canBeBought).
   *    summary: Edit items in Business (canBeBought).
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/EditItemsToBusiness'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  EditItemsToBusiness:           # <----------
   *    type: object
   *    properties:
   *      businessItems:
   *        type: array
   *        items:
   *          type: object
   *          properties:
   *            businessItemId:
   *              type: string
   *            canBeBought:
   *              type: boolean
   */
  app.post(
    '/business-items/edit',
    RolesChecker('EditItemsToBusiness'),
    editItemsInBusiness
  )

  /**
   * @openapi
   * /private/business-items/{businessId}:
   *  get:
   *    tags:
   *      - item
   *    description: get business item.
   *    summary: get business item.
   *    parameters:
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                status:
   *                  type: number
   *                itemInBusiness:
   *                  type: array
   *                  items:
   *                    type: object
   *                    properties:
   *                      id:
   *                        type: string
   *                      price:
   *                        type: number
   *                      canBeBought:
   *                        type: boolean
   *                      itemName:
   *                        type: string
   *                      itemPictureUrl:
   *                        type: string
   *                      itemType:
   *                        type: number
   *                      idUserCreated:
   *                        type: string
   *                      dateCreated:
   *                        type: string
   *                      idUserModified:
   *                        type: string
   *                      dateModified:
   *                        type: string
   */
  app.get(
    '/business-items/:businessId',
    RolesChecker('getBusinessItem'),
    getItemsFromBusiness
  )

  /**
   * @openapi
   * /private/pagin/business-items/{businessId}/{skip}/{take}:
   *  get:
   *    tags:
   *      - item
   *    description: get business item pagination.
   *    summary: get business item pagination.
   *    parameters:
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *    responses:
   *      200:
   *        description: Ok
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                status:
   *                  type: number
   *                count:
   *                  type: number
   *                itemInBusiness:
   *                  type: array
   *                  items:
   *                    type: object
   *                    properties:
   *                      id:
   *                        type: string
   *                      price:
   *                        type: number
   *                      canBeBought:
   *                        type: boolean
   *                      itemName:
   *                        type: string
   *                      itemPictureUrl:
   *                        type: string
   *                      itemType:
   *                        type: number
   *                      idUserCreated:
   *                        type: string
   *                      dateCreated:
   *                        type: string
   *                      idUserModified:
   *                        type: string
   *                      dateModified:
   *                        type: string
   */
  app.get(
    '/pagin/business-items/:businessId/:skip/:take',
    RolesChecker('getBusinessItemPagin'),
    getItemsFromBusinessPagin
  )

  /**
   * @openapi
   * /private/item/{itemId}:
   *  get:
   *    tags:
   *      - item
   *    description: get item.
   *    summary: get item.
   *    parameters:
   *      - in: path
   *        name: itemId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                status:
   *                  type: number
   *                item:
   *                  type: object
   *                  properties:
   *                    id:
   *                      type: string
   *                    name:
   *                      type: string
   *                    pictureUrl:
   *                      type: string
   *                    type:
   *                      type: number
   *                    dateCreated:
   *                      type: string
   *                    dateModified:
   *                      type: string
   */
  app.get('/item/:itemId', RolesChecker('getItem'), getItem)

  /**
   * @openapi
   * /private/items:
   *  get:
   *    tags:
   *      - item
   *    description: get item.
   *    summary: get item.
   *    parameters:
   *      - in: path
   *        name: itemId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                status:
   *                  type: number
   *                items:
   *                  type: array
   *                  items:
   *                    type: object
   *                    properties:
   *                      id:
   *                        type: string
   *                      name:
   *                        type: string
   *                      pictureUrl:
   *                        type: string
   *                      type:
   *                        type: number
   *                      dateCreated:
   *                        type: string
   *                      dateModified:
   *                        type: string
   */
  app.get('/items', RolesChecker('getItems'), getItems)

  /**
   * @openapi
   * /private/user-items/user/{userId}/business/{businessId}:
   *  get:
   *    tags:
   *      - item
   *    description: get user items.
   *    summary: get user items.
   *    parameters:
   *      - in: path
   *        name: userId
   *        schema:
   *          type: string
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                status:
   *                  type: number
   *                hrPoints:
   *                  type: number
   *                items:
   *                  type: array
   *                  items:
   *                    type: object
   *                    properties:
   *                      id:
   *                        type: string
   *                      businessItemId:
   *                        type: string
   *                      itemName:
   *                        type: string
   *                      itemPictureUrl:
   *                        type: string
   *                      itemType:
   *                        type: number
   *                      selected:
   *                        type: string
   *                      itemPosX:
   *                        type: string
   *                      itemPosY:
   *                        type: string
   *                      itemScale:
   *                        type: string
   *                      hrPoints:
   *                        type: number
   */
  app.get(
    '/user-items/user/:userId/business/:businessId',
    RolesChecker('getUserItems'),
    getAllUserItems
  )

  /**
   * @openapi
   * /private/user-item/{userItemId}:
   *  post:
   *    tags:
   *      - item
   *    description: Edit user item.
   *    summary: Edit user item.
   *    parameters:
   *      - in: path
   *        name: userItemId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/UserItemEdit'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  UserItemEdit:           # <----------
   *    type: object
   *    properties:
   *      itemPosX:
   *        type: number
   *      itemPosY:
   *        type: number
   *      itemScale:
   *        type: number
   *      selected:
   *        type: boolean
   */
  app.post('/user-item/:userItemId', RolesChecker('userItemEdit'), editUserItem)

  /**
   * @openapi
   * /private/user-items/edit:
   *  post:
   *    tags:
   *      - item
   *    description: Edit user items.
   *    summary: Edit user items.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/UserItemsEdit'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  UserItemsEdit:  # <----------
   *    type: object
   *    properties:
   *      items:
   *        type: array
   *        items:
   *          type: object
   *          properties:
   *            itemId:
   *              type: string
   *            itemPosX:
   *              type: number
   *            itemPosY:
   *              type: number
   *            itemScale:
   *              type: number
   *            selected:
   *              type: boolean
   */
  app.post('/user-items/edit', RolesChecker('userItemsEdit'), editUserItems)

  /**
   * @openapi
   * /private/user-selected-item/user/{userId}/business/{businessId}:
   *  get:
   *    tags:
   *      - item
   *    description: get user selected item.
   *    summary: get user selected item.
   *    parameters:
   *      - in: path
   *        name: userId
   *        schema:
   *          type: string
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                status:
   *                  type: number
   *                item:
   *                  type: object
   *                  properties:
   *                    id:
   *                      type: string
   *                    itemName:
   *                      type: string
   *                    itemPictureUrl:
   *                      type: string
   *                    itemType:
   *                      type: number
   *                    itemPosX:
   *                      type: number
   *                    itemPosY:
   *                      type: number
   *                    itemScale:
   *                      type: number
   *                    selected:
   *                      type: number
   */
  app.get(
    '/user-selected-item/user/:userId/business/:businessId',
    RolesChecker('getUserSelectedItems'),
    getUserSelectedItems
  )

  /**
   * @openapi
   * /private/pagin/items/{skip}/{take}:
   *  get:
   *    tags:
   *      - item
   *    description: get items pagination.
   *    summary: get items pagination.
   *    parameters:
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *    responses:
   *      200:
   *        description: Ok
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                status:
   *                  type: number
   *                count:
   *                  type: number
   *                items:
   *                  type: array
   *                  items:
   *                    type: object
   *                    properties:
   *                      id:
   *                        type: string
   *                      name:
   *                        type: string
   *                      pictureUrl:
   *                        type: string
   *                      type:
   *                        type: number
   *                      dateCreated:
   *                        type: string
   *                      dateModified:
   *                        type: string
   */
  app.get('/pagin/items/:skip/:take', RolesChecker('getItems'), getItemsPagin)

  /**
   * @openapi
   * /private/pagin/items/{skip}/{take}/search/{search}:
   *  get:
   *    tags:
   *      - item
   *    description: get items pagination and search.
   *    summary: get items pagination and search.
   *    parameters:
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *      - in: path
   *        name: search
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   *        content:
   *          application/json:
   *            schema:
   *              type: object
   *              properties:
   *                status:
   *                  type: number
   *                count:
   *                  type: number
   *                items:
   *                  type: array
   *                  items:
   *                    type: object
   *                    properties:
   *                      id:
   *                        type: string
   *                      name:
   *                        type: string
   *                      pictureUrl:
   *                        type: string
   *                      type:
   *                        type: number
   *                      dateCreated:
   *                        type: string
   *                      dateModified:
   *                        type: string
   */
  app.get(
    '/pagin/items/:skip/:take/search/:search',
    RolesChecker('getItems'),
    getItemsPaginSearch
  )
}
