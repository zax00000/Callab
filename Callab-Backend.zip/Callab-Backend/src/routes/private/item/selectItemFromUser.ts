import { Request, Response } from 'express'
import db from '../../../database'
import { UserItem } from '../../../database/entity/userItem'

export async function selectItemFromUser(req: Request, res: Response) {
  try {
    const {
      userId,
      businessItemId,
      businessId,
      itemPosX,
      itemPosY,
      itemScale,
    } = req.body

    return await db.transaction(async (transactionalEntityManager) => {
      const getUserItem = await transactionalEntityManager
        .getRepository(UserItem)
        .createQueryBuilder('userItem')
        .leftJoinAndSelect('userItem.userData', 'userData')
        .leftJoinAndSelect('userData.user', 'user')
        .leftJoinAndSelect('userItem.businessItem', 'businessItem')
        .where('businessItem.id = :businessItemId', {
          businessItemId: businessItemId,
        })
        .where('user.id = :userId', { userId: userId })
        .getOne()

      getUserItem.selected = !getUserItem.selected

      await transactionalEntityManager.getRepository(UserItem).save(getUserItem)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
