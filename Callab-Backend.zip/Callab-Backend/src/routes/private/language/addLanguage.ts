import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Languages } from '../../../database/entity/languages'
import { User } from '../../../database/entity/user'

export async function addLanguage(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { name, active, languageCode } = req.body
      const newLanguage = new Languages()
      const { id: userId } = <UserFromToken>req.user

      if (name == null || languageCode == null) {
        return res.json({
          status: 5,
        })
      }
      const DateNow = new Date()

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()

      newLanguage.dateCreated = DateNow
      newLanguage.dateModified = DateNow
      newLanguage.idUserCreated = getUser
      newLanguage.idUserModified = getUser
      newLanguage.languageCode = languageCode
      newLanguage.name = name
      newLanguage.active = active != null ? active : true

      const newLanguagesResponse = await transactionalEntityManager
        .getRepository(Languages)
        .save(newLanguage)
      return res.json({
        status: 0,
        languageId: newLanguagesResponse.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
