import { Request, Response } from 'express'
import db from '../../../database'
import { Languages } from '../../../database/entity/languages'

export async function deleteLanguage(req: Request, res: Response) {
  try {
    const { languageId } = req.params

    await db
      .createQueryBuilder()
      .delete()
      .from(Languages)
      .where('id = :id', {
        id: languageId,
      })
      .execute()

    return res.json({
      status: 0,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
