import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Languages } from '../../../database/entity/languages'
import { User } from '../../../database/entity/user'

export async function editLanguage(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { languageId } = req.params

      const { id: userId } = <UserFromToken>req.user

      const editedLanguage = await transactionalEntityManager
        .getRepository(Languages)
        .createQueryBuilder('Language')
        .where('Language.id = :id', { id: languageId })
        .getOne()
      const DateNow = new Date()

      if (editedLanguage == null) {
        return res.json({
          status: 3,
        })
      }
      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()

      let changeFlag = false
      ;['name', 'active', 'languageCode'].forEach((filed) => {
        if (req.body[filed] != null) {
          editedLanguage[filed as 'name'] = req.body[filed]
          changeFlag = true
        }
      })

      if (changeFlag) {
        editedLanguage.dateModified = DateNow
        editedLanguage.idUserModified = getUser
      }

      const editedLanguageResponse = await transactionalEntityManager
        .getRepository(Languages)
        .save(editedLanguage)
      return res.json({
        status: 0,
        languageId: editedLanguageResponse.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
