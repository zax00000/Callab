import { Request, Response } from 'express'
import db from '../../../database'
import { Languages } from '../../../database/entity/languages'

export async function getAllLanguagesPaginationSearch(
  req: Request,
  res: Response
) {
  try {
    const { skip, take, search } = req.params

    const getLanguages = await db
      .getRepository(Languages)
      .createQueryBuilder('language')
      .where('language.name ILIKE :searchQuery', { searchQuery: `%${search}%` })
      .skip(Number(skip))
      .take(Number(take))
      .getMany()

    const count = await db
      .getRepository(Languages)
      .createQueryBuilder('language')
      .where('language.name ILIKE :searchQuery', { searchQuery: `%${search}%` })
      .getCount()

    return res.json({
      status: 0,
      languages: getLanguages,
      count,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
