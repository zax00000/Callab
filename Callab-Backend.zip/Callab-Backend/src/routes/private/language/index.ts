import { Express } from 'express'
import RolesChecker from '../../../middleware/RolesChecker'
import { getInterfaceTranslation } from '../interface/getInterfaceTranslation'
import { addLanguage } from './addLanguage'
import { deleteLanguage } from './deleteLanguage'
import { editLanguage } from './editLanguage'
import { getAllLanguagesPagination } from './getAllLanguagesPagination'
import { getAllLanguagesPaginationSearch } from './getAllLanguagesPaginationSearch'

export default (app: Express) => {
  /**
   * @openapi
   * /private/language/{languageId}:
   *  delete:
   *    tags:
   *      - language
   *    description: Delete Language.
   *    summary: Delete Language.
   *    parameters:
   *      - in: path
   *        name: languageId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.delete(
    '/language/:languageId',
    RolesChecker('DeleteLanguage'),
    deleteLanguage
  )

  /**
   * @openapi
   * /private/language/new:
   *  post:
   *    tags:
   *      - language
   *    description: Create Language
   *    summary:  Create Language
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/NewLanguage'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  NewLanguage:           # <----------
   *    type: object
   *    required:
   *      - name
   *    properties:
   *      name:
   *        type: string
   *      active:
   *        type: boolean
   *      languageCode:
   *        type: string
   */
  app.post('/language/new', RolesChecker('AddLanguage'), addLanguage)

  /**
   * @openapi
   * /private/language/{languageId}:
   *  post:
   *    tags:
   *      - language
   *    description: Edit Language
   *    summary: Edit :Language
   *    parameters:
   *      - in: path
   *        name: languageId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/EditLanguage'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  EditLanguage:           # <----------
   *    type: object
   *    properties:
   *      name:
   *        type: string
   *      active:
   *        type: boolean
   *      languageCode:
   *        type: string
   */
  app.post('/language/:languageId', RolesChecker('EditLanguage'), editLanguage)

  /**
   * @openapi
   * /private/pagin/language/{skip}/{take}:
   *  get:
   *    tags:
   *      - language
   *    description: Get all languages with pagination.
   *    summary: Get all languages with pagination.
   *    parameters:
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/pagin/language/:skip/:take',
    RolesChecker('GetAllLanguagePagination'),
    getAllLanguagesPagination
  )

  /**
   * @openapi
   * /private/pagin/language/{skip}/{take}/search/{search}:
   *  get:
   *    tags:
   *      - language
   *    description: Get all languages with pagination.
   *    summary: Get all languages with pagination.
   *    parameters:
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *      - in: path
   *        name: search
   *        schema:
   *          type: number
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/pagin/language/:skip/:take/search/:search',
    RolesChecker('GetAllLanguagePaginationSearch'),
    getAllLanguagesPaginationSearch
  )

  /**
   * @openapi
   * /private/translation/interface/{interfaceId}:
   *  get:
   *    tags:
   *      - interface
   *    description: Get Interface translation.
   *    summary: Get Interface translation.
   *    parameters:
   *      - in: path
   *        name: interfaceId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/translation/interface/{interfaceId}', getInterfaceTranslation)
}
