import { Request, Response } from 'express'
import db from '../../../database'
import { License } from '../../../database/entity/license'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'

export async function addLicense(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { id: userId } = <UserFromToken>req.user
      const {
        startDate,
        endDate,
        maxUsersInBusiness,
        maxUsersRooms,
        maxFloorInBusiness,
        name,
      } = req.body

      const newLicense = new License()
      const DateNow = new Date()

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()

      if (
        maxUsersInBusiness != null &&
        Number.isInteger(Number(maxUsersInBusiness))
      ) {
        newLicense.maxUsersInBusiness = maxUsersInBusiness
      }
      if (maxUsersRooms != null && Number.isInteger(Number(maxUsersRooms))) {
        newLicense.maxUsersRooms = maxUsersRooms
      }
      if (
        maxFloorInBusiness != null &&
        Number.isInteger(Number(maxFloorInBusiness))
      ) {
        newLicense.maxFloorInBusiness = maxFloorInBusiness
      }

      if (new Date(startDate).getTime() > new Date(endDate).getTime()) {
        return res.json({
          status: 4,
        })
      }

      newLicense.startDate = new Date(startDate)
      newLicense.endDate =
        endDate != null && endDate.length > 0 ? new Date(endDate) : null
      newLicense.name = name
      newLicense.dateCreated = DateNow
      newLicense.dateModified = DateNow
      newLicense.idUserCreated = getUser
      newLicense.idUserModified = getUser

      const newLicenseResponse = await transactionalEntityManager
        .getRepository(License)
        .save(newLicense)
      return res.json({
        status: 0,
        licenseId: newLicenseResponse.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
