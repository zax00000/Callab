import { Request, Response } from 'express'
import db from '../../../database'
import { License } from '../../../database/entity/license'

export async function deleteLicense(req: Request, res: Response) {
  try {
    const { licenseId } = req.params

    await db
      .createQueryBuilder()
      .delete()
      .from(License)
      .where('id = :id', {
        id: licenseId,
      })
      .execute()

    return res.json({
      status: 0,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
