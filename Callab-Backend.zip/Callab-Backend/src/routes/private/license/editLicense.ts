import { Request, Response } from 'express'
import db from '../../../database'
import { License } from '../../../database/entity/license'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'

export async function editLicense(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { id: userId } = <UserFromToken>req.user
      const {
        name,
        startDate,
        endDate,
        maxUsersInBusiness,
        maxUsersRooms,
        maxFloorInBusiness,
      } = req.body
      const { licenseId } = req.params

      const getLicense = await transactionalEntityManager
        .getRepository(License)
        .createQueryBuilder('license')
        .where('license.id = :id', { id: licenseId })
        .getOne()
      if (getLicense == null) {
        return res.json({
          status: 3,
        })
      }
      const DateNow = new Date()

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()
      if (maxUsersInBusiness != null && Number.isInteger(maxUsersInBusiness)) {
        getLicense.maxUsersInBusiness = maxUsersInBusiness
      }
      if (name != null && name.length > 0) {
        getLicense.name = name
      }
      if (maxUsersRooms != null && Number.isInteger(maxUsersRooms)) {
        getLicense.maxUsersRooms = maxUsersRooms
      }
      if (maxFloorInBusiness != null && Number.isInteger(maxFloorInBusiness)) {
        getLicense.maxFloorInBusiness = maxFloorInBusiness
      }

      if (startDate != null && startDate.length > 0) {
        if (
          getLicense.endDate != null &&
          new Date(startDate).getTime() > new Date(getLicense.endDate).getTime()
        ) {
          return res.json({
            status: 4,
          })
        }
        getLicense.startDate = new Date(startDate)
      }

      if (endDate != null && endDate.length === 0) {
        getLicense.endDate = null
      }

      if (endDate != null && endDate.length > 0) {
        if (
          new Date(getLicense.startDate).getTime() > new Date(endDate).getTime()
        ) {
          return res.json({
            status: 4,
          })
        }
        getLicense.endDate = new Date(endDate)
      }
      getLicense.dateModified = DateNow
      getLicense.idUserModified = getUser

      const licenseResponse = await transactionalEntityManager
        .getRepository(License)
        .save(getLicense)
      return res.json({
        status: 0,
        licenseId: licenseResponse.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
