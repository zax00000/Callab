import { Request, Response } from 'express'
import db from '../../../database'
import { License } from '../../../database/entity/license'

export async function getAllLicense(req: Request, res: Response) {
  try {
    const getLicenses = await db
      .getRepository(License)
      .createQueryBuilder('license')
      .getMany()
    if (getLicenses == null || getLicenses.length === 0) {
      return res.json({
        status: 3,
      })
    }

    return res.json({
      status: 0,
      licenses: getLicenses,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
