import { Request, Response } from 'express'
import db from '../../../database'
import { License } from '../../../database/entity/license'

export async function getAllLicensePagination(req: Request, res: Response) {
  try {
    const { skip, take } = req.params
    const getLicenses = await db
      .getRepository(License)
      .createQueryBuilder('license')
      .leftJoinAndSelect('license.idUserCreated', 'licenseIdUserCreated')
      .leftJoinAndSelect('license.idUserModified', 'user')
      .skip(Number(skip))
      .take(Number(take))
      .select(['license', 'licenseIdUserCreated.email', 'user.email'])
      .getMany()
    if (getLicenses == null || getLicenses.length === 0) {
      return res.json({
        status: 3,
      })
    }

    const count = await db
      .getRepository(License)
      .createQueryBuilder('license')
      .getCount()
    if (count === 0) {
      return res.json({
        status: 3,
      })
    }

    return res.json({
      status: 0,
      licenses: getLicenses.map((license) => ({
        ...license,
        idUserCreated: license.idUserCreated ? license.idUserCreated.email : '',
        idUserModified: license.idUserModified
          ? license.idUserModified.email
          : '',
      })),
      count,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
