import { Request, Response } from 'express'
import db from '../../../database'
import { License } from '../../../database/entity/license'

export async function getLicense(req: Request, res: Response) {
  try {
    const { licenseId } = req.params

    const getLicense = await db
      .getRepository(License)
      .createQueryBuilder('license')
      .where('license.id = :id', { id: licenseId })
      .getOne()
    if (getLicense == null) {
      return res.json({
        status: 3,
      })
    }

    return res.json({
      status: 0,
      license: getLicense,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
