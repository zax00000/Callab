import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { UserFromToken } from '../../../interfaces/user'

export async function getLicenseForBusiness(req: Request, res: Response) {
  try {
    const { businessId } = req.params

    const { business: UserBusinessId, superAdmin: idSuperAdmin } = <
      UserFromToken
    >req.user

    const getBusiness = await db
      .getRepository(Business)
      .createQueryBuilder('business')
      .leftJoinAndSelect('business.license', 'license')
      .where('business.id = :id', {
        id: idSuperAdmin ? businessId : UserBusinessId,
      })
      .getOne()

    if (getBusiness == null || getBusiness.license == null) {
      return res.json({
        status: 3,
      })
    }

    return res.json({
      status: 0,
      license: getBusiness.license,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
