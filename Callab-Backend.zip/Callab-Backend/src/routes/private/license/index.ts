import { Express } from 'express'
import RolesChecker from '../../../middleware/RolesChecker'
import { addLicense } from './addLicense'
import { deleteLicense } from './deleteLicense'
import { editLicense } from './editLicense'
import { getAllLicense } from './getAllLicense'
import { getAllLicensePagination } from './getAllLicensePagination'
import { getAllLicensePaginationSearch } from './getAllLicensePaginationSearch'
import { getLicense } from './getLicense'
import { getLicenseForBusiness } from './getLicenseForBusiness'

export default (app: Express) => {
  /**
   * @openapi
   * /private/license/{licenseId}:
   *  delete:
   *    tags:
   *      - license
   *    description: Delete License.
   *    summary: Delete License.
   *    parameters:
   *      - in: path
   *        name: licenseId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.delete(
    '/license/:licenseId',
    RolesChecker('DeleteLicense'),
    deleteLicense
  )

  /**
   * @openapi
   * /private/license/new:
   *  post:
   *    tags:
   *      - license
   *    description: Create License
   *    summary:  Create License
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/NewLicense'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  NewLicense:           # <----------
   *    type: object
   *    required:
   *      - startDate
   *      - endDate
   *      - name
   *      - maxUsersRooms
   *      - maxUsersInBusiness
   *    properties:
   *      startDate:
   *        type: string
   *      endDate:
   *        type: string
   *      maxUsersInBusiness:
   *        type: integer
   *      maxUsersRooms:
   *        type: integer
   *      maxFloorInBusiness:
   *        type: integer
   */
  app.post('/license/new', RolesChecker('AddLicense'), addLicense)

  /**
   * @openapi
   * /private/license/{licenseId}:
   *  post:
   *    tags:
   *      - license
   *    description: Edit license
   *    summary: Edit license
   *    parameters:
   *      - in: path
   *        name: licenseId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/EditLicense'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  EditLicense:           # <----------
   *    type: object
   *    properties:
   *      startDate:
   *        type: string
   *      endDate:
   *        type: string
   *      maxUsersInBusiness:
   *        type: integer
   *      maxUsersRooms:
   *        type: integer
   *      maxFloorInBusiness:
   *        type: integer
   */
  app.post('/license/:licenseId', RolesChecker('EditLicense'), editLicense)

  /**
   * @openapi
   * /private/license/{licenseId}:
   *  get:
   *    tags:
   *      - license
   *    description: Get License.
   *    summary: Get License.
   *    parameters:
   *      - in: path
   *        name: licenseId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/license/:licenseId', RolesChecker('GetLicense'), getLicense)

  /**
   * @openapi
   * /private/licenses:
   *  get:
   *    tags:
   *      - license
   *    description: Get all licenses.
   *    summary: Get all licenses.
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/licenses', RolesChecker('GetAllLicense'), getAllLicense)

  /**
   * @openapi
   * /private/license/business/{businessId}:
   *  get:
   *    tags:
   *      - license
   *    description: Get license for business.
   *    summary: Get license for business.
   *    parameters:
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/license/business/:businessId',
    RolesChecker('GetLicenseForBusiness'),
    getLicenseForBusiness
  )

  /**
   * @openapi
   * /private/pagin/licenses/{skip}/{take}:
   *  get:
   *    tags:
   *      - license
   *    description: Get all licenses.
   *    summary: Get all licenses.
   *    parameters:
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/pagin/licenses/:skip/:take',
    RolesChecker('GetAllLicensePagination'),
    getAllLicensePagination
  )

  /**
   * @openapi
   * /private/pagin/licenses/{skip}/{take}/search/{search}:
   *  get:
   *    tags:
   *      - license
   *    description: Get all licenses.
   *    summary: Get all licenses.
   *    parameters:
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *      - in: path
   *        name: search
   *        schema:
   *          type: number
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/pagin/licenses/:skip/:take/search/:search',
    RolesChecker('GetAllLicensePaginationSearch'),
    getAllLicensePaginationSearch
  )
}
