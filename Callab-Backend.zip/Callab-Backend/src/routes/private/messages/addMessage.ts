import { Request, Response } from 'express'
import db from '../../../database'
import { Messages } from '../../../database/entity/messages'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'

export async function addMessage(req: Request, res: Response) {
  try {
    const { business: businessId, id: userId } = <UserFromToken>req.user

    const { roomId, message, email, firstName, surName } = req.body
    return await db.transaction(async (transactionalEntityManager) => {
      if (
        roomId == null ||
        roomId.length === 0 ||
        userId == null ||
        userId.length === 0
      ) {
        return res.json({
          status: 4,
        })
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.userData', 'userData')
        .leftJoinAndSelect('userData.business', 'businessForUserData')
        .select([
          'user.id',
          'userData.firstName',
          'userData.surName',
          'businessForUserData.id',
        ])
        .where('user.id = :id', { id: userId })
        .getOne()

      // const getRoomPromise = transactionalEntityManager
      //   .getRepository(Rooms)
      //   .createQueryBuilder('room')
      //   .select(['room.id'])
      //   .where('room.id = :id', { id: roomId })
      //   .getOne()

      // const [getRoom, getUser] = await Promise.all([
      //   getRoomPromise,
      //   getUserPromise,
      // ])

      // if (getRoom == null) {
      //   res.json({
      //     status: 4,
      //   })
      // }

      const userData = getUser.userData.find(
        (data) => data.business.id === businessId
      )

      const newMessages = new Messages()
      newMessages.userId = getUser.id
      newMessages.message = message
      newMessages.fullName = `${userData?.firstName || ''} ${
        userData?.surName || ''
      }`
      newMessages.email = email || ''
      newMessages.firstName = firstName || ''
      newMessages.surName = surName || ''
      newMessages.room = roomId
      newMessages.dateCreated = new Date()

      const newMessagesToSend = await transactionalEntityManager
        .getRepository(Messages)
        .save(newMessages)

      return res.json({
        status: 0,
        message: {
          ...newMessagesToSend,
          isDeleted: undefined,
          room: undefined,
          roomId: newMessagesToSend.room,
        },
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
