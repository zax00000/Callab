import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Messages } from '../../../database/entity/messages'
import { UserFromToken } from '../../../interfaces/user'

export async function deleteMessage(req: Request, res: Response) {
  try {
    const { messageId } = req.params

    const {
      business: businessId,
      superAdmin: idSuperAdmin,
      id: userId,
    } = <UserFromToken>req.user

    return await db.transaction(async (transactionalEntityManager) => {
      const getMessagesPromise = db
        .getRepository(Messages)
        .createQueryBuilder('messages')
        .select(['messages.id'])
        .where('messages.id = :id', { id: messageId })
        .getOne()

      const getBusinessPromise = db
        .getRepository(Business)
        .createQueryBuilder('business')
        .leftJoinAndSelect('business.users', 'users')
        .select(['business.id', 'users.id'])
        .where('business.id = :id', { id: businessId })
        .getOne()

      const [getMessages, getBusiness] = await Promise.all([
        getMessagesPromise,
        getBusinessPromise,
      ])

      if (getMessages == null) {
        return res.json({
          status: 4,
        })
      }
      if (
        (getBusiness != null &&
          getBusiness.users.some((user) => user.id === userId)) ||
        idSuperAdmin
      ) {
        getMessages.isDeleted = true
        await transactionalEntityManager
          .getRepository(Messages)
          .save(getMessages)
        return res.json({
          status: 0,
        })
      }

      return res.json({
        status: 2,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
