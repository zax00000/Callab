import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Messages } from '../../../database/entity/messages'
import { UserFromToken } from '../../../interfaces/user'

export async function getMessages(req: Request, res: Response) {
  try {
    const { skip, take, roomId } = req.params

    const {
      business: businessId,
      superAdmin: idSuperAdmin,
      id: userId,
    } = <UserFromToken>req.user

    const getMessagesPromise = db
      .getRepository(Messages)
      .createQueryBuilder('messages')
      // .leftJoinAndSelect('messages.room', 'room')
      .select([
        // 'room.id',
        'messages.id',
        'messages.userId',
        'messages.message',
        'messages.fullName',
        'messages.isDeleted',
        'messages.dateCreated',
        'messages.email',
        'messages.firstName',
        'messages.surName',
        'messages.room',
      ])
      .where('room = :id', { id: roomId })
      .andWhere('messages.isDeleted = :isDeleted', { isDeleted: false })
      .orderBy('messages.dateCreated', 'DESC')
      .skip(skip != null && Number(skip) > 0 ? Number(skip) : 0)
      .take(take != null && Number(take) > 0 ? Number(take) : null)
      .getMany()

    const getBusinessPromise = db
      .getRepository(Business)
      .createQueryBuilder('business')
      .leftJoinAndSelect('business.users', 'users')
      .select(['business.id', 'users.id'])
      .where('business.id = :id', { id: businessId })
      .getOne()

    const [getMessages, getBusiness] = await Promise.all([
      getMessagesPromise,
      getBusinessPromise,
    ])

    if (
      (getBusiness != null &&
        getBusiness.users.some((user) => user.id === userId)) ||
      idSuperAdmin
    ) {
      return res.json({
        status: 0,
        messages: getMessages
          .map((message) => ({
            ...message,
            isDeleted: undefined,
            room: undefined,
            roomId: message.room,
          }))
          .reverse(),
      })
    }

    return res.json({
      status: 2,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
