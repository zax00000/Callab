import { Express } from 'express'
import RolesChecker from '../../../middleware/RolesChecker'
import { addMessage } from './addMessage'
import { deleteMessage } from './deleteMessage'
import { getMessages } from './getMessages'

export default (app: Express) => {
  /**
   * @openapi
   * /private/messages/room/{roomId}/{skip}/{take}:
   *  get:
   *    tags:
   *      - messages
   *    description: Get Messages for Room Pagination
   *    summary: Get Messages for Room Pagination
   *    parameters:
   *      - in: path
   *        name: roomId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/messages/room/:roomId/:skip/:take',
    RolesChecker('GetMessages'),
    getMessages
  )

  /**
   * @openapi
   * /private/message:
   *  post:
   *    tags:
   *      - messages
   *    description: Add new message.
   *    summary: Add new message.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/AddMessage'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  AddMessage:           # <----------
   *    type: object
   *    properties:
   *      roomId:
   *        type: string
   *      email:
   *        type: string
   *      firstName:
   *        type: string
   *      surName:
   *        type: string
   */
  app.post('/message', RolesChecker('AddMessage'), addMessage)

  /**
   * @openapi
   * /private/message/{messageId}:
   *  delete:
   *    tags:
   *      - messages
   *    description: Delete message
   *    summary: Delete message.
   *    parameters:
   *      - in: path
   *        name: messageId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.delete(
    '/message/:messageId',
    RolesChecker('DeleteMessage'),
    deleteMessage
  )
}
