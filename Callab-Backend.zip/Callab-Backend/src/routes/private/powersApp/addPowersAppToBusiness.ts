import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { PowersApp } from '../../../database/entity/powersApp'
import { User } from '../../../database/entity/user'

export async function addPowersAppToBusiness(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { businessId, powersApp } = req.body

      const {
        business: UserBusinessId,
        superAdmin: idSuperAdmin,
        id: userId,
      } = <UserFromToken>req.user

      const business = await transactionalEntityManager
        .getRepository(Business)
        .createQueryBuilder('business')
        .leftJoinAndSelect('business.powersAppForBusiness', 'powersApp')
        .where('business.id = :id', {
          id: idSuperAdmin ? businessId : UserBusinessId,
        })
        .getOne()

      const newAddedPowersApp = await transactionalEntityManager
        .getRepository(PowersApp)
        .createQueryBuilder('powersApp')
        .where('powersApp.id IN (:...ids)', {
          ids: powersApp,
        })
        .getMany()
      business.powersAppForBusiness = newAddedPowersApp

      const user = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()

      business.idUserModified = user
      business.dateModified = new Date()

      await transactionalEntityManager.getRepository(Business).save(business)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
