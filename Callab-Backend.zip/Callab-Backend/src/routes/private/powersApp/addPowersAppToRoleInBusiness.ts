import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Role } from '../../../database/entity/role'
import { User } from '../../../database/entity/user'

export async function addPowersAppToRoleInBusiness(
  req: Request,
  res: Response
) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { businessId, powersAppId, roleId } = req.body

      const {
        business: UserBusinessId,
        superAdmin: idSuperAdmin,
        id: userId,
      } = <UserFromToken>req.user

      const business = await transactionalEntityManager
        .getRepository(Business)
        .createQueryBuilder('business')
        .leftJoinAndSelect('business.powersAppForBusiness', 'powersApp')
        .leftJoinAndSelect('business.roles', 'role')
        .where('business.id = :id', {
          id: idSuperAdmin ? businessId : UserBusinessId,
        })
        .getOne()

      const powersToAdd = business.powersAppForBusiness.filter((powerApp) =>
        powersAppId.some((powerAppId: string) => powerApp.id === powerAppId)
      )
      if (powersToAdd.length != powersAppId.length) {
        return res.json({
          status: 4,
        })
      }

      const role = business.roles.find((role) =>
        role ? role.id === roleId : false
      )

      if (role == null) {
        return res.json({
          status: 4,
        })
      }

      role.powersApp = powersToAdd

      const user = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()

      role.idUserModified = user
      role.dateModified = new Date()

      await transactionalEntityManager.getRepository(Role).save(role)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
