import { Request, Response } from 'express'
import db from '../../../database'
import { PowersApp } from '../../../database/entity/powersApp'

export async function getAllPowersApp(req: Request, res: Response) {
  try {
    const getPowersApp = await db
      .getRepository(PowersApp)
      .createQueryBuilder('powersApp')
      .getMany()

    return res.json({
      status: 0,
      powersApp: getPowersApp,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
