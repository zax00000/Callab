import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Business } from '../../../database/entity/business'

export async function getPowerAppByBusiness(req: Request, res: Response) {
  try {
    const { businessId } = req.params

    const { business: UserBusinessId, superAdmin: idSuperAdmin } = <
      UserFromToken
    >req.user

    const getBusiness = await db
      .getRepository(Business)
      .createQueryBuilder('business')
      .leftJoinAndSelect('business.powersAppForBusiness', 'powersApp')
      .where('business.id = :id', {
        id: idSuperAdmin ? businessId : UserBusinessId,
      })
      .getOne()

    return res.json({
      status: 0,
      powersApp: getBusiness.powersAppForBusiness,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
