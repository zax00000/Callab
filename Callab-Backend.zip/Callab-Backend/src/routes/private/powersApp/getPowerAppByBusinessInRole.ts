import { Request, Response } from 'express'
import db from '../../../database'
import { Role } from '../../../database/entity/role'

export async function getPowerAppByBusinessInRole(req: Request, res: Response) {
  try {
    const { roleId } = req.params

    const getPowerAppForRole = await db
      .getRepository(Role)
      .createQueryBuilder('role')
      .leftJoinAndSelect('role.powersApp', 'powersApp')
      .where('role.id = :id', {
        id: roleId,
      })
      .getOne()

    return res.json({
      status: 0,
      powersApp: getPowerAppForRole.powersApp,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
