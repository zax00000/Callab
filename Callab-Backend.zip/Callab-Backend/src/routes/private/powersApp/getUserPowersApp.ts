import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Authentication } from '../../../database/entity/authentication'

export async function getUserPowersApp(req: Request, res: Response) {
  try {
    const { authId } = <UserFromToken>req.user

    const userAuth = await db
      .getRepository(Authentication)
      .createQueryBuilder('authentication')
      .leftJoinAndSelect('authentication.activeBusinessRole', 'role')
      .leftJoinAndSelect('role.powersApp', 'powersApp')
      .where('authentication.id = :id', {
        id: authId,
      })
      .getOne()

    return res.json({
      status: 0,
      userPowersApp: userAuth.activeBusinessRole.powersApp,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
