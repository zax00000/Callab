import { Express } from 'express'
import RulesChecker from '../../../middleware/RolesChecker'
import { addPowersAppToBusiness } from './addPowersAppToBusiness'
import { getAllPowersApp } from './getPowerApp'
import { getPowerAppByBusiness } from './getPowerAppByBusiness'

import { addPowersAppToRoleInBusiness } from './addPowersAppToRoleInBusiness'
import { getPowerAppByBusinessInRole } from './getPowerAppByBusinessInRole'
import { getUserPowersApp } from './getUserPowersApp'

export default (app: Express) => {
  /**
   * @openapi
   * /private/powers-app:
   *  post:
   *    tags:
   *      - powersApp
   *    description: Add new power app to business.
   *    summary: Add new power app to business.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/AddPowersAppBusiness'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  AddPowersAppBusiness:           # <----------
   *    type: object
   *    properties:
   *      businessId:
   *        type: string
   *      powersApp:
   *        type: array
   *        items:
   *          type: string
   */
  app.post(
    '/powers-app',
    RulesChecker('AddPowersAppToBusiness'),
    addPowersAppToBusiness
  )

  /**
   * @openapi
   * /private/powers-app/business/{businessId}:
   *  get:
   *    tags:
   *      - powersApp
   *    description: Get all PowersApp in business.
   *    summary: Get all PowersApp in business.
   *    parameters:
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/powers-app/business/:businessId',
    RulesChecker('GetPowerAppByBusiness'),
    getPowerAppByBusiness
  )

  /**
   * @openapi
   * /private/powers-app/role/{roleId}:
   *  get:
   *    tags:
   *      - powersApp
   *    description: Get all PowersApp in role.
   *    summary: Get all PowersApp in role.
   *    parameters:
   *      - in: path
   *        name: roleId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/powers-app/role/:roleId', getPowerAppByBusinessInRole)

  /**
   * @openapi
   * /private/powers-app:
   *  get:
   *    tags:
   *      - powersApp
   *    description: Get all PowersApp.
   *    summary: Get all PowersApp.
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/powers-app', RulesChecker('GetAllPowersApp'), getAllPowersApp)

  /**
   * @openapi
   * /private/powers-app/user:
   *  get:
   *    tags:
   *      - powersApp
   *    description: Get all PowersApp for User roles.
   *    summary: Get all PowersApp for User roles.
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/powers-app/user',
    RulesChecker('GetUserPowersApp'),
    getUserPowersApp
  )

  /**
   * @openapi
   * /private/powers-app/role:
   *  post:
   *    tags:
   *      - powersApp
   *    description: Add power to role in business.
   *    summary: Add power to role in business.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/AddPowersAppToRoleBusiness'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  AddPowersAppToRoleBusiness:           # <----------
   *    type: object
   *    properties:
   *      businessId:
   *        type: string
   *      roleId:
   *        type: string
   *      powersAppId:
   *        type: array
   *        items:
   *          type: string
   */
  app.post(
    '/powers-app/role',
    RulesChecker('AddPowersAppToRoleInBusiness'),
    addPowersAppToRoleInBusiness
  )
}
