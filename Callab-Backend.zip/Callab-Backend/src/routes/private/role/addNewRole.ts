import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Role } from '../../../database/entity/role'
import { User } from '../../../database/entity/user'

export async function addNewRole(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { businessId, powersAppId } = req.body
      const roleName = req.body.roleName?.trim() as string

      const {
        business: UserBusinessId,
        superAdmin: idSuperAdmin,
        id: userId,
      } = <UserFromToken>req.user

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      if (getUser == null) {
        return res.json({
          status: 2,
        })
      }

      const getBusiness = await transactionalEntityManager
        .getRepository(Business)
        .createQueryBuilder('business')
        .leftJoinAndSelect('business.powersAppForBusiness', 'powersApp')
        .leftJoinAndSelect('business.roles', 'roles')
        .where('business.id = :id', {
          id: idSuperAdmin ? businessId : UserBusinessId,
        })
        .getOne()

      if (
        roleName == null ||
        roleName.length === 0 ||
        getBusiness == null ||
        getBusiness.roles.filter((role) => role.name === roleName).length > 0
      ) {
        return res.json({
          status: 4,
        })
      }

      const newRole = new Role()
      newRole.business = getBusiness

      if (powersAppId != null && powersAppId.length > 0) {
        const powersToAdd = getBusiness.powersAppForBusiness.filter(
          (powerApp) =>
            powersAppId.some((powerAppId: string) => powerApp.id === powerAppId)
        )

        if (powersToAdd.length != powersAppId.length) {
          return res.json({
            status: 4,
          })
        }
        newRole.powersApp = powersToAdd
      }

      newRole.dateCreated = new Date()
      newRole.dateModified = new Date()
      newRole.idUserCreated = getUser
      newRole.idUserModified = getUser
      newRole.name = roleName

      const responseRoleId = await transactionalEntityManager
        .getRepository(Role)
        .save(newRole)

      return res.json({
        status: 0,
        roleId: responseRoleId.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
