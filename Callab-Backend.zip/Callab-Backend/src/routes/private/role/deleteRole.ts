import { Request, Response } from 'express'
import db from '../../../database'
import { Role } from '../../../database/entity/role'

export async function deleteRole(req: Request, res: Response) {
  try {
    const { roleId } = req.params
    const getRoom = await db
      .getRepository(Role)
      .createQueryBuilder('role')
      .leftJoinAndSelect('role.userWithRole', 'user')
      .where('role.id = :id', {
        id: roleId,
      })
      .getOne()

    if (getRoom.userWithRole.length > 0) {
      return res.json({
        status: 4,
      })
    }

    await db
      .createQueryBuilder()
      .delete()
      .from(Role)
      .where('id = :id', {
        id: roleId,
      })
      .execute()

    return res.json({
      status: 0,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
