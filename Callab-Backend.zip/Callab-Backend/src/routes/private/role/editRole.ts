import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Role } from '../../../database/entity/role'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'

export async function editRole(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { roleId } = req.params
      let { roleName, powersAppId } = req.body

      const {
        business: UserBusinessId,
        superAdmin: idSuperAdmin,
        id: userId,
      } = <UserFromToken>req.user

      roleName = roleName?.trim()
      if (roleName == null || roleName.length === 0) {
        return res.json({
          status: 4,
        })
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      const editedRole = await transactionalEntityManager
        .getRepository(Role)
        .createQueryBuilder('role')
        .leftJoinAndSelect('role.business', 'business')
        .where('role.id = :id', {
          id: roleId,
        })
        .getOne()

      const getBusiness = await transactionalEntityManager
        .getRepository(Business)
        .createQueryBuilder('business')
        .leftJoinAndSelect('business.powersAppForBusiness', 'powersApp')
        .leftJoinAndSelect('business.roles', 'roles')
        .where('business.id = :id', {
          id: UserBusinessId,
        })
        .getOne()

      if (!idSuperAdmin && editedRole?.business?.id !== UserBusinessId) {
        return res.json({
          status: 2,
        })
      }

      if (
        getBusiness == null ||
        (roleName == null && getBusiness != null && !UserBusinessId
          ? getBusiness.roles.filter((role) => role.name === roleName).length >
            0
          : false)
      ) {
        return res.json({
          status: 4,
        })
      }

      if (editedRole == null) {
        return res.json({
          status: 3,
        })
      }

      if (powersAppId != null && powersAppId.length > 0) {
        const powersToAdd = getBusiness.powersAppForBusiness.filter(
          (powerApp) =>
            powersAppId.some((powerAppId: string) => powerApp.id === powerAppId)
        )

        if (powersToAdd.length != powersAppId.length) {
          return res.json({
            status: 4,
          })
        }
        editedRole.powersApp = powersToAdd
      }

      editedRole.dateModified = new Date()
      editedRole.idUserModified = getUser
      if (roleName != null && roleName.length > 0) {
        editedRole.name = roleName
      }

      await transactionalEntityManager.getRepository(Role).save(editedRole)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
