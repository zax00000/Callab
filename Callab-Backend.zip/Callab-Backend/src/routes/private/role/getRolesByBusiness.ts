import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { UserFromToken } from '../../../interfaces/user'

export async function getRolesByBusiness(req: Request, res: Response) {
  try {
    const { businessId } = req.params

    const { business: UserBusinessId, superAdmin: idSuperAdmin } = <
      UserFromToken
    >req.user

    const getBusiness = await db
      .getRepository(Business)
      .createQueryBuilder('business')
      .leftJoinAndSelect('business.roles', 'role')
      .leftJoinAndSelect('role.powersApp', 'powersApp')
      .select([
        'business.id',
        'role.id',
        'role.name',
        'role.superAdminApi',
        'role.superAdminApp',
        'role.dateCreated',
        'powersApp.id',
        'powersApp.name',
        'powersApp.powerEnum',
      ])
      .where('business.id = :id', {
        id: idSuperAdmin ? businessId : UserBusinessId,
      })
      .getOne()

    return res.json({
      status: 0,
      roles: getBusiness.roles.sort(
        (firstRole, secondRole) =>
          new Date(secondRole.dateCreated).getTime() -
          new Date(firstRole.dateCreated).getTime()
      ),
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
