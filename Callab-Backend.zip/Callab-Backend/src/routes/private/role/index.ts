import { Express } from 'express'
import RulesChecker from '../../../middleware/RolesChecker'
import { addNewRole } from './addNewRole'
import { deleteRole } from './deleteRole'
import { editRole } from './editRole'
import { getRolesByBusiness } from './getRolesByBusiness'

export default (app: Express) => {
  /**
   * @openapi
   * /private/role:
   *  post:
   *    tags:
   *      - role
   *    description: Add new role.
   *    summary: Add new role.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/AddRole'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  AddRole:           # <----------
   *    type: object
   *    properties:
   *      businessId:
   *        type: string
   *      roleName:
   *        type: string
   *      powersAppId:
   *        type: array
   *        items:
   *          type: string
   */
  app.post('/role', RulesChecker('AddNewRole'), addNewRole)

  /**
   * @openapi
   * /private/role/{roleId}:
   *  post:
   *    tags:
   *      - role
   *    description: Edit role.
   *    summary: Edit role.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/AddRole'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  AddRole:           # <----------
   *    type: object
   *    properties:
   *      roleName:
   *        type: string
   *      powersAppId:
   *        type: array
   *        items:
   *          type: string
   */
  app.post('/role/:roleId', RulesChecker('EditRole'), editRole)

  /**
   * @openapi
   * /private/roles/business/{businessId}:
   *  get:
   *    tags:
   *      - role
   *    description: Get all roles in business.
   *    summary: Get all roles in business.
   *    parameters:
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/roles/business/:businessId',
    RulesChecker('GetRolesByBusiness'),
    getRolesByBusiness
  )

  /**
   * @openapi
   * /private/role/{roleId}:
   *  delete:
   *    tags:
   *      - role
   *    description: Delete role.
   *    summary: Delete role.
   *    parameters:
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.delete('/role/:roleId', RulesChecker('DeleteRole'), deleteRole)
}
