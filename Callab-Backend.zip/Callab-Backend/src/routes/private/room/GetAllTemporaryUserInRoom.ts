import { Request, Response } from 'express'
import db from '../../../database'
import { Rooms } from '../../../database/entity/rooms'
import { UserFromToken } from '../../../interfaces/user'

export async function GetAllTemporaryUserInRoom(req: Request, res: Response) {
  try {
    const { roomId } = req.params

    const { business: UserBusinessId, superAdmin: idSuperAdmin } = <
      UserFromToken
    >req.user

    const getRoom = await db
      .getRepository(Rooms)
      .createQueryBuilder('rooms')
      .leftJoinAndSelect('rooms.floor', 'floors')
      .leftJoinAndSelect('floors.business', 'business')
      .leftJoinAndSelect('rooms.roomMembers', 'roomMembers')
      .leftJoinAndSelect('roomMembers.user', 'user')
      .leftJoinAndSelect('roomMembers.temporaryUser', 'temporaryUser')
      .leftJoinAndSelect('user.userData', 'userData')
      .leftJoinAndSelect('userData.business', 'businessForUserData')
      .where('rooms.id = :id', {
        id: roomId,
      })
      .cache(roomId, 1000 * 60 * 60)
      .getOne()

    if (getRoom == null) {
      return res.json({
        status: 3,
      })
    }

    if (!idSuperAdmin) {
      if (getRoom.floor.business.id !== UserBusinessId) {
        return res.json({
          status: 3,
        })
      }
    }
    const userInRoom = getRoom.roomMembers
      .filter(({ user }) => user == null)
      .map(({ temporaryUser, isManager, isModerator, isUser, isGuest, id }) => {
        return {
          id,
          userId: temporaryUser?.id || '',
          firstName: temporaryUser?.firstName || '',
          surName: temporaryUser?.surName || '',
          email: temporaryUser?.email,
          roomId,
          roomRole: isUser
            ? 2
            : isModerator
            ? 1
            : isManager
            ? 0
            : isGuest
            ? 3
            : 2,
        }
      })
      .sort((user1, user2) =>
        (user1.firstName + user1.surName).localeCompare(
          user2.firstName + user2.surName
        )
      )

    return res.json({
      status: 0,
      userInRoom,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
