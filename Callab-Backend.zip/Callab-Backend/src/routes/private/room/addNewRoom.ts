import bcrypt from 'bcryptjs'
import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Floors } from '../../../database/entity/floors'
import { Rooms } from '../../../database/entity/rooms'
import { RoomsTypes } from '../../../database/entity/roomsTypes'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'
import { checkLicenseTime } from '../../../utils/checkLicenseTime'

export async function addNewRoom(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const {
        business: UserBusinessId,
        superAdmin: idSuperAdmin,
        id: userId,
      } = <UserFromToken>req.user

      const {
        floorId,
        typesId,
        name,
        isSecured,
        password,
        coordX,
        coordY,
        width,
        height,
        rotation,
        scale,
        color,
      } = req.body

      if (!idSuperAdmin) {
        const getFloor = await transactionalEntityManager
          .getRepository(Floors)
          .createQueryBuilder('floors')
          .leftJoinAndSelect('floors.business', 'business')
          .where('floors.id = :id', {
            id: floorId,
          })
          .getOne()
        if (
          !(
            getFloor &&
            getFloor.business &&
            getFloor.business.id === UserBusinessId
          )
        ) {
          return res.json({
            status: 3,
          })
        }
      }

      const requireFields = [] as string[]
      ;[
        'name',
        'isSecured',
        'coordX',
        'coordY',
        'width',
        'height',
        'rotation',
        'scale',
        'color',
      ].forEach((fieldName) => {
        if (
          !(
            req.body[fieldName] != null &&
            req.body[fieldName].toString().length > 0
          )
        ) {
          requireFields.push(fieldName)
        }
      })

      if (requireFields.length > 0) {
        return res.json({
          status: 5,
        })
      }

      const getUserPromise = transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      const getFloorPromise = transactionalEntityManager
        .getRepository(Floors)
        .createQueryBuilder('floors')
        .leftJoinAndSelect('floors.business', 'business')
        .select(['business.id', 'floors'])
        .where('floors.id = :id', {
          id: floorId,
        })
        .getOne()

      const getRoomTypePromise = transactionalEntityManager
        .getRepository(RoomsTypes)
        .createQueryBuilder('roomTypes')
        .where('roomTypes.id = :id', {
          id: typesId,
        })
        .getOne()

      const [getUser, getFloor, getRoomType] = await Promise.all([
        getUserPromise,
        getFloorPromise,
        getRoomTypePromise,
      ])

      const getBusiness = await transactionalEntityManager
        .getRepository(Business)
        .createQueryBuilder('business')
        .leftJoinAndSelect('business.floors', 'floors')
        .leftJoinAndSelect('business.license', 'license')
        .leftJoinAndSelect('floors.rooms', 'rooms')
        .select([
          'business.id',
          'floors.id',
          'rooms.id',
          'license.id',
          'license.maxUsersRooms',
          'license.endDate',
          'license.startDate',
        ])
        .where('business.id = :id', {
          id: getFloor.business.id,
        })
        .getOne()
      if (checkLicenseTime(getBusiness.license)) {
        return res.json({
          status: 7,
        })
      }

      const roomInBusiness = getBusiness.floors.reduce((value, floors) => {
        return value + floors.rooms.length
      }, 0)

      if (
        getBusiness.license.maxUsersRooms !== 0 &&
        roomInBusiness >= getBusiness.license.maxUsersRooms
      ) {
        return res.json({
          status: 7,
        })
      }

      if (!getRoomType) {
        return res.json({
          status: 3,
        })
      }

      const newRoom = new Rooms()

      const newDate = new Date()
      newRoom.floor = getFloor
      newRoom.types = getRoomType
      newRoom.name = name
      newRoom.isSecured = isSecured
      if (isSecured) {
        newRoom.password = await bcrypt.hash(password, 10)
      }
      newRoom.color = color
      newRoom.coordX = coordX
      newRoom.coordY = coordY
      newRoom.width = width
      newRoom.height = height
      newRoom.rotation = rotation
      newRoom.scale = scale
      newRoom.idUserCreated = getUser
      newRoom.idUserModified = getUser
      newRoom.dateModified = newDate
      newRoom.dateCreated = newDate
      getFloor.dateModified = newDate

      await transactionalEntityManager.getRepository(Floors).save(getFloor)
      const newRoomResponse = await transactionalEntityManager
        .getRepository(Rooms)
        .save(newRoom)

      await db.queryResultCache.remove([floorId])

      return res.json({
        status: 0,
        roomId: newRoomResponse.id,
      })
    })
  } catch (error) {
    console.error(error)

    return res.json({
      status: 6,
    })
  }
}
