import { Request, Response } from 'express'
import db from '../../../database'
import { Floors } from '../../../database/entity/floors'
import { Rooms } from '../../../database/entity/rooms'
import { RoomsMembers } from '../../../database/entity/roomsMembers'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'
import { checkLicenseTime } from '../../../utils/checkLicenseTime'
import { noManagerForRoom } from '../../../utils/noManagerForRoom'

export async function addUserToRoom(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { roomId, userId, roomRole } = req.body

      const {
        business: UserBusinessId,
        superAdmin: idSuperAdmin,
        id: userWhoAddID,
      } = <UserFromToken>req.user

      const getRoom = await transactionalEntityManager
        .getRepository(Rooms)
        .createQueryBuilder('rooms')
        .leftJoinAndSelect('rooms.floor', 'floors')
        .leftJoinAndSelect('rooms.types', 'types')
        .leftJoinAndSelect('floors.business', 'business')
        .leftJoinAndSelect('business.license', 'license')
        .leftJoinAndSelect('rooms.roomMembers', 'roomsMembers')
        .leftJoinAndSelect('roomsMembers.user', 'user')
        .select([
          'floors',
          'business.id',
          'business.license',
          'license',
          'rooms',
          'roomsMembers',
          'user.id',
          'types.id',
          'types.maxUsersLicensed',
          'types.maxUsers',
          'types.isConference',
        ])
        .where('rooms.id = :id', {
          id: roomId,
        })
        .getOne()

      if (checkLicenseTime(getRoom.floor.business.license)) {
        return res.json({
          status: 7,
        })
      }

      if (
        getRoom?.types != null &&
        getRoom.types.maxUsersLicensed === true &&
        getRoom.types.maxUsers != null &&
        getRoom.roomMembers.length >= getRoom.types.maxUsers
      ) {
        return res.json({
          status: 7,
        })
      }

      // if (
      //   getRoom.floor.business.license.maxUsersRooms !== 0 &&
      //   getRoom.roomMembers.length >=
      //     getRoom.floor.business.license.maxUsersRooms
      // ) {
      //   return res.json({
      //     status: 7,
      //   })
      // }

      if (!idSuperAdmin) {
        if (getRoom.floor.business.id !== UserBusinessId) {
          return res.json({
            status: 2,
          })
        }
      }

      const roomMembers = getRoom.roomMembers || []

      if (
        roomMembers.some((roomMember) => {
          return roomMember?.user?.id === userId
        })
      ) {
        return res.json({
          status: 8,
        })
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userWhoAddID,
        })
        .getOne()

      const getAddingUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      if (roomRole == null || !Number.isInteger(Number(roomRole))) {
        return res.json({
          status: 5,
        })
      }

      const getUserRoomMembers = await transactionalEntityManager
        .getRepository(RoomsMembers)
        .createQueryBuilder('roomsMembers')
        .leftJoinAndSelect('roomsMembers.user', 'user')
        .leftJoinAndSelect('roomsMembers.room', 'room')
        .leftJoinAndSelect('room.floor', 'floor')
        .leftJoinAndSelect('room.types', 'types')
        .leftJoinAndSelect('floor.business', 'business')
        .select([
          'roomsMembers.id',
          'business.id',
          'user.id',
          'room.id',
          'floor.id',
          'types.id',
          'types.isConference',
        ])
        .where('user.id = :id', {
          id: userId,
        })
        .andWhere('business.id = :businessId', {
          businessId: UserBusinessId,
        })
        .andWhere('types.isConference = :isConference', {
          isConference: false,
        })
        .getMany()

      if (
        getRoom.types.isConference === false &&
        getUserRoomMembers.length > 0
      ) {
        return res.json({
          status: 7,
        })
      }

      if (roomRole === 0) {
        await noManagerForRoom({ roomId })
      }

      const newDate = new Date()
      const newRoomMembers = new RoomsMembers()
      newRoomMembers.user = getAddingUser
      newRoomMembers.room = getRoom
      newRoomMembers.isManager = roomRole === 0
      newRoomMembers.isModerator = roomRole === 1
      newRoomMembers.isUser = roomRole === 2
      newRoomMembers.isGuest = roomRole === 3
      newRoomMembers.dateCreated = newDate
      newRoomMembers.idUserCreated = getUser
      newRoomMembers.dateModified = newDate
      newRoomMembers.idUserModified = getUser

      const newRoomResponse = await transactionalEntityManager
        .getRepository(RoomsMembers)
        .save(newRoomMembers)

      getRoom.floor.dateModified = new Date()

      await transactionalEntityManager.getRepository(Floors).save(getRoom.floor)

      await db.queryResultCache.remove([roomId])
      await db.queryResultCache.remove([getRoom.floor.id])

      return res.json({
        status: 0,
        roomMembers: newRoomResponse.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
