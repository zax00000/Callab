import { Request, Response } from 'express'
import db from '../../../database'
import { Floors } from '../../../database/entity/floors'
import { Rooms } from '../../../database/entity/rooms'
import { RoomsMembers } from '../../../database/entity/roomsMembers'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'
import { checkLicenseTime } from '../../../utils/checkLicenseTime'
import { noManagerForRoom } from '../../../utils/noManagerForRoom'

export async function addUsersToRoom(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { roomId, users } = req.body

      const {
        business: UserBusinessId,
        superAdmin: idSuperAdmin,
        id: userWhoAddID,
      } = <UserFromToken>req.user

      const getRoom = await transactionalEntityManager
        .getRepository(Rooms)
        .createQueryBuilder('rooms')
        .leftJoinAndSelect('rooms.floor', 'floors')
        .leftJoinAndSelect('rooms.types', 'types')
        .leftJoinAndSelect('floors.business', 'business')
        .leftJoinAndSelect('business.license', 'license')
        .leftJoinAndSelect('rooms.roomMembers', 'roomsMembers')
        .leftJoinAndSelect('roomsMembers.user', 'user')
        .select([
          'floors',
          'business.id',
          'business.license',
          'license',
          'rooms',
          'roomsMembers',
          'user.id',
          'types.id',
          'types.maxUsersLicensed',
          'types.maxUsers',
          'types.isConference',
        ])
        .where('rooms.id = :id', {
          id: roomId,
        })
        .getOne()

      if (checkLicenseTime(getRoom.floor.business.license)) {
        return res.json({
          status: 7,
        })
      }

      const roomMembers = getRoom.roomMembers || []

      // if (
      //   roomMembers.some((roomMember) => {
      //     return roomMember.user.id === userId
      //   })
      // ) {
      //   return res.json({
      //     status: 8,
      //   })
      // }

      const filteredUser = users.filter(
        (user: { userId: string }) =>
          !roomMembers.some((roomMember) => {
            return roomMember?.user?.id === user.userId
          })
      )

      if (
        getRoom?.types != null &&
        getRoom.types.maxUsersLicensed === true &&
        getRoom.types.maxUsers != null &&
        getRoom.roomMembers.length + filteredUser.length >
          getRoom.types.maxUsers
      ) {
        return res.json({
          status: 7,
        })
      }

      if (!idSuperAdmin) {
        if (getRoom.floor.business.id !== UserBusinessId) {
          return res.json({
            status: 2,
          })
        }
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userWhoAddID,
        })
        .getOne()

      const getAddingUsers = (await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id IN (:...ids)', {
          ids: filteredUser.map((user: { userId: string }) => user.userId),
        })
        .getMany()) as User[]

      await Promise.all(
        getAddingUsers.map(async (AddingUser) => {
          const fendedUser = filteredUser.find(
            (user: { userId: string }) => AddingUser.id === user.userId
          )
          if (
            fendedUser.roomRole == null ||
            !Number.isInteger(Number(fendedUser.roomRole))
          ) {
            return
          }

          const getUserRoomMembers = await transactionalEntityManager
            .getRepository(RoomsMembers)
            .createQueryBuilder('roomsMembers')
            .leftJoinAndSelect('roomsMembers.user', 'user')
            .leftJoinAndSelect('roomsMembers.room', 'room')
            .leftJoinAndSelect('room.types', 'types')
            .leftJoinAndSelect('room.floor', 'floor')
            .leftJoinAndSelect('floor.business', 'business')
            .select([
              'roomsMembers.id',
              'business.id',
              'user.id',
              'room.id',
              'floor.id',
              'types.id',
              'types.isConference',
            ])
            .where('user.id = :id', {
              id: AddingUser.id,
            })
            .andWhere('business.id = :businessId', {
              businessId: UserBusinessId,
            })
            .andWhere('types.isConference = :isConference', {
              isConference: false,
            })
            .getMany()

          if (
            getRoom.types.isConference === false &&
            getUserRoomMembers.length > 0
          ) {
            return
          }

          if (fendedUser.roomRole === 0) {
            await noManagerForRoom({ roomId })
          }
          const newDate = new Date()
          const newRoomMembers = new RoomsMembers()
          newRoomMembers.user = AddingUser
          newRoomMembers.room = getRoom
          newRoomMembers.isManager = fendedUser.roomRole === 0
          newRoomMembers.isModerator = fendedUser.roomRole === 1
          newRoomMembers.isUser = fendedUser.roomRole === 2
          newRoomMembers.isGuest = fendedUser.roomRole === 3
          newRoomMembers.dateCreated = newDate
          newRoomMembers.idUserCreated = getUser
          newRoomMembers.dateModified = newDate
          newRoomMembers.idUserModified = getUser

          await transactionalEntityManager
            .getRepository(RoomsMembers)
            .save(newRoomMembers)
        })
      )

      getRoom.floor.dateModified = new Date()

      await transactionalEntityManager.getRepository(Floors).save(getRoom.floor)

      await db.queryResultCache.remove([roomId])
      await db.queryResultCache.remove([getRoom.floor.id])

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
