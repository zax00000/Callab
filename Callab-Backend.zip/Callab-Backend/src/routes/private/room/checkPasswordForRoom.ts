import bcrypt from 'bcryptjs'
import { Request, Response } from 'express'
import db from '../../../database'
import { Rooms } from '../../../database/entity/rooms'

export async function checkPasswordForRoom(req: Request, res: Response) {
  try {
    const { roomId, password } = req.body

    const getRoom = await db
      .getRepository(Rooms)
      .createQueryBuilder('rooms')
      .where('rooms.id = :id', {
        id: roomId,
      })
      .getOne()

    if (getRoom == null) {
      return res.json({
        status: 3,
      })
    }

    if (getRoom.isSecured === false) {
      return res.json({
        status: 0,
        access: true,
      })
    }

    const validPassword = await bcrypt.compare(password, getRoom.password)

    return res.json({
      status: 0,
      access: validPassword,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
