import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Floors } from '../../../database/entity/floors'
import { Rooms } from '../../../database/entity/rooms'

export async function deleteRoom(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const removedRoomId = req.params.roomId

      const { business: businessId, superAdmin: idSuperAdmin } = <
        UserFromToken
      >req.user

      const getRoom = await transactionalEntityManager
        .getRepository(Rooms)
        .createQueryBuilder('rooms')
        .leftJoinAndSelect('rooms.floor', 'floors')
        .leftJoinAndSelect('floors.business', 'business')
        .where('rooms.id = :id', {
          id: removedRoomId,
        })
        .getOne()

      if (!idSuperAdmin) {
        if (
          !(
            getRoom &&
            getRoom.floor &&
            getRoom.floor.business &&
            getRoom.floor.business.id &&
            getRoom.floor.business.id === businessId
          )
        ) {
          return res.json({
            status: 3,
          })
        }
      }

      const newDate = new Date()

      const floor = getRoom.floor

      floor.dateModified = newDate

      const getRemovingRoom = await transactionalEntityManager
        .getRepository(Rooms)
        .createQueryBuilder('rooms')
        .where('rooms.id = :id', {
          id: removedRoomId,
        })
        .getOne()

      await transactionalEntityManager
        .getRepository(Rooms)
        .remove(getRemovingRoom)
      await transactionalEntityManager.getRepository(Floors).save(floor)

      await db.queryResultCache.remove([floor.id])

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
