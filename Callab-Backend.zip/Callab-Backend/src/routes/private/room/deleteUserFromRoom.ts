import { Request, Response } from 'express'
import { TemporaryUser } from '../../../database/entity/temporaryUser'
import db from '../../../database'
import { Floors } from '../../../database/entity/floors'
import { Rooms } from '../../../database/entity/rooms'
import { RoomsMembers } from '../../../database/entity/roomsMembers'
import { UserFromToken } from '../../../interfaces/user'

export async function deleteUserFromRoom(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { roomId, userId } = req.params

      const { business: UserBusinessId, superAdmin: idSuperAdmin } = <
        UserFromToken
      >req.user

      const getRoom = await transactionalEntityManager
        .getRepository(Rooms)
        .createQueryBuilder('rooms')
        .leftJoinAndSelect('rooms.floor', 'floors')
        .leftJoinAndSelect('floors.business', 'business')
        .leftJoinAndSelect('rooms.roomMembers', 'roomsMembers')
        .leftJoinAndSelect('roomsMembers.user', 'user')
        .leftJoinAndSelect('roomsMembers.temporaryUser', 'temporaryUser')
        .select([
          'floors',
          'business.id',
          'rooms',
          'roomsMembers',
          'user.id',
          'temporaryUser.id',
        ])
        .where('rooms.id = :id', {
          id: roomId,
        })
        .getOne()

      if (!idSuperAdmin) {
        if (getRoom.floor.business.id !== UserBusinessId) {
          return res.json({
            status: 3,
          })
        }
      }

      let RoomMembersToDelete = getRoom.roomMembers.find(
        (roomMember) => roomMember?.user?.id === userId
      )
      if (RoomMembersToDelete == null) {
        RoomMembersToDelete = getRoom.roomMembers.find(
          (roomMember) => roomMember?.temporaryUser?.id === userId
        )
        await transactionalEntityManager
          .getRepository(TemporaryUser)
          .remove(RoomMembersToDelete.temporaryUser)
      }

      getRoom.floor.dateModified = new Date()
      await transactionalEntityManager.getRepository(Floors).save(getRoom.floor)

      await transactionalEntityManager
        .getRepository(RoomsMembers)
        .remove(RoomMembersToDelete)

      await db.queryResultCache.remove([roomId])
      await db.queryResultCache.remove([getRoom.floor.id])

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
