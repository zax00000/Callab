import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Floors } from '../../../database/entity/floors'
import { Rooms } from '../../../database/entity/rooms'
import { User } from '../../../database/entity/user'

export async function editCloseRoom(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const roomId = req.params.roomId

      const { id: userId } = <UserFromToken>req.user

      const { isClosed } = req.body

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      const getEditedRoom = await transactionalEntityManager
        .getRepository(Rooms)
        .createQueryBuilder('rooms')
        .leftJoinAndSelect('rooms.floor', 'floors')
        .leftJoinAndSelect('rooms.roomMembers', 'roomMembers')
        .leftJoinAndSelect('roomMembers.user', 'user')
        .where('rooms.id = :id', {
          id: roomId,
        })
        .getOne()

      if (!getEditedRoom) {
        return res.json({ status: 3 })
      }
      const newDate = new Date()

      const userRoomMembers = getEditedRoom.roomMembers.find(
        (roomMember) => roomMember?.user?.id === userId
      )
      if (userRoomMembers == null) {
        return res.json({ status: 2 })
      }

      if (userRoomMembers.isModerator || userRoomMembers.isManager) {
        getEditedRoom.isClosed = isClosed
        getEditedRoom.idUserModified = getUser
        getEditedRoom.dateModified = newDate
        getEditedRoom.floor.dateModified = newDate

        const newRoomResponse = await transactionalEntityManager
          .getRepository(Rooms)
          .save(getEditedRoom)
        await transactionalEntityManager
          .getRepository(Floors)
          .save(getEditedRoom.floor)

        await db.queryResultCache.remove([getEditedRoom.floor.id])

        return res.json({
          status: 0,
          roomId: newRoomResponse.id,
        })
      }

      return res.json({
        status: 2,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
