import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Rooms } from '../../../database/entity/rooms'
import { User } from '../../../database/entity/user'

export async function editMutedAndCamDisallowedRoom(
  req: Request,
  res: Response
) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { roomId } = req.params

      const { id: userId } = <UserFromToken>req.user

      const { isMuted, camDisallowed } = req.body

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      const getEditedRoom = await transactionalEntityManager
        .getRepository(Rooms)
        .createQueryBuilder('rooms')
        .leftJoinAndSelect('rooms.floor', 'floors')
        .leftJoinAndSelect('rooms.roomMembers', 'roomMembers')
        .leftJoinAndSelect('roomMembers.user', 'user')
        .where('rooms.id = :id', {
          id: roomId,
        })
        .getOne()

      if (!getEditedRoom) {
        return res.json({ status: 3 })
      }
      const newDate = new Date()

      const userRoomMembers = getEditedRoom.roomMembers.find(
        (roomMember) => roomMember?.user?.id === userId
      )
      if (userRoomMembers == null) {
        return res.json({ status: 2 })
      }

      if (userRoomMembers.isModerator || userRoomMembers.isManager) {
        if (isMuted != null) {
          getEditedRoom.isMuted = Boolean(isMuted)
        }
        if (camDisallowed != null) {
          getEditedRoom.camDisallowed = Boolean(camDisallowed)
        }
        getEditedRoom.idUserModified = getUser
        getEditedRoom.dateModified = newDate

        const newRoomResponse = await transactionalEntityManager
          .getRepository(Rooms)
          .save(getEditedRoom)

        return res.json({
          status: 0,
          roomId: newRoomResponse.id,
        })
      }

      return res.json({
        status: 2,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
