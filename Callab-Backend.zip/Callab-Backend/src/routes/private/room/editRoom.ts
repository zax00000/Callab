import bcrypt from 'bcryptjs'
import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Floors } from '../../../database/entity/floors'
import { Rooms } from '../../../database/entity/rooms'
import { RoomsTypes } from '../../../database/entity/roomsTypes'
import { User } from '../../../database/entity/user'
import sendMail from '../../../sendMail'
import roomPasswordChange from '../../../sendMail/roomPasswordChange'

export async function editRoom(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const roomId = req.params.roomId

      const {
        business: businessId,
        superAdmin: idSuperAdmin,
        id: userId,
      } = <UserFromToken>req.user

      const { floorId, typesId, isSecured, password } = req.body

      if (!idSuperAdmin) {
        const getRoom = await transactionalEntityManager
          .getRepository(Rooms)
          .createQueryBuilder('rooms')
          .leftJoinAndSelect('rooms.floor', 'floors')
          .leftJoinAndSelect('floors.business', 'business')
          .where('rooms.id = :id', {
            id: roomId,
          })
          .getOne()
        if (
          !(
            getRoom &&
            getRoom.floor &&
            getRoom.floor.business &&
            getRoom.floor.business.id &&
            getRoom.floor.business.id === businessId
          )
        ) {
          return res.json({
            status: 3,
          })
        }
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()
      let getFloor
      if (floorId) {
        getFloor = await transactionalEntityManager
          .getRepository(Floors)
          .createQueryBuilder('floors')
          .where('floors.id = :id', {
            id: floorId,
          })
          .getOne()
        if (!getFloor) {
          return res.json({
            status: 3,
          })
        }
      }

      let getRoomType
      if (typesId != null) {
        getRoomType = await transactionalEntityManager
          .getRepository(RoomsTypes)
          .createQueryBuilder('roomTypes')
          .where('roomTypes.id = :id', {
            id: typesId,
          })
          .getOne()

        if (!getRoomType) {
          return res.json({
            status: 3,
          })
        }
      }

      const getEditedRoomBeforeChange = await transactionalEntityManager
        .getRepository(Rooms)
        .createQueryBuilder('rooms')
        .leftJoinAndSelect('rooms.floor', 'floor')
        .leftJoinAndSelect('floor.business', 'business')
        .leftJoinAndSelect('rooms.roomMembers', 'roomMembers')
        .leftJoinAndSelect('roomMembers.user', 'user')
        .where('rooms.id = :id', {
          id: roomId,
        })
        .getOne()

      const getEditedRoom = { ...getEditedRoomBeforeChange }

      if (!getEditedRoom) {
        return res.json({ status: 3 })
      }
      const newDate = new Date()
      if (floorId) {
        getEditedRoom.floor = getFloor
      }
      if (typesId) {
        getEditedRoom.types = getRoomType
      }

      ;[
        'name',
        'coordX',
        'coordY',
        'width',
        'height',
        'rotation',
        'scale',
        'color',
        'isClosed',
        'isSecured',
      ].forEach((fieldName) => {
        if (
          req.body[fieldName] != null &&
          req.body[fieldName].toString().length > 0
        ) {
          getEditedRoom[fieldName as 'name'] = req.body[fieldName]
        }
      })

      if (isSecured != null && password != null && password.length > 0) {
        getEditedRoom.password = await bcrypt.hash(password, 10)
        const usersEmailInRoom = getEditedRoom.roomMembers
          .filter((roomMember) => roomMember.user != null)
          .map((roomMember) => roomMember.user.email)
        usersEmailInRoom.forEach((email) => {
          sendMail.sendMail({
            to: email,
            subject: 'Password in room was changed',
            text: 'Password in room was changed',
            html: roomPasswordChange(
              password,
              getEditedRoomBeforeChange.floor.business.name,
              getEditedRoom.name
            ),
          })
        })
      }

      if (isSecured != null && isSecured === false) {
        getEditedRoom.isSecured = false
        getEditedRoom.password = null
      }

      getEditedRoom.idUserModified = getUser
      getEditedRoom.dateModified = newDate
      getEditedRoom.floor.dateModified = newDate

      const newRoomResponse = await transactionalEntityManager
        .getRepository(Rooms)
        .save(getEditedRoom)

      await transactionalEntityManager
        .getRepository(Floors)
        .save(getEditedRoom.floor)

      await db.queryResultCache.remove([getEditedRoom.floor.id])

      return res.json({
        status: 0,
        roomId: newRoomResponse.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
