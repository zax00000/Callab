import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Floors } from '../../../database/entity/floors'
import { Rooms } from '../../../database/entity/rooms'
import { RoomsMembers } from '../../../database/entity/roomsMembers'
import { User } from '../../../database/entity/user'
import { noManagerForRoom } from '../../../utils/noManagerForRoom'

export async function editUserInRoom(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { roomId, userId: editUser, roomRole } = req.body

      const {
        business: UserBusinessId,
        superAdmin: idSuperAdmin,
        id: userID,
      } = <UserFromToken>req.user

      const getRoom = await transactionalEntityManager
        .getRepository(Rooms)
        .createQueryBuilder('rooms')
        .leftJoinAndSelect('rooms.floor', 'floors')
        .leftJoinAndSelect('floors.business', 'business')
        .leftJoinAndSelect('rooms.roomMembers', 'roomsMembers')
        .leftJoinAndSelect('roomsMembers.user', 'user')
        .select(['floors', 'business.id', 'rooms', 'roomsMembers', 'user.id'])
        .where('rooms.id = :id', {
          id: roomId,
        })
        .getOne()

      if (!idSuperAdmin) {
        if (getRoom.floor.business.id !== UserBusinessId) {
          return res.json({
            status: 3,
          })
        }
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userID,
        })
        .getOne()

      const getEditUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: editUser,
        })
        .getOne()

      if (roomRole == null || !Number.isInteger(Number(roomRole))) {
        return res.json({
          status: 5,
        })
      }

      const newDate = new Date()

      const getUserRoomMembers = await transactionalEntityManager
        .getRepository(RoomsMembers)
        .createQueryBuilder('roomsMembers')
        .leftJoinAndSelect('roomsMembers.user', 'user')
        .leftJoinAndSelect('roomsMembers.room', 'room')
        .where('roomsMembers.user.id = :idUser', {
          idUser: editUser,
        })
        .andWhere('roomsMembers.room.id = :idRoom', {
          idRoom: roomId,
        })
        .getOne()

      if (!getUserRoomMembers) {
        return res.json({
          status: 3,
        })
      }

      if (Number(roomRole) === 0) {
        await noManagerForRoom({ roomId })
      }

      getUserRoomMembers.isManager = Number(roomRole) === 0
      getUserRoomMembers.isModerator = Number(roomRole) === 1
      getUserRoomMembers.isUser = Number(roomRole) === 2
      getUserRoomMembers.isGuest = Number(roomRole) === 3
      getUserRoomMembers.dateModified = newDate
      getUserRoomMembers.idUserModified = getUser
      getUserRoomMembers.idUserModified = getEditUser

      const RoomsMembersToLog = await transactionalEntityManager
        .getRepository(RoomsMembers)
        .save(getUserRoomMembers)

      getRoom.floor.dateModified = new Date()

      await transactionalEntityManager.getRepository(Floors).save(getRoom.floor)

      await db.queryResultCache.remove([roomId])
      await db.queryResultCache.remove([getRoom.floor.id])

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
