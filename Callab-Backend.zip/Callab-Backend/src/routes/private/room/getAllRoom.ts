import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Business } from '../../../database/entity/business'

export async function getAllRoom(req: Request, res: Response) {
  try {
    const businessId = req.params.businessId

    const {
      business: UserBusinessId,
      superAdmin: idSuperAdmin,
      id: userId,
    } = <UserFromToken>req.user

    const getBusiness = await db
      .getRepository(Business)
      .createQueryBuilder('business')
      .leftJoinAndSelect('business.floors', 'floors')
      .leftJoinAndSelect('floors.rooms', 'rooms')
      .leftJoinAndSelect('rooms.roomMembers', 'roomMembers')
      .leftJoinAndSelect('roomMembers.user', 'user')
      // .leftJoinAndSelect('roomMembers.temporaryUser', 'temporaryUser')
      // .leftJoinAndSelect('user.userData', 'userData')
      // .leftJoinAndSelect('userData.business', 'businessForUserData')
      .leftJoinAndSelect('rooms.types', 'roomsTypes')
      .select([
        'floors.id',
        'roomMembers.isUser',
        'roomMembers.isModerator',
        'roomMembers.isManager',
        'roomMembers.isGuest',
        'user.id',
        // 'temporaryUser',
        // 'userData',
        // 'businessForUserData',
        'business.id',
        'rooms',
        'roomsTypes',
      ])
      .where('business.id = :id', {
        id: idSuperAdmin ? businessId : UserBusinessId,
      })
      .getOne()

    if (!getBusiness) {
      return res.json({
        status: 3,
      })
    }

    let rooms = [] as any[]

    getBusiness.floors.forEach((floor) => {
      rooms = [
        ...floor.rooms.map((room) => ({
          ...room,
          roomMembers: room.roomMembers
            .filter(({ user }) => user != null)
            .map(
              ({
                user,
                isUser,
                isModerator,
                isManager,
                isGuest,
                // temporaryUser,
              }) => {
                return {
                  userId: user?.id || '',
                  roomRole: isUser
                    ? 2
                    : isModerator
                    ? 1
                    : isManager
                    ? 0
                    : isGuest
                    ? 3
                    : 2,
                }
              }
            ),
          password: undefined,
          floorId: floor.id,
        })),
        ...rooms,
      ]
    })

    return res.json({
      status: 0,
      rooms,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
