import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Floors } from '../../../database/entity/floors'

export async function getAllRoomsForFloor(req: Request, res: Response) {
  try {
    const floorId = req.params.floorId

    const { business: UserBusinessId, superAdmin: idSuperAdmin } = <
      UserFromToken
    >req.user

    const getFloor = await db
      .getRepository(Floors)
      .createQueryBuilder('floors')
      .leftJoinAndSelect('floors.rooms', 'rooms')
      .leftJoinAndSelect('rooms.idUserCreated', 'userCreated')
      .leftJoinAndSelect('rooms.idUserModified', 'userModified')
      .leftJoinAndSelect('rooms.roomMembers', 'roomMembers')
      .leftJoinAndSelect('roomMembers.user', 'user')
      .leftJoinAndSelect('roomMembers.temporaryUser', 'temporaryUser')
      .leftJoinAndSelect('floors.business', 'business')
      .leftJoinAndSelect('rooms.types', 'roomsTypes')
      .select([
        'floors',
        'roomsTypes',
        'business.id',
        'rooms',
        'userCreated',
        'userModified',
        'roomMembers',
        'user',
        'temporaryUser',
      ])
      .where('floors.id = :id', {
        id: floorId,
      })
      .getOne()

    if (!getFloor) {
      return res.json({
        status: 3,
      })
    }

    if (!idSuperAdmin) {
      if (getFloor.business.id !== UserBusinessId) {
        return res.json({
          status: 3,
        })
      }
    }

    const rooms = getFloor.rooms.map((room) => ({
      ...room,
      roomMembers: room.roomMembers.map((roomMember) => roomMember?.user?.id),
      idUserCreated: undefined,
      idUserModified: undefined,
      userCreated: room.idUserCreated ? room.idUserCreated.email : '',
      userModified: room.idUserModified ? room.idUserModified.email : '',
      password: undefined,
    }))

    return res.json({
      status: 0,
      rooms,
    })
  } catch (error) {
    console.error(error.message)
    return res.json({
      status: 6,
    })
  }
}
