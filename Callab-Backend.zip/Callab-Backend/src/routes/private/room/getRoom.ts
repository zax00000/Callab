import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Rooms } from '../../../database/entity/rooms'

export async function getRoom(req: Request, res: Response) {
  try {
    const roomId = req.params.roomId

    const { business: UserBusinessId, superAdmin: idSuperAdmin } = <
      UserFromToken
    >req.user

    if (!idSuperAdmin) {
      const getRoom = await db
        .getRepository(Rooms)
        .createQueryBuilder('rooms')
        .leftJoinAndSelect('rooms.floor', 'floors')
        .leftJoinAndSelect('floors.business', 'business')
        .where('rooms.id = :id', {
          id: roomId,
        })
        .getOne()
      if (
        !(
          getRoom &&
          getRoom.floor &&
          getRoom.floor.business &&
          getRoom.floor.business.id &&
          getRoom.floor.business.id === UserBusinessId
        )
      ) {
        return res.json({
          status: 3,
        })
      }
    }

    const getRoom = await db
      .getRepository(Rooms)
      .createQueryBuilder('rooms')
      .leftJoinAndSelect('rooms.floor', 'floors')
      .leftJoinAndSelect('floors.business', 'business')
      .leftJoinAndSelect('rooms.types', 'roomsTypes')
      .leftJoinAndSelect('rooms.roomMembers', 'roomsMembers')
      .leftJoinAndSelect('roomsMembers.user', 'user')
      .leftJoinAndSelect('roomsMembers.temporaryUser', 'temporaryUser')
      .select([
        'floors.id',
        'business.id',
        'roomsTypes',
        'rooms',
        'roomsMembers',
        'user.id',
        'temporaryUser.id',
      ])
      .where('rooms.id = :id', {
        id: roomId,
      })
      .getOne()

    let managerId
    const moderatorsId = [] as string[]
    const usersId = [] as string[]
    const guestId = [] as string[]
    getRoom.roomMembers.forEach((roomMember) => {
      const userId = roomMember?.user?.id
        ? roomMember?.user?.id
        : roomMember?.temporaryUser?.id || ''
      if (roomMember.isManager) {
        managerId = userId
        return
      }
      if (roomMember.isModerator) {
        moderatorsId.push(userId)
        return
      }
      if (roomMember.isUser) {
        usersId.push(userId)
        return
      }
      if (roomMember.isGuest) {
        guestId.push(userId)
        return
      }
    })
    return res.json({
      status: 0,
      room: {
        ...getRoom,
        password: undefined,
        roomMembers: undefined,
        managerId,
        moderatorsId,
        usersId,
        guestId,
      },
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
