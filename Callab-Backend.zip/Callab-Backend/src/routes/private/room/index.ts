import { Express } from 'express'
import RolesChecker from '../../../middleware/RolesChecker'
import { addNewRoom } from './addNewRoom'
import { addUsersToRoom } from './addUsersToRoom'
import { addUserToRoom } from './addUserToRoom'
import { checkPasswordForRoom } from './checkPasswordForRoom'
import { deleteRoom } from './deleteRoom'
import { deleteUserFromRoom } from './deleteUserFromRoom'
import { editCloseRoom } from './editCloseRoom'
import { editMutedAndCamDisallowedRoom } from './editMutedAndCamDisallowedRoom'
import { editRoom } from './editRoom'
import { editUserInRoom } from './editUserInRoom'
import { getAllRoom } from './getAllRoom'
import { getAllRoomsForFloor } from './getAllRoomsForFloor'
import { GetAllTemporaryUserInRoom } from './GetAllTemporaryUserInRoom'
import { GetAllUserInRoom } from './GetAllUserInRoom'
import { getRoom } from './getRoom'

export default (app: Express) => {
  /**
   * @openapi
   * /private/room/{roomId}:
   *  delete:
   *    tags:
   *      - room
   *    description: Delete room.
   *    summary: Delete room.
   *    parameters:
   *      - in: path
   *        name: roomId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.delete('/room/:roomId', RolesChecker('DeleteRoom'), deleteRoom)

  /**
   * @openapi
   * /private/room/new:
   *  post:
   *    tags:
   *      - room
   *    description: Create Room
   *    summary: Create Room
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/NewRoom'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  NewRoom:           # <----------
   *    type: object
   *    required:
   *      - floorId
   *      - typesId
   *      - name
   *      - isSecured
   *      - password
   *      - coordX
   *      - coordY
   *      - width
   *      - height
   *      - rotation
   *      - scale
   *      - color
   *    properties:
   *      floorId:
   *        type: string
   *      typesId:
   *        type: string
   *      name:
   *        type: string
   *      isSecured:
   *        type: boolean
   *      password:
   *        type: string
   *      coordX:
   *        type: number
   *      coordY:
   *        type: number
   *      width:
   *        type: number
   *      height:
   *        type: number
   *      rotation:
   *        type: number
   *      scale:
   *        type: number
   *      color:
   *        type: string
   */
  app.post('/room/new', RolesChecker('AddNewRoom'), addNewRoom)

  /**
   * @openapi
   * /private/room/{roomId}:
   *  post:
   *    tags:
   *      - room
   *    description: Edit Room
   *    summary: Edit Room
   *    parameters:
   *      - in: path
   *        name: roomId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/EditRoom'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  EditRoom:           # <----------
   *    type: object
   *    required:
   *    properties:
   *      floorId:
   *        type: string
   *      idTypes:
   *        type: string
   *      name:
   *        type: string
   *      isSecured:
   *        type: boolean
   *      isClosed:
   *        type: boolean
   *      password:
   *        type: string
   *      coordX:
   *        type: number
   *      coordY:
   *        type: number
   *      width:
   *        type: number
   *      height:
   *        type: number
   *      rotation:
   *        type: number
   *      scale:
   *        type: number
   *      color:
   *        type: string
   */
  app.post('/room/:roomId', RolesChecker('EditRoom'), editRoom)

  /**
   * @openapi
   * /private/room/{roomId}:
   *  get:
   *    tags:
   *      - room
   *    description: Get Room.
   *    summary: Get Room.
   *    parameters:
   *      - in: path
   *        name: roomId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/room/:roomId', RolesChecker('GetRoom'), getRoom)

  /**
   * @openapi
   * /private/room/business/{businessId}:
   *  get:
   *    tags:
   *      - room
   *    description: Get all room in business.
   *    summary: Get all room business.
   *    parameters:
   *      - in: path
   *        name: businessId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/room/business/:businessId', RolesChecker('GetAllRoom'), getAllRoom)

  /**
   * @openapi
   * /private/room/floor/{floorId}:
   *  get:
   *    tags:
   *      - room
   *    description: Get all room in floor.
   *    summary: Get all room in floor.
   *    parameters:
   *      - in: path
   *        name: floorId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/room/floor/:floorId',
    RolesChecker('GetAllRoomsForFloor'),
    getAllRoomsForFloor
  )

  /**
   * @openapi
   * /private/user/room/{roomId}:
   *  get:
   *    tags:
   *      - room
   *    description: Get all user in room.
   *    summary: Get all user in room.
   *    parameters:
   *      - in: path
   *        name: roomId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/user/room/:roomId', GetAllUserInRoom)

  /**
   * @openapi
   * /private/user/temporary-user/{roomId}:
   *  get:
   *    tags:
   *      - room
   *    description: Get all temporary user in room.
   *    summary: Get all temporary user in room.
   *    parameters:
   *      - in: path
   *        name: roomId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/user/temporary-user/:roomId', GetAllTemporaryUserInRoom)

  /**
   * @openapi
   * /private/room/user/add:
   *  post:
   *    tags:
   *      - room
   *    description: Add User to Room
   *    summary: Add User to Room
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/AddUsersToRoom'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  AddUsersToRoom:           # <----------
   *    type: object
   *    required:
   *      - userId
   *      - roomId
   *      - roomRole
   *    properties:
   *      userId:
   *        type: string
   *      roomId:
   *        type: string
   *      roomRole:
   *        summary: 0 - Admin, 1 - Moderator, 2 - User, 3 - Guest
   *        type: number
   */
  app.post('/room/user/add', RolesChecker('AddUserToRoom'), addUserToRoom)

  /**
   * @openapi
   * /private/room/users/add:
   *  post:
   *    tags:
   *      - room
   *    description: Add Users to Room
   *    summary: Add Users to Room
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/AddUserToRoom'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  AddUserToRoom:           # <----------
   *    type: object
   *    required:
   *      - userId
   *      - roomId
   *      - roomRole
   *    properties:
   *      roomId:
   *        type: string
   *      users:
   *        type: array
   *        items:
   *          type: object
   *          properties:
   *            userId:
   *              type: string
   *            roomRole:
   *              summary: 0 - Admin, 1 - Moderator, 2 - User, 3 - Guest
   *              type: number
   */
  app.post('/room/users/add', RolesChecker('AddUsersToRoom'), addUsersToRoom)

  /**
   * @openapi
   * /private/room/user/edit:
   *  post:
   *    tags:
   *      - room
   *    description: Edit User RoomMembers
   *    summary: Edit User RoomMembers
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/EditUserToRoom'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  EditUserToRoom:           # <----------
   *    type: object
   *    required:
   *      - userId
   *      - roomId
   *      - roomRole
   *    properties:
   *      userId:
   *        type: integer
   *      roomId:
   *        type: integer
   *      roomRole:
   *        summary: 0 - Admin, 1 - Moderator, 2 - User, 3 - Guest
   *        type: number
   */
  app.post('/room/user/edit', RolesChecker('EditUserInRoom'), editUserInRoom)

  /**
   * @openapi
   * /private/room/{roomId}/user/{userId}:
   *  delete:
   *    tags:
   *      - room
   *    description: Delete user from room.
   *    summary: Delete user from room.
   *    parameters:
   *      - in: path
   *        name: userId
   *        schema:
   *          type: integer
   *      - in: path
   *        name: roomId
   *        schema:
   *          type: integer
   *    responses:
   *      200:
   *        description: Ok
   */
  app.delete(
    '/room/:roomId/user/:userId',
    RolesChecker('DeleteUserFromRoom'),
    deleteUserFromRoom
  )

  /**
   * @openapi
   * /private/password/room:
   *  post:
   *    tags:
   *      - room
   *    description: Check password for room
   *    summary: Check password for room
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/passwordForRoom'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  passwordForRoom:           # <----------
   *    type: object
   *    required:
   *      -roomId
   *      -password
   *    properties:
   *      roomId:
   *        type: string
   *      password:
   *        type: string
   */
  app.post(
    '/password/room',
    RolesChecker('CheckPasswordForRoom'),
    checkPasswordForRoom
  )

  /**
   * @openapi
   * /private/close/room/{roomId}:
   *  post:
   *    tags:
   *      - room
   *    description: Edit Close Room
   *    summary: Edit Close Room
   *    parameters:
   *      - in: path
   *        name: roomId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/CloseRoom'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  CloseRoom:           # <----------
   *    type: object
   *    required:
   *    properties:
   *      isClosed:
   *        type: boolean
   */
  app.post('/close/room/:roomId', RolesChecker('CloseRoom'), editCloseRoom)

  /**
   * @openapi
   * /private/MutedAndCamDisallowed/room/{roomId}:
   *  post:
   *    tags:
   *      - room
   *    description: Edit isMuted And CamDisallowed in Room
   *    summary: Edit isMuted And CamDisallowed in Room
   *    parameters:
   *      - in: path
   *        name: roomId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/MutedAndCamDisallowedRoom'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  MutedAndCamDisallowedRoom:           # <----------
   *    type: object
   *    required:
   *    properties:
   *      isMuted:
   *        type: boolean
   *      camDisallowed:
   *        type: boolean
   */
  app.post(
    '/MutedAndCamDisallowed/room/:roomId',
    RolesChecker('MutedAndCamDisallowed'),
    editMutedAndCamDisallowedRoom
  )
}
