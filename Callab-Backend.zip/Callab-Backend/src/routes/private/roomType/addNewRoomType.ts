import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { RoomsTypes } from '../../../database/entity/roomsTypes'
import { User } from '../../../database/entity/user'

export async function addNewRoomType(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { id: userId } = <UserFromToken>req.user

      const requireFields = [] as string[]
      ;[
        'name',
        'maxUsersLicensed',
        'maxUsers',
        'inviteOnly',
        'hasManager',
        'hasModerators',
        'isConference',
        'enumNumber',
      ].forEach((fieldName) => {
        if (
          !(
            req.body[fieldName] != null &&
            req.body[fieldName].toString().length > 0
          )
        ) {
          requireFields.push(fieldName)
        }
      })

      if (requireFields.length > 0) {
        return res.json({
          status: 5,
          message: `RequireFields: ${requireFields}`,
        })
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      const {
        name,
        maxUsersLicensed,
        maxUsers,
        inviteOnly,
        hasManager,
        hasModerators,
        isConference,
        enumNumber,
      } = req.body

      const newRoomType = new RoomsTypes()

      const newDate = new Date()

      newRoomType.name = name
      newRoomType.maxUsersLicensed = maxUsersLicensed
      newRoomType.maxUsers = maxUsers
      newRoomType.inviteOnly = inviteOnly
      newRoomType.hasManager = hasManager
      newRoomType.roomTypeEnum = enumNumber
      newRoomType.isConference = isConference
      newRoomType.hasModerators = hasModerators
      newRoomType.idUserCreated = getUser
      newRoomType.idUserModified = getUser
      newRoomType.dateModified = newDate
      newRoomType.dateCreated = newDate

      const newRoomTypesResponse = await transactionalEntityManager
        .getRepository(RoomsTypes)
        .save(newRoomType)

      return res.json({
        status: 0,
        roomTypeId: newRoomTypesResponse.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
