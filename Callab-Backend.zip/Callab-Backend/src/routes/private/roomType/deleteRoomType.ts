import { Request, Response } from 'express'
import db from '../../../database'
import { RoomsTypes } from '../../../database/entity/roomsTypes'

export async function deleteRoomType(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const removedRoomTypeId = req.params.roomTypeId

      const getRemovingRoomType = await transactionalEntityManager
        .getRepository(RoomsTypes)
        .createQueryBuilder('roomsTypes')
        .where('roomsTypes.id = :id', {
          id: removedRoomTypeId,
        })
        .getOne()

      await transactionalEntityManager
        .getRepository(RoomsTypes)
        .remove(getRemovingRoomType)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
