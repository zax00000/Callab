import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { RoomsTypes } from '../../../database/entity/roomsTypes'
import { User } from '../../../database/entity/user'

export async function editRoomType(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { roomTypeId } = req.params

      const { id: userId } = <UserFromToken>req.user

      const getEditedRoomType = await transactionalEntityManager
        .getRepository(RoomsTypes)
        .createQueryBuilder('roomsTypes')
        .where('roomsTypes.id = :id', {
          id: roomTypeId,
        })
        .getOne()

      if (!getEditedRoomType) {
        return res.json({
          status: 3,
        })
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      const newDate = new Date()
      ;[
        'name',
        'maxUsersLicensed',
        'maxUsers',
        'inviteOnly',
        'hasManager',
        'hasModerators',
        'isConference',
      ].forEach((fieldName) => {
        if (
          req.body[fieldName] != null &&
          req.body[fieldName].toString().length > 0
        ) {
          getEditedRoomType[fieldName as 'name'] = req.body[fieldName]
        }
      })
      getEditedRoomType.idUserModified = getUser
      getEditedRoomType.dateModified = newDate

      const newRoomTypesResponse = await transactionalEntityManager
        .getRepository(RoomsTypes)
        .save(getEditedRoomType)

      return res.json({
        status: 0,
        roomTypeId: newRoomTypesResponse.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
