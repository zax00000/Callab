import { Request, Response } from 'express'
import db from '../../../database'
import { RoomsTypes } from '../../../database/entity/roomsTypes'

export async function getAllRoomType(req: Request, res: Response) {
  try {
    const getRoomTypes = await db
      .getRepository(RoomsTypes)
      .createQueryBuilder('roomsTypes')
      .leftJoinAndSelect('roomsTypes.idUserCreated', 'UserCreated')
      .leftJoinAndSelect('roomsTypes.idUserModified', 'UserModified')
      .getMany()

    if (!getRoomTypes) {
      return res.json({
        status: 3,
      })
    }

    return res.json({
      status: 0,
      roomTypes: getRoomTypes.map((roomType) => ({
        ...roomType,
        idUserCreated: undefined,
        idUserModified: undefined,
        userCreated: roomType.idUserCreated ? roomType.idUserCreated.email : '',
        userModified: roomType.idUserModified
          ? roomType.idUserModified.email
          : '',
      })),
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
