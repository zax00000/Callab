import { Request, Response } from 'express'
import db from '../../../database'
import { RoomsTypes } from '../../../database/entity/roomsTypes'

export async function getAllRoomTypePagin(req: Request, res: Response) {
  try {
    const { skip, take, search } = req.params

    const getRoomTypes = await db
      .getRepository(RoomsTypes)
      .createQueryBuilder('roomsTypes')
      .leftJoinAndSelect('roomsTypes.idUserCreated', 'UserCreated')
      .leftJoinAndSelect('roomsTypes.idUserModified', 'UserModified')
      .skip(Number(skip))
      .take(Number(take))
      .getMany()

    if (!getRoomTypes) {
      return res.json({
        status: 3,
      })
    }

    const count = await db
      .getRepository(RoomsTypes)
      .createQueryBuilder('roomsTypes')
      .getCount()

    return res.json({
      status: 0,
      roomTypes: getRoomTypes.map((roomType) => ({
        ...roomType,
        idUserCreated: undefined,
        idUserModified: undefined,
        userCreated: roomType.idUserCreated ? roomType.idUserCreated.email : '',
        userModified: roomType.idUserModified
          ? roomType.idUserModified.email
          : '',
      })),
      count,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
