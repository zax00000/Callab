import { Request, Response } from 'express'
import db from '../../../database'
import { RoomsTypes } from '../../../database/entity/roomsTypes'

export async function getRoomType(req: Request, res: Response) {
  try {
    const roomTypeId = req.params.roomTypesId

    const getRoomTypes = await db
      .getRepository(RoomsTypes)
      .createQueryBuilder('roomsTypes')
      .where('roomsTypes.id = :id', {
        id: roomTypeId,
      })
      .getOne()

    return res.json({
      status: 0,
      roomType: getRoomTypes,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
