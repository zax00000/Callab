import { Express } from 'express'
import RolesChecker from '../../../middleware/RolesChecker'
import { addNewRoomType } from './addNewRoomType'
import { deleteRoomType } from './deleteRoomType'
import { editRoomType } from './editRoomType'
import { getAllRoomType } from './getAllRoomType'
import { getAllRoomTypeSearchPagin } from './getAllRoomTypeSearchPagin'
import { getRoomType } from './getRoomType'

export default (app: Express) => {
  /**
   * @openapi
   * /private/room-type/{roomTypeId}:
   *  delete:
   *    tags:
   *      - roomTypes
   *    description: Delete Room Type.
   *    summary: Delete Room Type.
   *    parameters:
   *      - in: path
   *        name: roomTypeId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.delete(
    '/room-type/:roomTypeId',
    RolesChecker('DeleteRoomType'),
    deleteRoomType
  )

  /**
   * @openapi
   * /private/room-type/new:
   *  post:
   *    tags:
   *      - roomTypes
   *    description: Create Room Type
   *    summary: Create Room Type
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/NewRoomType'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  NewRoomType:           # <----------
   *    type: object
   *    required:
   *      - name
   *      - maxUsersLicensed
   *      - maxUsers
   *      - inviteOnly
   *      - hasManager
   *      - hasModerators
   *      - isConference
   *      - enumNumber
   *    properties:
   *      name:
   *        type: string
   *      maxUsersLicensed:
   *        type: boolean
   *      maxUsers:
   *        type: number
   *      inviteOnly:
   *        type: boolean
   *      hasManager:
   *        type: boolean
   *      hasModerators:
   *        type: boolean
   *      isConference:
   *        type: boolean
   *      enumNumber:
   *        type: number
   */
  app.post('/room-type/new', RolesChecker('AddNewRoomType'), addNewRoomType)

  /**
   * @openapi
   * /private/room-type/{roomTypeId}:
   *  post:
   *    tags:
   *      - roomTypes
   *    description: Edit Room
   *    summary: Edit Room
   *    parameters:
   *      - in: path
   *        name: roomTypeId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/EditRoomType'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  EditRoomType:           # <----------
   *    type: object
   *    required:
   *    properties:
   *      name:
   *        type: string
   *      maxUsersLicensed:
   *        type: boolean
   *      maxUsers:
   *        type: number
   *      inviteOnly:
   *        type: boolean
   *      hasManager:
   *        type: boolean
   *      hasModerators:
   *        type: boolean
   *      isConference:
   *        type: boolean
   */
  app.post('/room-type/:roomTypeId', RolesChecker('EditRoomType'), editRoomType)

  /**
   * @openapi
   * /private/room-type/{roomTypesId}:
   *  get:
   *    tags:
   *      - roomTypes
   *    description: Get Room.
   *    summary: Get Room.
   *    parameters:
   *      - in: path
   *        name: roomTypesId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/room-type/:roomTypesId', RolesChecker('GetRoomType'), getRoomType)

  /**
   * @openapi
   * /private/room-types:
   *  get:
   *    tags:
   *      - room
   *    description: Get all room type.
   *    summary: Get all room type.
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/room-types', RolesChecker('GetAllRoomType'), getAllRoomType)

  /**
   * @openapi
   * /private/room-types/pagin/{skip}/{take}:
   *  get:
   *    tags:
   *      - room
   *    description: Get all room type.
   *    summary: Get all room type.
   *    parameters:
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/room-types/pagin/:skip/:take',
    RolesChecker('GetAllRoomTypePagin'),
    getAllRoomType
  )

  /**
   * @openapi
   * /private/room-types/pagin/{skip}/{take}/search/{search}:
   *  get:
   *    tags:
   *      - room
   *    description: Get all room type.
   *    summary: Get all room type.
   *    parameters:
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *      - in: path
   *        name: search
   *        schema:
   *          type: number
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/room-types/pagin/:skip/:take/search/:search',
    RolesChecker('GetAllRoomTypeSearchPagin'),
    getAllRoomTypeSearchPagin
  )
}
