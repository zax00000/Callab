import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { User } from '../../../database/entity/user'

export async function getStatistics(req: Request, res: Response) {
  try {
    const allUsersCountPromise = db
      .getRepository(User)
      .createQueryBuilder('user')
      .getCount()

    const allUsersLoggedCountPromise = db
      .getRepository(User)
      .createQueryBuilder('user')
      .where('user.isLogged = :isLogged', {
        isLogged: true,
      })
      .getCount()

    const getBusinessPromise = db
      .getRepository(Business)
      .createQueryBuilder('business')
      .leftJoinAndSelect('business.users', 'user')
      .leftJoinAndSelect('business.floors', 'floors')
      .leftJoinAndSelect('floors.rooms', 'rooms')
      .leftJoinAndSelect('rooms.roomMembers', 'roomMembers')
      .select([
        'business.id',
        'user.id',
        'floors.id',
        'rooms.id',
        'roomMembers.id',
      ])
      .getMany()

    const [allUsersCount, allUsersLoggedCount, getBusiness] = await Promise.all(
      [allUsersCountPromise, allUsersLoggedCountPromise, getBusinessPromise]
    )

    const allBusinessCount = getBusiness.length

    const averageBusinessUsers =
      getBusiness
        .map((business) => business.users.length)
        .reduce((sum, usersCount) => sum + usersCount, 0) / getBusiness.length

    const averageBusinessFloors =
      getBusiness
        .map((business) => business.floors.length)
        .reduce((sum, floorsCount) => sum + floorsCount, 0) / getBusiness.length

    const averageBusinessRooms =
      getBusiness
        .map((business) =>
          business.floors
            .map((floor) => floor.rooms.length)
            .reduce((sum, roomsCount) => sum + roomsCount, 0)
        )
        .reduce((sum, roomsCount) => sum + roomsCount, 0) / getBusiness.length

    const averageBusinessUserInRooms =
      getBusiness
        .map(
          (business) =>
            (business.floors
              .map(
                (floor) =>
                  floor.rooms
                    .map((room) => room.roomMembers.length)
                    .reduce(
                      (sum, roomMembersCount) => sum + roomMembersCount,
                      0
                    ) || 0
              )
              .reduce((sum, roomMembersCount) => sum + roomMembersCount, 0) ||
              0) /
              business.floors
                .map((floor) => floor.rooms.length)
                .reduce((sum, roomsCount) => sum + roomsCount, 0) || 0
        )
        .reduce((sum, roomMembersCount) => sum + roomMembersCount, 0) /
        getBusiness.length || 0

    return res.json({
      status: 0,
      allUsersCount,
      allBusinessCount,
      allUsersLoggedCount,
      averageBusinessUsers,
      averageBusinessFloors,
      averageBusinessRooms,
      averageBusinessUserInRooms,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
