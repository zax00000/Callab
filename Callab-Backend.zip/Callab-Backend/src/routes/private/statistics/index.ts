import { Express } from 'express'
import RolesChecker from '../../../middleware/RolesChecker'
import { getStatistics } from './getStatistics'

export default (app: Express) => {
  /**
   * @openapi
   * /private/statistics:
   *  get:
   *    tags:
   *      - statistics
   *    description: Get statistics.
   *    summary: Get statistics.
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/statistics', RolesChecker('Statistics'), getStatistics)
}
