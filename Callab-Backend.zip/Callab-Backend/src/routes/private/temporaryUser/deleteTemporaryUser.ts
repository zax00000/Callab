import { Request, Response } from 'express'
import { TemporaryUser } from '../../../database/entity/temporaryUser'
import db from '../../../database'
import { RoomsMembers } from '../../../database/entity/roomsMembers'

export async function deleteTemporaryUser(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { usersId } = req.body

      if (!Array.isArray(usersId)) {
        return res.json({
          status: 4,
        })
      }
      await Promise.all(
        usersId.map(async (userId: string) => {
          const getRoomMembers = await transactionalEntityManager
            .getRepository(RoomsMembers)
            .createQueryBuilder('roomsMembers')
            .leftJoinAndSelect('roomsMembers.room', 'room')
            .leftJoinAndSelect('roomsMembers.temporaryUser', 'temporaryUser')
            .select([
              'roomsMembers.id',
              'roomsMembers.isGuest',
              'room.id',
              'temporaryUser.id',
            ])
            .where('temporaryUser.id = :userId', { userId: userId })
            .getOne()

          if (getRoomMembers != null) {
            if (getRoomMembers.isGuest) {
              await transactionalEntityManager
                .getRepository(RoomsMembers)
                .remove(getRoomMembers)
            }
            await transactionalEntityManager
              .getRepository(TemporaryUser)
              .remove(getRoomMembers.temporaryUser)
          }
        })
      )

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
