import { Request, Response } from 'express'
import jwt from 'jsonwebtoken'
import { Brackets } from 'typeorm'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Rooms } from '../../../database/entity/rooms'
import { RoomsMembers } from '../../../database/entity/roomsMembers'
import { TemporaryUser } from '../../../database/entity/temporaryUser'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'
import sendMail from '../../../sendMail'
import joinTheMeetingMail from '../../../sendMail/joinTheMeetingMail'
import emailValidator from '../../../utils/emailValidator'

export async function generateAndSendLink(req: Request, res: Response) {
  const { id: userId } = <UserFromToken>req.user

  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { email, businessId, roomId } = req.body

      const getUserPromise = transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.settings', 'userSettings')
        .where('user.id = :id', { id: userId })
        .getOne()

      const getRoomPromise = transactionalEntityManager
        .getRepository(Rooms)
        .createQueryBuilder('room')
        .leftJoinAndSelect('room.floor', 'floor')
        .leftJoinAndSelect('room.roomMembers', 'roomsMembers')
        .where('room.id = :id', { id: roomId })
        .getOne()

      const getBusinessPromise = transactionalEntityManager
        .getRepository(Business)
        .createQueryBuilder('business')
        .leftJoinAndSelect('business.license', 'license')
        .where('business.id = :id', { id: businessId })
        .getOne()

      const getRoomMembersPromise = transactionalEntityManager
        .getRepository(RoomsMembers)
        .createQueryBuilder('roomsMembers')
        .leftJoinAndSelect('roomsMembers.room', 'room')
        .leftJoinAndSelect('roomsMembers.user', 'user')
        .leftJoinAndSelect('roomsMembers.temporaryUser', 'temporaryUser')
        .where(
          new Brackets((qb) => {
            qb.where('room.id = :roomId', { roomId: roomId }).andWhere(
              'user.email = :userEmail',
              { userEmail: email }
            )
          })
        )
        .orWhere(
          new Brackets((qb) => {
            qb.where('room.id = :roomId', { roomId: roomId }).andWhere(
              'temporaryUser.email = :userEmail',
              { userEmail: email }
            )
          })
        )
        .getOne()

      const getTemporaryUserPromise = transactionalEntityManager
        .getRepository(TemporaryUser)
        .createQueryBuilder('temporaryUser')
        .leftJoinAndSelect('temporaryUser.roomMember', 'roomMember')
        .leftJoinAndSelect('roomMember.user', 'user')
        .leftJoinAndSelect('roomMember.room', 'room')
        .where('temporaryUser.email = :email', { email: email })
        .andWhere('room.id = :roomId', { roomId: roomId })
        .getOne()

      const [getUser, getBusiness, getRoom, getRoomMembers, getTemporaryUser] =
        await Promise.all([
          getUserPromise,
          getBusinessPromise,
          getRoomPromise,
          getRoomMembersPromise,
          getTemporaryUserPromise,
        ])

      if (
        getUser == null ||
        getBusiness == null ||
        getRoom == null ||
        !(await emailValidator(email))
      ) {
        return res.json({
          status: 4,
        })
      }

      // if (
      //   getBusiness.license == null ||
      //   new Date(getBusiness.license.endDate).getTime() < new Date().getTime()
      // ) {
      //   return res.json({
      //     status: 7,
      //   })
      // }

      // if (
      //   getBusiness.license.maxUsersRooms !== 0 &&
      //   getRoom.roomMembers.length >= getBusiness.license.maxUsersRooms
      // ) {
      //   return res.json({
      //     status: 7,
      //   })
      // }

      let newTemporaryUser = new TemporaryUser()
      if (getTemporaryUser != null) {
        newTemporaryUser = getTemporaryUser
      }
      const dateNow = new Date()

      newTemporaryUser.idUserCreated = getUser
      newTemporaryUser.idUserModified = getUser
      newTemporaryUser.dateCreated = dateNow
      newTemporaryUser.dateModified = dateNow
      newTemporaryUser.email = email

      const newTemporaryUserResponse = await transactionalEntityManager
        .getRepository(TemporaryUser)
        .save(newTemporaryUser)

      const tokenToMeeting = jwt.sign(
        { tempUser: newTemporaryUserResponse.id, businessId },
        process.env.MEETING_SECRET,
        {
          expiresIn: '24h',
        }
      )
      if (getRoomMembers != null) {
        newTemporaryUserResponse.roomMember = getRoomMembers
      }

      newTemporaryUserResponse.accessHash = tokenToMeeting
      const temporaryUserWithToken = await transactionalEntityManager
        .getRepository(TemporaryUser)
        .save(newTemporaryUserResponse)

      if (getRoomMembers == null) {
        const newRoomMembers = new RoomsMembers()

        newRoomMembers.dateCreated = dateNow
        newRoomMembers.dateModified = dateNow
        newRoomMembers.idUserCreated = getUser
        newRoomMembers.idUserModified = getUser
        newRoomMembers.isGuest = true
        newRoomMembers.temporaryUser = temporaryUserWithToken
        newRoomMembers.room = getRoom
        newRoomMembers.user = null

        await transactionalEntityManager
          .getRepository(RoomsMembers)
          .save(newRoomMembers)
      }

      sendMail.sendMail({
        to: email,
        subject: 'Join the meeting',
        text: 'Join the meeting',
        html: joinTheMeetingMail(email, tokenToMeeting),
      })

      await db.queryResultCache.remove([roomId])
      await db.queryResultCache.remove([getRoom.floor.id])

      return res.json({
        status: 0,
        temporaryUser: temporaryUserWithToken.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
