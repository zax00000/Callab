import { Express } from 'express'
import RolesChecker from '../../../middleware/RolesChecker'
import { deleteTemporaryUser } from './deleteTemporaryUser'
import { generateAndSendLink } from './generateAndSendLink'

export default (app: Express) => {
  /**
   * @openapi
   * /private/delete-temporary-user:
   *  post:
   *    tags:
   *      - meeting
   *    description: Delete temporary-users.
   *    summary: Delete temporary-users.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/deleteTemporaryUser'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  deleteTemporaryUser:           # <----------
   *    type: object
   *    properties:
   *      usersId:
   *        type: array
   *        items:
   *          type: string
   */
  app.post('/delete-temporary-user', deleteTemporaryUser)

  /**
   * @openapi
   * /private/generate-meeting-link:
   *  post:
   *    tags:
   *      - meeting
   *    description: generate and send meeting link
   *    summary: generate and send meeting link
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/generateMeetingLink'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  generateMeetingLink:           # <----------
   *    type: object
   *    properties:
   *      email:
   *        type: string
   *      businessId:
   *        type: string
   *      roomId:
   *        type: string
   */
  app.post(
    '/generate-meeting-link',
    RolesChecker('GenerateAndSendLink'),
    generateAndSendLink
  )
}
