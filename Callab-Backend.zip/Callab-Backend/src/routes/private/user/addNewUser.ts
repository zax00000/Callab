import crypto from 'crypto'
import { Request, Response } from 'express'
import jwt from 'jsonwebtoken'
import db from '../../../database'
import { Avatar } from '../../../database/entity/avatar'
import { Business } from '../../../database/entity/business'
import { Role } from '../../../database/entity/role'
import { User } from '../../../database/entity/user'
import { UserData } from '../../../database/entity/userData'
import { UserSettings } from '../../../database/entity/userSettings'
import { UserFromToken } from '../../../interfaces/user'
import sendMail from '../../../sendMail'
import newAccountMail from '../../../sendMail/newAccountMail'
import { checkLicenseTime } from '../../../utils/checkLicenseTime'
import emailValidator from '../../../utils/emailValidator'

export async function addNewUser(req: Request, res: Response) {
  try {
    const {
      business: UserBusinessId,
      superAdmin: idSuperAdmin,
      id: userId,
    } = <UserFromToken>req.user

    const { businessId, roleId, avatarImage } = req.body
    let { email } = req.body

    return await db.transaction(async (transactionalEntityManager) => {
      email = email?.toLowerCase()
      if (email != null) {
        if (!(await emailValidator(email))) {
          return res.json({
            status: 4,
          })
        }

        const userPromise = transactionalEntityManager
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.id = :id', { id: userId })
          .getOne()

        const getBusinessPromise = transactionalEntityManager
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.license', 'license')
          .leftJoinAndSelect('business.users', 'user')
          .where('business.id = :id', {
            id: idSuperAdmin ? businessId : UserBusinessId,
          })
          .getOne()

        const [user, getBusiness] = await Promise.all([
          userPromise,
          getBusinessPromise,
        ])
        if (checkLicenseTime(getBusiness.license)) {
          return res.json({
            status: 7,
          })
        }
        if (
          getBusiness.license.maxUsersInBusiness !== 0 &&
          getBusiness.users &&
          getBusiness.users.length >= getBusiness.license.maxUsersInBusiness
        ) {
          return res.json({
            status: 7,
          })
        }

        const getRolePromise = transactionalEntityManager
          .getRepository(Role)
          .createQueryBuilder('role')
          .where('role.id = :id', {
            id: roleId,
          })
          .getOne()

        const newUserPromise = transactionalEntityManager
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.business', 'business')
          .leftJoinAndSelect('user.businessRoles', 'businessRoles')
          .leftJoinAndSelect('user.userData', 'userData')
          .where('user.email = :email', { email: email })
          .getOne()

        const getRole = await getRolePromise
        let newUser = await newUserPromise

        const newDate = new Date()

        const userNotExists = newUser == null
        if (userNotExists) {
          newUser = new User()

          newUser.email = email as string
          newUser.isActivated = false
          newUser.activatingHash = jwt.sign(
            { businessId: getBusiness.id, rand: crypto.randomUUID() },
            process.env.ACTIVATE_SECRET,
            {
              expiresIn: '9999y',
            }
          )
          newUser.idUserCreated = user
          newUser.dateCreated = newDate

          newUser.settings = new UserSettings()
          newUser.settings.alternateEmail = ''
          newUser.settings.defaultBusiness = null
          newUser.settings.phoneNumber = ''
          await transactionalEntityManager
            .getRepository(UserSettings)
            .save(newUser.settings)
        }

        newUser.idUserModified = user
        newUser.dateModified = newDate
        newUser.business = [
          ...(newUser && newUser.business ? newUser.business : []),
          getBusiness,
        ]
        newUser.businessRoles = [
          ...(newUser && newUser.businessRoles ? newUser.businessRoles : []),
          getRole,
        ]

        if (avatarImage) {
          const newAvatar = new Avatar()
          newAvatar.avatar = avatarImage
          newAvatar.dateCreated = newDate
          newAvatar.dateModified = newDate
          newAvatar.idUserModified = user
          newAvatar.idUserCreated = user
          const newAvatarResponse = await transactionalEntityManager
            .getRepository(Avatar)
            .save(newAvatar)

          newUser.avatar = newAvatarResponse
        }

        const newUserData = new UserData()
        newUserData.business = getBusiness
        newUserData.user = newUser

        if (newUser?.userData != null && newUser.userData.length > 0) {
          newUser.userData = [...newUser.userData, newUserData]
        } else {
          newUser.userData = [newUserData]
        }
        const newUserResponse = await transactionalEntityManager
          .getRepository(User)
          .save(newUser)

        if (userNotExists) {
          sendMail.sendMail({
            to: newUserResponse.email,
            subject: 'Active Account',
            text: 'Active Account',
            html: newAccountMail(
              newUserResponse.email,
              newUserResponse.activatingHash
            ),
          })
        }
        return res.json({
          status: 0,
          userId: newUserResponse.id,
        })
      } else {
        return res.json({
          status: 4,
        })
      }
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
