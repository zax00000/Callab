import crypto from 'crypto'
import { Request, Response } from 'express'
import jwt from 'jsonwebtoken'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Role } from '../../../database/entity/role'
import { User } from '../../../database/entity/user'
import { UserData } from '../../../database/entity/userData'
import { UserSettings } from '../../../database/entity/userSettings'
import { UserFromToken } from '../../../interfaces/user'
import sendMail from '../../../sendMail'
import newAccountMail from '../../../sendMail/newAccountMail'
import { checkLicenseTime } from '../../../utils/checkLicenseTime'
import emailValidator from '../../../utils/emailValidator'

export async function addNewUsers(req: Request, res: Response) {
  try {
    const {
      business: UserBusinessId,
      superAdmin: idSuperAdmin,
      id: userId,
    } = <UserFromToken>req.user

    const { businessId, roleId, emails } = <
      {
        businessId: string
        roleId: string
        emails: string[]
      }
    >req.body

    return await db.transaction(async (transactionalEntityManager) => {
      if (emails == null || emails.length == 0) {
        return res.json({
          status: 4,
        })
      }

      const getBusiness = await transactionalEntityManager
        .getRepository(Business)
        .createQueryBuilder('business')
        .leftJoinAndSelect('business.license', 'license')
        .leftJoinAndSelect('business.users', 'user')
        .where('business.id = :id', {
          id: idSuperAdmin ? businessId : UserBusinessId,
        })
        .getOne()

      if (checkLicenseTime(getBusiness.license)) {
        return res.json({
          status: 7,
        })
      }
      if (
        getBusiness.license.maxUsersInBusiness !== 0 &&
        getBusiness.users &&
        getBusiness.users.length >= getBusiness.license.maxUsersInBusiness
      ) {
        return res.json({
          status: 7,
        })
      }

      const emailsIsInvalid = (
        await Promise.all(emails.map(async (email) => emailValidator(email)))
      ).some((isValid) => !isValid)

      if (emailsIsInvalid) {
        return res.json({
          status: 4,
        })
      }

      await Promise.all(
        emails.map(async (email: string) => {
          const getUserPromise = transactionalEntityManager
            .getRepository(User)
            .createQueryBuilder('user')
            .where('user.id = :id', { id: userId })
            .getOne()

          const getRolePromise = transactionalEntityManager
            .getRepository(Role)
            .createQueryBuilder('role')
            .where('role.id = :id', {
              id: roleId,
            })
            .getOne()

          const newUserPromise = transactionalEntityManager
            .getRepository(User)
            .createQueryBuilder('user')
            .leftJoinAndSelect('user.business', 'business')
            .leftJoinAndSelect('user.businessRoles', 'businessRoles')
            .leftJoinAndSelect('user.userData', 'userData')
            .where('user.email = :email', { email: email })
            .getOne()

          const [getRole, getNewUser, getUser] = await Promise.all([
            getRolePromise,
            newUserPromise,
            getUserPromise,
          ])

          let newUser = getNewUser
          const newDate = new Date()

          const userNotExists = newUser == null

          if (userNotExists) {
            newUser = new User()

            newUser.email = email as string
            newUser.isActivated = false
            newUser.activatingHash = jwt.sign(
              { businessId: getBusiness.id, rand: crypto.randomUUID() },
              process.env.ACTIVATE_SECRET,
              {
                expiresIn: '9999y',
              }
            )
            newUser.idUserCreated = getUser
            newUser.dateCreated = newDate

            newUser.settings = new UserSettings()
            newUser.settings.alternateEmail = ''
            newUser.settings.defaultBusiness = null
            newUser.settings.phoneNumber = ''
            await transactionalEntityManager
              .getRepository(UserSettings)
              .save(newUser.settings)
          }

          newUser.idUserModified = getUser
          newUser.dateModified = newDate
          newUser.business = [
            ...(newUser && newUser.business ? newUser.business : []),
            getBusiness,
          ]
          newUser.businessRoles = [
            ...(newUser && newUser.businessRoles ? newUser.businessRoles : []),
            getRole,
          ]

          const newUserData = new UserData()
          newUserData.business = getBusiness
          newUserData.user = newUser

          if (newUser?.userData != null && newUser.userData.length > 0) {
            newUser.userData = [...newUser.userData, newUserData]
          } else {
            newUser.userData = [newUserData]
          }
          const newUserResponse = await transactionalEntityManager
            .getRepository(User)
            .save(newUser)

          if (userNotExists) {
            sendMail.sendMail({
              to: newUserResponse.email,
              subject: 'Active Account',
              text: 'Active Account',
              html: newAccountMail(
                newUserResponse.email,
                newUserResponse.activatingHash
              ),
            })
          }
        })
      )
      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
