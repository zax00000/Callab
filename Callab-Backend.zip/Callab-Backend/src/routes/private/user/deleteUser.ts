import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Floors } from '../../../database/entity/floors'
import { User } from '../../../database/entity/user'

export async function deleteUser(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { id: userId } = <UserFromToken>req.user
      const { id } = req.params

      const userPromise = transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: userId })
        .getOne()

      const userFloorPromise = transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.roomsMembers', 'roomsMembers')
        .leftJoinAndSelect('roomsMembers.room', 'room')
        .leftJoinAndSelect('room.floor', 'floor')
        .where('user.id = :id', {
          id: id,
        })
        .getOne()

      const [userEditor, userFloor] = await Promise.all([
        userPromise,
        userFloorPromise,
      ])

      const dateNow = new Date()
      await Promise.all(
        userFloor.roomsMembers.map((roomMembers) => {
          const floor = roomMembers.room.floor
          floor.dateModified = dateNow
          floor.idUserModified = userEditor
          return Promise.all([
            transactionalEntityManager.getRepository(Floors).save(floor),
            db.queryResultCache.remove([floor.id]),
          ])
        })
      )

      await transactionalEntityManager
        .createQueryBuilder()
        .delete()
        .from(User)
        .where('id = :id', { id: id })
        .execute()

      return res.json({ status: 0 })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
