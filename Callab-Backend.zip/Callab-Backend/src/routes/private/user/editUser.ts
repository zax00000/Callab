import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Role } from '../../../database/entity/role'
import { User } from '../../../database/entity/user'
import { UserData } from '../../../database/entity/userData'
import emailValidator from '../../../utils/emailValidator'
import powersRoles from '../../../utils/powersRoles'

export async function editUser(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { userId: editedUserId } = req.params

      const {
        superAdmin: idSuperAdmin,
        id: userId,
        role: userRole,
      } = <UserFromToken>req.user

      const isAdmin =
        !!idSuperAdmin ||
        (await powersRoles.checkRolesApi('EditUser', userRole))

      const { roleId, businessId } = req.body as {
        roleId: string
        businessId: string
      }
      if (!isAdmin && userId != editedUserId) {
        return res.json({
          status: 2,
        })
      }

      const userPromise = transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.avatar', 'avatar')
        .leftJoinAndSelect('user.business', 'businessCheck')
        .leftJoinAndSelect('user.businessRoles', 'businessRoles')
        .leftJoinAndSelect('user.userData', 'userData')
        .leftJoinAndSelect('userData.business', 'businessForUserData')
        .leftJoinAndSelect('businessRoles.business', 'business')
        .where('user.id = :id', {
          id: editedUserId,
        })
        .getOne()

      const userModifiedPromise = transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      const [user, userModified] = await Promise.all([
        userPromise,
        userModifiedPromise,
      ])

      if (
        !idSuperAdmin &&
        !user.business.some((oneBusiness) => oneBusiness.id === businessId)
      ) {
        return res.json({
          status: 2,
        })
      }
      let { email } = req.body

      email = email?.toLowerCase()

      if (email != null && email.length > 0) {
        const userWithEmail = await transactionalEntityManager
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.email = :email', { email: req.body.email })
          .getOne()

        if (
          (userWithEmail != null &&
            !(
              userWithEmail.id === userId || userWithEmail.id === editedUserId
            )) ||
          !(await emailValidator(email))
        ) {
          return res.json({
            status: 4,
          })
        }

        user.email = email
      }
      // const userData = user.userData.find(
      //   (userData) => userData.business.id === businessId
      // )
      // let userDataFlag = false

      // ;['firstName', 'surName'].forEach((field) => {
      //   if (req.body[field] != null) {
      //     if (req.body[field].trim().length === 0) {
      //       return res.json({
      //         status: 4,
      //       })
      //     }
      //     userData[field as 'firstName'] = req.body[field]
      //     userDataFlag = true
      //   }
      // })
      let userDataFlag = false

      if (req.body.surName != null || req.body.firstName != null) {
        let userData = user.userData.find(
          (userData) => userData.business.id === businessId
        )

        if (userData == null) {
          const newUserData = new UserData()
          const getBusiness = await transactionalEntityManager
            .getRepository(Business)
            .createQueryBuilder('business')
            .leftJoinAndSelect('business.userData', 'userData')
            .leftJoinAndSelect('userData.business', 'businessForUserData')
            .where('business.id = :id', {
              id: businessId,
            })
            .getOne()
          if (getBusiness == null) {
            return res.json({
              status: 5,
            })
          }
          newUserData.business = getBusiness
          newUserData.user = user
          ;['firstName', 'surName'].forEach((field) => {
            if (req.body[field] != null && req.body[field]) {
              newUserData[field as 'firstName'] = req.body[field]
              userDataFlag = true
            }
          })
          const savedUserData = await transactionalEntityManager
            .getRepository(UserData)
            .save(newUserData)

          if (user.userData != null && user.userData.length > 0) {
            user.userData = [...user.userData, savedUserData]
          } else {
            user.userData = [savedUserData]
          }

          if (getBusiness.userData != null && getBusiness.userData.length > 0) {
            getBusiness.userData = [...getBusiness.userData, savedUserData]
          } else {
            getBusiness.userData = [savedUserData]
          }
          await transactionalEntityManager
            .getRepository(Business)
            .save(getBusiness)
        } else {
          ;['firstName', 'surName'].forEach((field) => {
            if (req.body[field] != null && req.body[field]) {
              userData[field as 'firstName'] = req.body[field]
              userDataFlag = true
            }
          })
          if (userDataFlag) {
            await transactionalEntityManager
              .getRepository(UserData)
              .save(userData)
          }
        }
      }

      // if (avatarImage != null && avatarImage.trim().length > 0) {
      //   if (user.avatar == null) {
      //     const userAvatar = new Avatar()
      //     user.avatar = userAvatar
      //     user.avatar.dateCreated = new Date()
      //     user.avatar.dateModified = new Date()
      //     user.avatar.idUserCreated = userModified
      //     user.avatar.idUserModified = userModified
      //     await transactionalEntityManager.getRepository(Avatar).save(user.avatar)
      //   }
      //   user.avatar.avatar = avatarImage
      // }

      if (roleId && businessId) {
        const promiseBusinessRole = await Promise.all(
          user.businessRoles.map(async (role) => {
            if (role.business.id === businessId) {
              const getRole = await transactionalEntityManager
                .getRepository(Role)
                .createQueryBuilder('role')
                .leftJoinAndSelect('role.business', 'business')
                .where('role.id = :id', {
                  id: roleId,
                })
                .getOne()
              if (getRole.business.id === businessId) {
                return getRole
              }
            }
            return role
          })
        )

        user.businessRoles = promiseBusinessRole
      }

      user.idUserModified = userModified
      user.dateModified = new Date()

      const newUserResponse = await transactionalEntityManager
        .getRepository(User)
        .save(user)
      return res.json({
        status: 0,
        userId: newUserResponse.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
