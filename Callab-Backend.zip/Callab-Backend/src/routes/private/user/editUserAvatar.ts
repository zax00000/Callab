import { Request, Response } from 'express'
import db from '../../../database'
import { Avatar } from '../../../database/entity/avatar'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'
import powersRoles from '../../../utils/powersRoles'

export async function editUserAvatar(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { userId: editedUserId } = req.params
      const { avatar: avatarToSave } = req.body

      const {
        superAdmin: idSuperAdmin,
        id: userId,
        business: businessId,
        role: userRole,
      } = <UserFromToken>req.user
      let userIdToEdit = ''

      if (idSuperAdmin != null || editedUserId === userId) {
        userIdToEdit = editedUserId
      } else {
        if (
          await powersRoles.checkRolesApi('EditUserAvatarInBusiness', userRole)
        ) {
          const UserBusiness = await transactionalEntityManager
            .getRepository(User)
            .createQueryBuilder('user')
            .leftJoinAndSelect('user.business', 'business')
            .where('user.id = :id', {
              id: editedUserId,
            })
            .getOne()

          if (UserBusiness.business.some(({ id }) => id === businessId)) {
            userIdToEdit = editedUserId
          }
        }
      }

      if (userIdToEdit.length === 0) {
        return res.json({
          status: 4,
        })
      }

      const editedUserAvatarPromise = transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.avatar', 'avatar')
        .where('user.id = :id', {
          id: userIdToEdit,
        })
        .getOne()

      const userModifiedPromise = transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      const [editedUserAvatar, userModified] = await Promise.all([
        editedUserAvatarPromise,
        userModifiedPromise,
      ])

      if (editedUserAvatar == null) {
        return res.json({
          status: 3,
        })
      }
      let avatar = editedUserAvatar.avatar
      const nowDate = new Date()

      if (avatar == null) {
        avatar = new Avatar()
        avatar.dateCreated = nowDate
        avatar.idUserCreated = userModified
      }

      if (avatarToSave != null) {
        avatar.avatar = avatarToSave
        avatar.dateModified = nowDate
        avatar.idUserModified = userModified
      }
      const editedUserAvatarResponse = await transactionalEntityManager
        .getRepository(Avatar)
        .save(avatar)

      editedUserAvatar.avatar = editedUserAvatarResponse
      await transactionalEntityManager
        .getRepository(User)
        .save(editedUserAvatar)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
