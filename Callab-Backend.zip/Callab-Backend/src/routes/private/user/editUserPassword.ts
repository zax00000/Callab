import bcrypt from 'bcryptjs'
import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { User } from '../../../database/entity/user'

export async function editUserPassword(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { id: userId } = <UserFromToken>req.user

      const { oldPassword, newPassword } = req.body as {
        oldPassword: string
        newPassword: string
      }

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      const validPassword = await bcrypt.compare(oldPassword, getUser.pass)

      if (validPassword) {
        const hash = await bcrypt.hash(newPassword, 10)

        getUser.pass = hash
        await transactionalEntityManager.getRepository(User).save(getUser)

        return res.json({
          status: 0,
        })
      } else {
        return res.json({
          status: 4,
        })
      }
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
