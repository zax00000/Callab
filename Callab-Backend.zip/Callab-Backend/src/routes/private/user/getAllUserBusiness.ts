import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { User } from '../../../database/entity/user'

export async function getAllUserBusiness(req: Request, res: Response) {
  try {
    const { superAdmin: idSuperAdmin, id: userId } = <UserFromToken>req.user

    if (idSuperAdmin) {
      const getAllBusiness = await db
        .getRepository(Business)
        .createQueryBuilder('Business')
        .getMany()
      return res.json({
        status: 0,
        userBusiness: { id: userId, userBusiness: getAllBusiness },
      })
    }

    const getUserBusiness = await db
      .getRepository(User)
      .createQueryBuilder('user')
      .leftJoinAndSelect('user.business', 'business')
      .select(['user.id', 'business'])
      .where('user.id = :id', { id: userId })
      .getOne()

    return res.json({
      status: 0,
      userBusiness: getUserBusiness,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
