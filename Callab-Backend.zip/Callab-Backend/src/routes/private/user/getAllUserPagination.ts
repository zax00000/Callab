import { Request, Response } from 'express'
import db from '../../../database'
import { User } from '../../../database/entity/user'

export async function getAllUserPagination(req: Request, res: Response) {
  try {
    const { skip, take, search } = req.params

    let getUsers
    let getUsersCount = 0

    if (search == null || search.length === 0) {
      getUsers = await db
        .getRepository(User)
        .createQueryBuilder('user')
        .skip(Number(skip))
        .take(Number(take))
        .getMany()
      getUsersCount = await db
        .getRepository(User)
        .createQueryBuilder('user')
        .getCount()
    } else {
      getUsers = await db
        .getRepository(User)
        .createQueryBuilder('user')
        .skip(Number(skip))
        .take(Number(take))
        .where('user.email ILIKE :searchQuery', {
          searchQuery: `%${search}%`,
        })
        .getMany()
      getUsersCount = await db
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.email ILIKE :searchQuery', {
          searchQuery: `%${search}%`,
        })
        .getCount()
    }
    return res.json({
      status: 0,
      users: getUsers.map((user) => ({
        ...user,
        pass: undefined,
        passHash: undefined,
        activatingHash: undefined,
      })),
      count: getUsersCount,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
