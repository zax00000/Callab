import { Request, Response } from 'express'
import db from '../../../database'
import { User } from '../../../database/entity/user'

export async function getAllUsers(req: Request, res: Response) {
  try {
    const getUsers = await db
      .getRepository(User)
      .createQueryBuilder('user')
      .getMany()

    return res.json({
      status: 0,
      users: getUsers.map((user) => ({
        ...user,
        pass: undefined,
        passHash: undefined,
        activatingHash: undefined,
      })),
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
