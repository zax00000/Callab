import { Request, Response } from 'express'
import db from '../../../database'
import { User } from '../../../database/entity/user'
import { UserFromToken } from '../../../interfaces/user'

export async function getUser(req: Request, res: Response) {
  try {
    const { role, business, id: userId } = <UserFromToken>req.user

    const getUser = await db
      .getRepository(User)
      .createQueryBuilder('user')
      .leftJoinAndSelect('user.avatar', 'avatar')
      .leftJoinAndSelect('user.settings', 'userSettings')
      .leftJoinAndSelect('user.userData', 'userData')
      .leftJoinAndSelect('userData.items', 'items')
      .leftJoinAndSelect('items.businessItem', 'businessItem')
      .leftJoinAndSelect('businessItem.item', 'item')
      .leftJoinAndSelect('userData.business', 'businessForUserData')
      .leftJoinAndSelect('userSettings.defaultBusiness', 'defaultBusiness')
      .leftJoinAndSelect('userSettings.defaultLanguage', 'defaultLanguage')
      .where('user.id = :id', { id: userId })
      .getOne()

    const { id, email, avatar, settings, dateCreated, dateLogIn, isLogged } =
      getUser

    const userData = getUser.userData.find(
      (userData) => userData.business.id === business
    )

    return res.json({
      status: 0,
      user: {
        id,
        email,
        firstName: userData?.firstName,
        surName: userData?.surName,
        isLogged,
        avatarImage: avatar?.avatar || '',
        roleId: role,
        businessId: business,
        phoneNumber: settings?.phoneNumber || '',
        alternateEmail: settings?.alternateEmail || '',
        defaultBusinessId: settings?.defaultBusiness?.id || '',
        afterLoginEnum: settings?.afterLoginEnum || 0,
        defaultLanguageId: settings?.defaultLanguage?.id || '',
        hrPoints: userData?.hrPoints || 0,
        items: userData?.items.map((item) => ({
          id: item?.id,
          itemName: item?.businessItem?.item.name,
          itemPictureUrl: item?.businessItem?.item.pictureUrl,
          itemType: item?.businessItem?.item.type,
          itemPosX: item.posX,
          itemPosY: item.posY,
          itemScale: item.scale,
          selected: item.selected,
          businessItemId: item.businessItem.id,
          description: item?.businessItem?.item.description,
        })),
      },
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
