import { Express } from 'express'
import RolesChecker from '../../../middleware/RolesChecker'
import { addNewUser } from './addNewUser'
import { addNewUsers } from './addNewUsers'
import { deleteUser } from './deleteUser'
import { editUser } from './editUser'
import { editUserAvatar } from './editUserAvatar'
import { editUserPassword } from './editUserPassword'
import { getAllUserBusiness } from './getAllUserBusiness'
import { getAllUserPagination } from './getAllUserPagination'
import { getAllUsers } from './getAllUsers'
import { getAllUsersSearch } from './getAllUsersSearch'
import { getUser } from './getUser'
import { logout } from './logout'
import { resetUserPassword } from './resetUserPassword'

export default (app: Express) => {
  /**
   * @openapi
   * /private/user/{id}:
   *  delete:
   *    tags:
   *      - user
   *    description: Delete user
   *    summary: Delete user.
   *    parameters:
   *      - in: path
   *        name: id
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.delete('/user/:id', RolesChecker('DeleteUser'), deleteUser)

  /**
   * @openapi
   * /private/user/new:
   *  post:
   *    tags:
   *      - user
   *    description: Create User
   *    summary: Create User
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/NewUser'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  NewUser:           # <----------
   *    type: object
   *    required:
   *      - email
   *      - roleId
   *      - businessId
   *    properties:
   *      email:
   *        type: string
   *      roleId:
   *        type: string
   *      businessId:
   *        type: string
   */
  app.post('/user/new', RolesChecker('AddNewUser'), addNewUser)

  /**
   * @openapi
   * /private/users/new:
   *  post:
   *    tags:
   *      - user
   *    description: Create Users
   *    summary: Create Users
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/NewUsers'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  NewUsers:           # <----------
   *    type: object
   *    required:
   *      - emails
   *      - roleId
   *      - businessId
   *    properties:
   *      emails:
   *        type: array
   *        items:
   *          type: string
   *      roleId:
   *        type: string
   *      businessId:
   *        type: string
   */
  app.post('/users/new', RolesChecker('AddNewUsers'), addNewUsers)

  /**
   * @openapi
   * /private/user/password:
   *  post:
   *    tags:
   *      - user
   *    description: Change User Password
   *    summary: Change User Password
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/editUserPassword'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  editUserPassword:           # <----------
   *    type: object
   *    required:
   *      - oldPassword
   *      - newPassword
   *    properties:
   *      oldPassword:
   *        type: string
   *      newPassword:
   *        type: string
   */
  app.post('/user/password', RolesChecker('EditUserPassword'), editUserPassword)

  /**
   * @openapi
   * /private/user/{userId}:
   *  post:
   *    tags:
   *      - user
   *    description: Edit User
   *    summary: Edit User
   *    parameters:
   *      - in: path
   *        name: userId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/EditUser'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  EditUser:           # <----------
   *    type: object
   *    required:
   *      - email
   *      - firstName
   *      - surName
   *      - roleId
   *      - businessId
   *    properties:
   *      email:
   *        type: string
   *      firstName:
   *        type: string
   *      surName:
   *        type: string
   *      roleId:
   *        type: string
   *      businessId:
   *        type: string
   */
  app.post('/user/:userId', editUser)

  /**
   * @openapi
   * /private/user:
   *  get:
   *    tags:
   *      - user
   *    description: Get user.
   *    summary: Get user.
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/user', RolesChecker('GetUser'), getUser)

  /**
   * @openapi
   * /private/users:
   *  get:
   *    tags:
   *      - user
   *    description: Get users.
   *    summary: Get users.
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/users', RolesChecker('getAllUsers'), getAllUsers)

  /**
   * @openapi
   * /private/user/business:
   *  get:
   *    tags:
   *      - user
   *    description: Get all user business.
   *    summary: Get all user business.
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/user/business', getAllUserBusiness)

  /**
   * @openapi
   * /private/pagin/users/{skip}/{take}:
   *  get:
   *    tags:
   *      - user
   *    description: Get all users with pagination.
   *    summary: Get all users with pagination.
   *    parameters:
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/pagin/users/:skip/:take',
    RolesChecker('GetAllUserPagination'),
    getAllUserPagination
  )

  /**
   * @openapi
   * /private/pagin/users/{skip}/{take}/search/{search}:
   *  get:
   *    tags:
   *      - user
   *    description: Get all users with pagination and search.
   *    summary: Get all users with pagination and search.
   *    parameters:
   *      - in: path
   *        name: search
   *        schema:
   *          type: string
   *      - in: path
   *        name: skip
   *        schema:
   *          type: number
   *      - in: path
   *        name: take
   *        schema:
   *          type: number
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/pagin/users/:skip/:take/search/:search',
    RolesChecker('GetAllUserPagination'),
    getAllUserPagination
  )
  /**
   * @openapi
   * /private/search/users/{search}:
   *  get:
   *    tags:
   *      - user
   *    description: Get all users with search.
   *    summary: Get all users with search.
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/search/users/:search',
    RolesChecker('GetAllUserSearch'),
    getAllUsersSearch
  )

  /**
   * @openapi
   * /private/logout:
   *  post:
   *    tags:
   *      - authorization
   *    description: Logout user.
   *    summary: Logout user.
   *    responses:
   *      200:
   *        description: Ok
   */
  app.post('/logout', logout)

  /**
   * @openapi
   * /private/reset-user-password/{userId}:
   *  post:
   *    tags:
   *      - authorization
   *    description: Reset User Password.
   *    summary: Reset User Password.
   *    parameters:
   *      - in: path
   *        name: userId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.post('/reset-user-password/:userId', resetUserPassword)

  /**
   * @openapi
   * /private/avatar/user/{userId}:
   *  post:
   *    tags:
   *      - user
   *    description: Edit User avatar
   *    summary: Edit User avatar
   *    parameters:
   *      - in: path
   *        name: userId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/EditUserAvatar'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  EditUserAvatar:           # <----------
   *    type: object
   *    required:
   *      - avatar
   *    properties:
   *      avatar:
   *        type: string
   */
  app.post(
    '/avatar/user/:userId',
    RolesChecker('EditUserAvatar'),
    editUserAvatar
  )
}
