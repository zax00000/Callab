import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Authentication } from '../../../database/entity/authentication'
import { User } from '../../../database/entity/user'

export async function logout(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { authId } = <UserFromToken>req.user

      const removedAuth = await transactionalEntityManager
        .getRepository(Authentication)
        .createQueryBuilder('authentication')
        .leftJoinAndSelect('authentication.user', 'user')
        .where('authentication.id = :id', {
          id: authId,
        })
        .getOne()

      const userLogout = removedAuth.user
      userLogout.isLogged = false
      userLogout.dateLogOut = new Date()

      await transactionalEntityManager.getRepository(User).save(userLogout)

      await transactionalEntityManager
        .getRepository(Authentication)
        .remove(removedAuth)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
