import crypto from 'crypto'
import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { User } from '../../../database/entity/user'
import sendMail from '../../../sendMail'
import resetUserPasswordMail from '../../../sendMail/resetUserPasswordMail'
import powersRoles from '../../../utils/powersRoles'

export async function resetUserPassword(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { userId: editedUserId } = req.params

      const {
        business: adminBusinessId,
        superAdmin: idSuperAdmin,
        id: userId,
        role: userRole,
      } = <UserFromToken>req.user

      const isAdmin =
        !!idSuperAdmin ||
        (await powersRoles.checkRolesApi('EditUser', userRole))

      if (!isAdmin && userId != editedUserId) {
        return res.json({
          status: 2,
        })
      }

      const userPromise = transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.avatar', 'avatar')
        .leftJoinAndSelect('user.business', 'businessCheck')
        .leftJoinAndSelect('user.businessRoles', 'businessRoles')
        .leftJoinAndSelect('businessRoles.business', 'business')
        .where('user.id = :id', {
          id: editedUserId,
        })
        .getOne()

      adminBusinessId

      const userModifiedPromise = transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', {
          id: userId,
        })
        .getOne()

      const [user, userModified] = await Promise.all([
        userPromise,
        userModifiedPromise,
      ])

      if (
        !idSuperAdmin &&
        !user.business.some((oenBusiness) => oenBusiness.id === adminBusinessId)
      ) {
        return res.json({
          status: 2,
        })
      }

      user.passHash = crypto.randomUUID()
      user.passChange = true
      user.idUserModified = userModified
      user.dateModified = new Date()

      sendMail.sendMail({
        to: user.email,
        subject: 'ResetPassword Account',
        text: 'Active Account',
        html: resetUserPasswordMail(user.email, user.passHash),
      })

      const newUserResponse = await transactionalEntityManager
        .getRepository(User)
        .save(user)
      return res.json({
        status: 0,
        userId: newUserResponse.id,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
