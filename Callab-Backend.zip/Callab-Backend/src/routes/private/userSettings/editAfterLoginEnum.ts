import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { User } from '../../../database/entity/user'
import { UserSettings } from '../../../database/entity/userSettings'

export async function editAfterLoginEnum(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { userId: editedUserId } = req.params

      const { superAdmin: idSuperAdmin, id: userId } = <UserFromToken>req.user

      const { afterLoginEnum } = req.body

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.settings', 'userSettings')
        .leftJoinAndSelect('user.userData', 'userData')
        .leftJoinAndSelect('userData.business', 'businessForUserData')
        .where('user.id = :id', { id: idSuperAdmin ? editedUserId : userId })
        .getOne()

      if (getUser.settings == null) {
        getUser.settings = new UserSettings()
      }

      if (afterLoginEnum != null && Number.isInteger(Number(afterLoginEnum))) {
        getUser.settings.afterLoginEnum = afterLoginEnum
      }

      await transactionalEntityManager
        .getRepository(UserSettings)
        .save(getUser.settings)

      await transactionalEntityManager.getRepository(User).save(getUser)
      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
