import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Languages } from '../../../database/entity/languages'
import { User } from '../../../database/entity/user'
import { UserData } from '../../../database/entity/userData'
import { UserSettings } from '../../../database/entity/userSettings'
import emailValidator from '../../../utils/emailValidator'

export async function editUserSettings(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { userId: editedUserId } = req.params

      const { superAdmin: idSuperAdmin, id: userId } = <UserFromToken>req.user

      const { defaultBusinessId, defaultLanguageId, businessId } = req.body

      const getUser = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .leftJoinAndSelect('user.settings', 'userSettings')
        .leftJoinAndSelect('user.userData', 'userData')
        .leftJoinAndSelect('userData.business', 'businessForUserData')
        .where('user.id = :id', { id: idSuperAdmin ? editedUserId : userId })
        .getOne()

      if (getUser.settings == null) {
        getUser.settings = new UserSettings()
      }
      let { alternateEmail } = req.body
      if (alternateEmail != null) {
        alternateEmail = alternateEmail.toLowerCase()
        if (alternateEmail != null && alternateEmail) {
          if (!(await emailValidator(alternateEmail))) {
            return res.json({
              status: 4,
            })
          }
          getUser.settings.alternateEmail = alternateEmail
        }
      }

      ;['phoneNumber'].forEach((field) => {
        if (req.body[field] != null && req.body[field]) {
          getUser.settings[field as 'phoneNumber'] = req.body[field]
        }
      })

      let { email } = req.body

      email = email?.toLowerCase()

      if (email != null && email.length > 0) {
        const userWithEmail = await transactionalEntityManager
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.email = :email', { email: req.body.email })
          .getOne()

        if (
          (userWithEmail != null &&
            !(
              userWithEmail.id === userId || userWithEmail.id === editedUserId
            )) ||
          !(await emailValidator(email))
        ) {
          return res.json({
            status: 4,
          })
        }

        getUser.email = email
      }

      if (defaultBusinessId != null) {
        if (defaultBusinessId.length === 0) {
          getUser.settings.defaultBusiness = null
        } else {
          const getBusiness = await transactionalEntityManager
            .getRepository(Business)
            .createQueryBuilder('business')
            .where('business.id = :id', { id: defaultBusinessId })
            .getOne()

          if (getBusiness != null) {
            getUser.settings.defaultBusiness = getBusiness
          }
        }
      }

      if (defaultLanguageId != null) {
        if (defaultLanguageId.length === 0) {
          getUser.settings.defaultLanguage = null
        } else {
          const getLanguage = await transactionalEntityManager
            .getRepository(Languages)
            .createQueryBuilder('languages')
            .where('languages.id = :id', { id: defaultLanguageId })
            .getOne()

          if (getLanguage != null) {
            getUser.settings.defaultLanguage = getLanguage
          }
        }
      }

      let userDataFlag = false

      if (req.body.surName != null || req.body.firstName != null) {
        let userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )

        if (userData == null) {
          const newUserData = new UserData()
          const getBusiness = await transactionalEntityManager
            .getRepository(Business)
            .createQueryBuilder('business')
            .leftJoinAndSelect('business.userData', 'userData')
            .leftJoinAndSelect('userData.business', 'businessForUserData')
            .where('business.id = :id', {
              id: businessId,
            })
            .getOne()
          if (getBusiness == null) {
            return res.json({
              status: 5,
            })
          }
          newUserData.business = getBusiness
          newUserData.user = getUser
          ;['firstName', 'surName'].forEach((field) => {
            if (req.body[field] != null && req.body[field]) {
              newUserData[field as 'firstName'] = req.body[field]
              userDataFlag = true
            }
          })
          const savedUserData = await transactionalEntityManager
            .getRepository(UserData)
            .save(newUserData)

          if (getUser.userData != null && getUser.userData.length > 0) {
            getUser.userData = [...getUser.userData, savedUserData]
          } else {
            getUser.userData = [savedUserData]
          }

          if (getBusiness.userData != null && getBusiness.userData.length > 0) {
            getBusiness.userData = [...getBusiness.userData, savedUserData]
          } else {
            getBusiness.userData = [savedUserData]
          }
          await transactionalEntityManager
            .getRepository(Business)
            .save(getBusiness)
        } else {
          ;['firstName', 'surName'].forEach((field) => {
            if (req.body[field] != null && req.body[field]) {
              userData[field as 'firstName'] = req.body[field]
              userDataFlag = true
            }
          })
          if (userDataFlag) {
            await transactionalEntityManager
              .getRepository(UserData)
              .save(userData)
          }
        }
      }

      await transactionalEntityManager
        .getRepository(UserSettings)
        .save(getUser.settings)
      await transactionalEntityManager.getRepository(User).save(getUser)
      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
