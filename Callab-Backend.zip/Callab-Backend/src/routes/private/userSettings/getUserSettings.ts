import { Request, Response } from 'express'
import { UserFromToken } from '../../../interfaces/user'
import db from '../../../database'
import { User } from '../../../database/entity/user'

export async function getUserSettings(req: Request, res: Response) {
  try {
    const { userId: editedUserId } = req.params

    const {
      business: businessId,
      superAdmin: idSuperAdmin,
      id: userId,
    } = <UserFromToken>req.user

    const getUserSettings = await db
      .getRepository(User)
      .createQueryBuilder('user')
      .leftJoinAndSelect('user.settings', 'userSettings')
      .leftJoinAndSelect('user.avatar', 'avatar')
      .leftJoinAndSelect('user.userData', 'userData')
      .leftJoinAndSelect('userData.business', 'businessForUserData')
      .leftJoinAndSelect('userSettings.defaultBusiness', 'defaultBusiness')
      .leftJoinAndSelect('userSettings.defaultLanguage', 'defaultLanguage')
      .where('user.id = :id', { id: idSuperAdmin ? editedUserId : userId })
      .getOne()

    const { email, avatar, settings } = getUserSettings
    const userData = getUserSettings.userData.find(
      (userData) => userData.business.id === businessId
    )
    return res.json({
      status: 0,
      user: {
        email,
        firstName: userData?.firstName || '',
        surName: userData?.surName || '',
        avatarImage: avatar?.avatar || '',
        phoneNumber: settings?.phoneNumber || '',
        alternateEmail: settings?.alternateEmail || '',
        defaultBusinessId: settings?.defaultBusiness?.id || '',
        afterLoginEnum: settings?.afterLoginEnum || 0,
        defaultLanguageId: settings?.defaultLanguage?.id || '',
      },
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
