import { Express } from 'express'
import RolesChecker from '../../../middleware/RolesChecker'
import { editAfterLoginEnum } from './editAfterLoginEnum'
import { editUserSettings } from './editUserSettings'
import { getUserSettings } from './getUserSettings'

export default (app: Express) => {
  /**
   * @openapi
   * /private/user-settings/{userId}:
   *  post:
   *    tags:
   *      - userSettings
   *    description: Edit User
   *    summary: Edit User
   *    parameters:
   *      - in: path
   *        name: userId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/EditUserSettings'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  EditUserSettings:           # <----------
   *    type: object
   *    properties:
   *      phoneNumber:
   *        type: string
   *      alternateEmail:
   *        type: string
   *      defaultBusinessId:
   *        type: string
   *      afterLoginEnum:
   *        type: number
   *      defaultLanguageId:
   *        type: string
   *      firstName:
   *        type: number
   *      surName:
   *        type: string
   *      businessId:
   *        type: string
   */
  app.post(
    '/user-settings/:userId',
    RolesChecker('EditUserSettings'),
    editUserSettings
  )

  /**
   * @openapi
   * /private/user-settings/after-login-enum/{userId}:
   *  post:
   *    tags:
   *      - userSettings
   *    description: Edit User Settings AfterLoginEnum
   *    summary: Edit User Settings AfterLoginEnum
   *    parameters:
   *      - in: path
   *        name: userId
   *        schema:
   *          type: string
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/EditUserSettingsAfterLoginEnum'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  EditUserSettingsAfterLoginEnum:           # <----------
   *    type: object
   *    properties:
   *      afterLoginEnum:
   *        type: number
   */
  app.post(
    '/user-settings/after-login-enum/:userId',
    RolesChecker('EditUserSettingsAfterLoginEnum'),
    editAfterLoginEnum
  )

  /**
   * @openapi
   * /private/user-settings/{userId}:
   *  get:
   *    tags:
   *      - userSettings
   *    description: Get user settings.
   *    summary: Get user settings.
   *    parameters:
   *      - in: path
   *        name: userId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get(
    '/user-settings/:userId',
    RolesChecker('GetUserSettings'),
    getUserSettings
  )
}
