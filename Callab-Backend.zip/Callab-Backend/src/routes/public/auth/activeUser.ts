import bcrypt from 'bcryptjs'
import { Request, Response } from 'express'
import jwt from 'jsonwebtoken'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { User } from '../../../database/entity/user'
import { UserData } from '../../../database/entity/userData'

export async function activeUser(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { firstName, surName, pass, active } = req.body
      if (
        firstName != null &&
        firstName.length > 0 &&
        surName != null &&
        surName.length > 0 &&
        pass != null &&
        pass.length > 0
      ) {
        const getUser = await transactionalEntityManager
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.userData', 'userData')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('user.activatingHash = :activatingHash', {
            activatingHash: active,
          })
          .getOne()

        if (getUser == null) {
          return res.json({
            status: 5,
          })
        }

        let payload = null
        try {
          payload = jwt.verify(active, process.env.ACTIVATE_SECRET) as {
            businessId: string
          }
        } catch (error) {
          console.error(error.message)

          return res.json({
            status: 9,
          })
        }

        getUser.activatingHash = null
        getUser.isActivated = true

        const hash = await bcrypt.hash(pass, 10)

        getUser.pass = hash

        const { businessId } = payload

        const getBusiness = await transactionalEntityManager
          .getRepository(Business)
          .createQueryBuilder('business')
          .leftJoinAndSelect('business.userData', 'userData')
          .leftJoinAndSelect('userData.business', 'businessForUserData')
          .where('business.id = :id', {
            id: businessId,
          })
          .getOne()
        if (getBusiness == null) {
          return res.json({
            status: 5,
          })
        }
        let userData = getUser.userData.find(
          (userData) => userData.business.id === businessId
        )

        if (userData == null) {
          const newUserData = new UserData()

          newUserData.business = getBusiness
          newUserData.firstName = firstName
          newUserData.surName = surName
          newUserData.user = getUser
          const savedUserData = await transactionalEntityManager
            .getRepository(UserData)
            .save(newUserData)

          if (getUser.userData != null && getUser.userData.length > 0) {
            getUser.userData = [...getUser.userData, savedUserData]
          } else {
            getUser.userData = [savedUserData]
          }

          if (getBusiness.userData != null && getBusiness.userData.length > 0) {
            getBusiness.userData = [...getBusiness.userData, savedUserData]
          } else {
            getBusiness.userData = [savedUserData]
          }

          await transactionalEntityManager
            .getRepository(Business)
            .save(getBusiness)
        }
        await transactionalEntityManager.getRepository(User).save(getUser)

        return res.json({
          status: 0,
        })
      } else {
        return res.json({
          status: 5,
        })
      }
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
