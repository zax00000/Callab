import bcrypt from 'bcryptjs'
import { Request, Response } from 'express'
import db from '../../../database'
import { User } from '../../../database/entity/user'

export async function changePassword(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { pass, pH } = req.body
      if (pass != null && pass.length > 0) {
        const getUser = await transactionalEntityManager
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.passHash = :passHash', {
            passHash: pH,
          })
          .getOne()

        if (getUser == null) {
          return res.json({
            status: 5,
          })
        }

        getUser.passHash = null
        getUser.passChange = false

        const hash = await bcrypt.hash(pass, 10)

        getUser.pass = hash

        await transactionalEntityManager.getRepository(User).save(getUser)

        return res.json({
          status: 0,
        })
      } else {
        return res.json({
          status: 5,
        })
      }
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
