import { Request, Response } from 'express'
import db from '../../../database'
import { User } from '../../../database/entity/user'

export async function checkActivationCode(req: Request, res: Response) {
  try {
    const { active } = req.body

    const getUser = await db
      .getRepository(User)
      .createQueryBuilder('user')
      .where('user.activatingHash = :activatingHash', {
        activatingHash: active,
      })
      .getOne()

    if (getUser != null) {
      return res.json({
        status: 0,
      })
    } else {
      return res.json({
        status: 5,
      })
    }
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
