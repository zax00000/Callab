import { Express } from 'express'
import { activeUser } from './activeUser'
import { changePassword } from './changePassword'
import { checkActivationCode } from './checkActivationCode'
import { checkPasswordCode } from './checkPasswordCode'
import { login } from './login'
import { newToken } from './newToken'
import { tokenReject } from './tokenReject'

export default (app: Express) => {
  /**
   * @openapi
   * /login:
   *  post:
   *    tags:
   *      - authorization
   *    description: Login Email-password.
   *    summary: Login Email-password.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/UserAuthentication'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  UserAuthentication:           # <----------
   *    type: object
   *    required:
   *      - email
   *      - password
   *    properties:
   *      email:
   *        type: string
   *      password:
   *        type: string
   */
  app.post('/login', login)

  /**
   * @openapi
   * /token:
   *  post:
   *    tags:
   *      - authorization
   *    description: Generate new AccessToken
   *    summary: Generate new AccessToken
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/RefreshToken'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  RefreshToken:           # <----------
   *    type: object
   *    required:
   *      - refreshToken
   *    properties:
   *      refreshToken:
   *        type: string
   */
  app.post('/token', newToken)

  /**
   * @openapi
   * /token/reject:
   *  post:
   *    tags:
   *      - authorization
   *    description: Reject RefreshToken
   *    summary: Reject RefreshToken
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/RefreshToken'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  RefreshToken:           # <----------
   *    type: object
   *    required:
   *      - refreshToken
   *    properties:
   *      refreshToken:
   *        type: string
   */
  app.post('/token/reject', tokenReject)

  /**
   * @openapi
   * /active:
   *  post:
   *    tags:
   *      - authorization
   *    description: Active Account
   *    summary: Active Account
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/Active'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  Active:           # <----------
   *    type: object
   *    required:
   *      - firstName
   *      - surName
   *      - pass
   *      - active
   *    properties:
   *      firstName:
   *        type: string
   *      surName:
   *        type: string
   *      pass:
   *        type: string
   *      active:
   *        type: string
   */
  app.post('/active', activeUser)

  /**
   * @openapi
   * /check-code:
   *  post:
   *    tags:
   *      - authorization
   *    description: Check activation code
   *    summary:  Check activation code
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/CheckActivationCode'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  CheckActivationCode:           # <----------
   *    type: object
   *    required:
   *      - active
   *    properties:
   *      active:
   *        type: string
   */
  app.post('/check-code', checkActivationCode)

  /**
   * @openapi
   * /check-password-code:
   *  post:
   *    tags:
   *      - authorization
   *    description: Check password code
   *    summary:  Check password code
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/CheckPasswordCode'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  CheckPasswordCode:           # <----------
   *    type: object
   *    required:
   *      - pH
   *    properties:
   *      pH:
   *        type: string
   */

  app.post('/check-password-code', checkPasswordCode)
  /**
   * @openapi
   * /change-password:
   *  post:
   *    tags:
   *      - authorization
   *    description: Check password code
   *    summary:  Check password code
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/ChangePassword'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  ChangePassword:           # <----------
   *    type: object
   *    required:
   *      - pH
   *      - pass
   *    properties:
   *      pass:
   *        type: string
   *      pH:
   *        type: string
   */
  app.post('/change-password', changePassword)
}
