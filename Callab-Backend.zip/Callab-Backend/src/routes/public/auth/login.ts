import bcrypt from 'bcryptjs'
import { Request, Response } from 'express'
import jwt from 'jsonwebtoken'
import db from '../../../database'
import { Authentication } from '../../../database/entity/authentication'
import { User } from '../../../database/entity/user'

const CountAuthenticateDifferentDevice = 5

export async function login(req: Request, res: Response) {
  try {
    let { email, password } = req.body
    email = email.toLowerCase()

    if (!(email && password)) {
      return res.status(200).send({ status: 5 })
    }

    const user = await db
      .getRepository(User)
      .createQueryBuilder('user')
      .leftJoinAndSelect('user.authentications', 'authentication')
      .leftJoinAndSelect('user.settings', 'settings')
      .leftJoinAndSelect('settings.defaultBusiness', 'defaultBusiness')
      .where('user.email = :email', { email })
      .getOne()

    if (user != null) {
      if (!user.isActivated) {
        return res.json({
          status: 2,
        })
      }
      const validPassword = await bcrypt.compare(password, user.pass)

      if (!validPassword) {
        return res.json({
          status: 1,
        })
      }

      let tokenUser

      const refreshToken = jwt.sign(
        { id: user.id },
        process.env.REFRESH_TOKEN_SECRET,
        {
          expiresIn: '100y',
        }
      )

      const newAuthentication = new Authentication()

      newAuthentication.user = user
      newAuthentication.refreshToken = refreshToken
      newAuthentication.dateLogin = new Date()

      const userAuthentications = user.authentications.sort(
        (a, b) =>
          new Date(a.dateLogin).getTime() - new Date(b.dateLogin).getTime()
      )
      if (
        user.authentications &&
        user.authentications.length >= CountAuthenticateDifferentDevice
      ) {
        await db
          .getRepository(Authentication)
          .remove(userAuthentications.shift())
      }
      userAuthentications.push(newAuthentication)
      user.authentications = userAuthentications
      const authentication = await db
        .getRepository(Authentication)
        .save(newAuthentication)
      if (user.superAdmin) {
        const userRoles = await db
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.businessRoles', 'role')
          .where('user.id = :id', { id: user.id })
          .getOne()

        if (userRoles.businessRoles.some((role) => role.superAdminApi)) {
          tokenUser = {
            id: user.id,
            authId: authentication.id,
            superAdmin: true,
            dashboardAdmin: true,
          }
        } else {
          return res.json({
            status: 2,
          })
        }
      } else {
        tokenUser = {
          id: user.id,
          authId: authentication.id,
        }
      }

      const accessToken = jwt.sign(tokenUser, process.env.TOKEN_SECRET, {
        expiresIn: 300,
      })

      user.isLogged = true
      user.dateLogIn = new Date()
      await db.getRepository(User).save(user)

      return res.json({
        status: 0,
        accessToken,
        refreshToken,
        defaultBusinessId: user?.settings?.defaultBusiness?.id || '',
      })
    } else {
      return res.json({
        status: 1,
      })
    }
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
