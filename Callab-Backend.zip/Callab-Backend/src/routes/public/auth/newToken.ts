import { Request, Response } from 'express'
import jwt from 'jsonwebtoken'
import db from '../../../database'
import { User } from '../../../database/entity/user'

export async function newToken(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { refreshToken } = req.body
      let payload = null
      try {
        payload = jwt.verify(
          refreshToken,
          process.env.REFRESH_TOKEN_SECRET
        ) as {
          id: number
        }
      } catch (error) {
        console.error(error.message)

        return res.json({
          status: 9,
        })
      }

      if (payload && payload.id) {
        const user = await transactionalEntityManager
          .getRepository(User)
          .createQueryBuilder('user')
          .leftJoinAndSelect('user.authentications', 'authentication')
          .leftJoinAndSelect('authentication.activeBusiness', 'business')
          .leftJoinAndSelect('authentication.activeBusinessRole', 'role')
          .leftJoinAndSelect('user.settings', 'settings')
          .leftJoinAndSelect('settings.defaultBusiness', 'defaultBusiness')
          .where('user.id = :id', { id: payload.id })
          .getOne()

        if (user == null) {
          return res.json({
            status: 9,
          })
        }

        const userRefreshToken = user.authentications.find(
          (authentication) => authentication.refreshToken === refreshToken
        )
        const defaultBusinessId = user?.settings?.defaultBusiness?.id || ''

        if (userRefreshToken != null) {
          let tokenUser

          if (user.superAdmin) {
            tokenUser = {
              id: user.id,
              superAdmin: user.superAdmin,
              authId: userRefreshToken.id,
              dashboardAdmin: true,
            }
          } else {
            tokenUser = {
              id: user.id,
              authId: userRefreshToken.id,
              role: userRefreshToken.activeBusinessRole?.id,
              business: userRefreshToken.activeBusiness?.id,
            }
          }
          const accessToken = jwt.sign(tokenUser, process.env.TOKEN_SECRET, {
            expiresIn: 300,
          })

          user.isLogged = true
          await transactionalEntityManager.getRepository(User).save(user)

          return res.json({
            status: 0,
            accessToken,
            refreshToken,
            defaultBusinessId,
          })
        }
        return res.json({
          status: 9,
        })
      } else {
        return res.json({
          status: 9,
        })
      }
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
