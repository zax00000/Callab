import { Request, Response } from 'express'
import jwt from 'jsonwebtoken'
import db from '../../../database'
import { Authentication } from '../../../database/entity/authentication'

export async function tokenReject(req: Request, res: Response) {
  try {
    const { refreshToken } = req.body
    let payload = null
    try {
      payload = jwt.verify(refreshToken, process.env.REFRESH_TOKEN_SECRET) as {
        id: number
      }
    } catch (error) {
      console.error(error.message)

      return res.json({
        status: 9,
      })
    }

    if (payload && payload.id) {
      await db
        .createQueryBuilder()
        .delete()
        .from(Authentication)
        .where('refreshToken = :refreshToken', { refreshToken: refreshToken })
        .execute()
      return res.json({
        status: 0,
      })
    } else {
      return res.json({
        status: 9,
      })
    }
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
