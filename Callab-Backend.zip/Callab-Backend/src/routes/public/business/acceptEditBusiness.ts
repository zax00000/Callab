import { Request, Response } from 'express'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { BusinessChanges } from '../../../database/entity/businessChanges'
import { User } from '../../../database/entity/user'

export async function acceptEditBusiness(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { token } = req.body

      const getChangeBusiness = await transactionalEntityManager
        .getRepository(BusinessChanges)
        .createQueryBuilder('businessChanges')
        .leftJoinAndSelect('businessChanges.business', 'business')
        .where('businessChanges.changesToken = :changesToken', {
          changesToken: token,
        })
        .getOne()

      if (getChangeBusiness == null) {
        return res.json({
          status: 4,
        })
      }

      const getBusiness = await transactionalEntityManager
        .getRepository(Business)
        .createQueryBuilder('business')
        .where('business.id = :id', {
          id: getChangeBusiness.business.id,
        })
        .getOne()

      if (getBusiness == null) {
        return res.json({
          status: 4,
        })
      }

      ;[
        'nip',
        'name',
        'country',
        'zipCode',
        'city',
        'address1',
        'address2',
        'phoneNumber',
        'contactName',
        'contactLastName',
      ].forEach((fieldName) => {
        const filed = getChangeBusiness[fieldName as 'nip']
        if (filed) {
          getBusiness[fieldName as 'nip'] = filed
        }
      })

      const { email } = getChangeBusiness
      if (email != null) {
        getBusiness.email = email.toLowerCase()
      }

      const user = await transactionalEntityManager
        .getRepository(User)
        .createQueryBuilder('user')
        .where('user.id = :id', { id: getChangeBusiness.userId })
        .getOne()

      getBusiness.idUserModified = user
      getBusiness.dateModified = getChangeBusiness.dateModification

      await transactionalEntityManager.getRepository(Business).save(getBusiness)

      await transactionalEntityManager
        .getRepository(BusinessChanges)
        .remove(getChangeBusiness)

      return res.json({
        status: 0,
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
