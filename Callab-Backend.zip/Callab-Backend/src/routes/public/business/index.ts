import { Express } from 'express'
import { acceptEditBusiness } from './acceptEditBusiness'

export default (app: Express) => {
  /**
   * @openapi
   * /accept-business-changes:
   *  post:
   *    tags:
   *      - business
   *    description: Accept business changes.
   *    summary: Accept business changes.
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/acceptBusinessChanges'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  acceptBusinessChanges:           # <----------
   *    type: object
   *    properties:
   *      token:
   *        type: string
   */
  app.post('/accept-business-changes', acceptEditBusiness)
}
