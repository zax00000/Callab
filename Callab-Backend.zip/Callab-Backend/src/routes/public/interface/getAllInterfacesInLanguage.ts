import { Request, Response } from 'express'
import db from '../../../database'
import { Interface } from '../../../database/entity/interface'

export async function getAllInterfacesInLanguage(req: Request, res: Response) {
  try {
    const { languageId } = req.params

    const getInterfaces = await db
      .getRepository(Interface)
      .createQueryBuilder('interface')
      .leftJoinAndSelect('interface.translation', 'translation')
      .leftJoinAndSelect('translation.language', 'language')
      .select([
        'interface.name',
        'translation.language',
        'translation.translation',
        'language.id',
      ])
      .getMany()

    const interfaces = getInterfaces.map(({ name, translation }) => {
      const translationLanguage = translation.find(
        (element) => element.language.id === languageId
      )
      return {
        name,
        translationString:
          translationLanguage != null && translationLanguage.translation
            ? translationLanguage.translation
            : '',
      }
    })
    return res.json({
      status: 0,
      interfaces: interfaces,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
