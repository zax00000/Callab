import { Request, Response } from 'express'
import db from '../../../database'
import { Interface } from '../../../database/entity/interface'

export async function getInterface(req: Request, res: Response) {
  try {
    const { interfaceName } = req.params

    const getInterface = await db
      .getRepository(Interface)
      .createQueryBuilder('interface')
      .leftJoinAndSelect('interface.translation', 'translation')
      .leftJoinAndSelect('translation.language', 'language')
      .where('interface.name = :name', { name: interfaceName })
      .getOne()

    return res.json({
      status: 0,
      interface: getInterface,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
