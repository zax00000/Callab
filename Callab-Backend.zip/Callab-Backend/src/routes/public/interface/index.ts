import { Express } from 'express'
import { getAllInterfacesInLanguage } from './getAllInterfacesInLanguage'
import { getInterface } from './getInterface'

export default (app: Express) => {
  /**
   * @openapi
   * /interface/{interfaceName}:
   *  get:
   *    tags:
   *      - interface
   *    description: Get Interface.
   *    summary: Get Interface.
   *    parameters:
   *      - in: path
   *        name: interfaceName
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/interface/:interfaceName', getInterface)

  /**
   * @openapi
   * /interfaces/language/{languageId}:
   *  get:
   *    tags:
   *      - interface
   *    description: Get all interfaces.
   *    summary: Get all interfaces.
   *    parameters:
   *      - in: path
   *        name: languageId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/interfaces/language/:languageId', getAllInterfacesInLanguage)
}
