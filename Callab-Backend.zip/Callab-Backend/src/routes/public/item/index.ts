import { Express } from 'express'

import path from 'path'

export default (app: Express) => {
  /**
   * @openapi
   * /item-picture/{itemPicture}:
   *  get:
   *    tags:
   *      - item
   *    description: get item Picture.
   *    summary: get item Picture.
   *    parameters:
   *      - in: path
   *        name: itemPicture
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok Return Picture
   */
  app.get('/item-picture/:itemPicture', (req, res) => {
    const { itemPicture } = req.params
    res.sendFile(path.join(__dirname, '/static/itemPicture/', itemPicture))
  })
}
