import { Request, Response } from 'express'
import db from '../../../database'
import { Languages } from '../../../database/entity/languages'

export async function getAllLanguages(req: Request, res: Response) {
  try {
    const getLanguages = await db
      .getRepository(Languages)
      .createQueryBuilder('language')
      .select([
        'language.active',
        'language.languageCode',
        'language.name',
        'language.id',
      ])
      .getMany()

    return res.json({
      status: 0,
      languages: getLanguages,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
