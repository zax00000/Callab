import { Request, Response } from 'express'
import db from '../../../database'
import { Languages } from '../../../database/entity/languages'

export async function getLanguage(req: Request, res: Response) {
  try {
    const { languageId } = req.params

    const getLanguage = await db
      .getRepository(Languages)
      .createQueryBuilder('language')
      .where('language.id = :id', { id: languageId })
      .getOne()

    return res.json({
      status: 0,
      language: getLanguage,
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
    })
  }
}
