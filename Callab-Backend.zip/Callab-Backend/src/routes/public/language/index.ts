import { Express } from 'express'
import { getAllLanguages } from './getAllLanguages'
import { getLanguage } from './getLanguage'

export default (app: Express) => {
  /**
   * @openapi
   * /language/{languageId}:
   *  get:
   *    tags:
   *      - language
   *    description: Get Language.
   *    summary: Get Language.
   *    parameters:
   *      - in: path
   *        name: languageId
   *        schema:
   *          type: string
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/language/:languageId', getLanguage)

  /**
   * @openapi
   * /languages:
   *  get:
   *    tags:
   *      - language
   *    description: Get all languages.
   *    summary: Get all languages.
   *    responses:
   *      200:
   *        description: Ok
   */
  app.get('/languages', getAllLanguages)
}
