import { Request, Response } from 'express'
import jwt from 'jsonwebtoken'
import db from '../../../database'
import { Business } from '../../../database/entity/business'
import { Role } from '../../../database/entity/role'
import { RoomsMembers } from '../../../database/entity/roomsMembers'
import { TemporaryUser } from '../../../database/entity/temporaryUser'

export async function decodeLink(req: Request, res: Response) {
  try {
    return await db.transaction(async (transactionalEntityManager) => {
      const { token } = req.body

      let payload
      try {
        payload = jwt.verify(token, process.env.MEETING_SECRET) as {
          tempUser: string
          businessId: string
        }
      } catch (error) {
        console.error(error.message)
        return res.json({
          status: 9,
        })
      }

      const { tempUser, businessId } = payload

      const getTemporaryUserPromise = transactionalEntityManager
        .getRepository(TemporaryUser)
        .createQueryBuilder('temporaryUser')
        .leftJoinAndSelect('temporaryUser.roomMember', 'roomMember')
        .leftJoinAndSelect('roomMember.room', 'room')
        .leftJoinAndSelect('roomMember.user', 'user')
        // .leftJoinAndSelect('room.floor', 'floor')
        // .leftJoinAndSelect('floor.business', 'business')
        // .leftJoinAndSelect('business.users', 'users')
        // .leftJoinAndSelect('users.userData', 'userData')
        // .leftJoinAndSelect('userData.business', 'businessUserData')
        .where('temporaryUser.id = :id', { id: tempUser })
        .getOne()

      const getBusinessPromise = transactionalEntityManager
        .getRepository(Business)
        .createQueryBuilder('business')
        .leftJoinAndSelect('business.users', 'users')
        .leftJoinAndSelect('users.userData', 'userData')
        .leftJoinAndSelect('userData.business', 'businessUserData')
        .where('business.id = :id', { id: businessId })
        .getOne()

      const [getTemporaryUser, getBusiness] = await Promise.all([
        getTemporaryUserPromise,
        getBusinessPromise,
      ])

      if (
        getTemporaryUser == null ||
        getTemporaryUser.accessHash.length === 0 ||
        getBusiness == null
      ) {
        return res.json({
          status: 2,
        })
      }

      const userInBusiness = getBusiness.users.find(
        (user) => user.email === getTemporaryUser.email
      )

      if (userInBusiness != null) {
        const userData = userInBusiness.userData.find(
          ({ business }) => business.id === getBusiness.id
        )

        let getRoomsMembersForUser = await transactionalEntityManager
          .getRepository(RoomsMembers)
          .createQueryBuilder('roomsMembers')
          .leftJoinAndSelect('roomsMembers.user', 'user')
          .leftJoinAndSelect('roomsMembers.room', 'room')
          .where('user.id = :idUser', { idUser: userInBusiness.id })
          .andWhere('room.id = :idRoom', {
            idRoom: getTemporaryUser.roomMember.room.id,
          })
          .getOne()

        if (getRoomsMembersForUser == null) {
          const newRoomMembers = new RoomsMembers()

          const dateNow = new Date()

          newRoomMembers.dateCreated = dateNow
          newRoomMembers.dateModified = dateNow
          newRoomMembers.idUserCreated = userInBusiness
          newRoomMembers.idUserModified = userInBusiness

          newRoomMembers.isGuest = true
          newRoomMembers.room = getTemporaryUser.roomMember.room
          newRoomMembers.user = userInBusiness

          getRoomsMembersForUser = await transactionalEntityManager
            .getRepository(RoomsMembers)
            .save(newRoomMembers)
          await transactionalEntityManager
            .getRepository(RoomsMembers)
            .remove(getTemporaryUser.roomMember)
        }
        const userId = userInBusiness.id
        const email = userInBusiness.email

        const firstName = userData?.firstName || ''
        const surName = userData?.surName || ''
        const roomId = getTemporaryUser.roomMember.room.id
        const isInBusiness = true
        if (getTemporaryUser.roomMember.user == null) {
          getTemporaryUser.roomMember = getRoomsMembersForUser
          getTemporaryUser.accessHash = ''
          await transactionalEntityManager
            .getRepository(TemporaryUser)
            .save(getTemporaryUser)
        }

        return res.json({
          status: 0,
          user: {
            userId,
            email,
            firstName,
            surName,
            roomId,
            isInBusiness,
            businessId,
          },
        })
      }

      if (
        getTemporaryUser == null ||
        getTemporaryUser.roomMember == null ||
        getBusiness?.id == null
      ) {
        return res.json({
          status: 9,
        })
      }

      const { firstName: firstNameFormBody, surName: surNameFormBody } =
        req.body

      if (
        firstNameFormBody == null ||
        firstNameFormBody.toString().length === 0 ||
        surNameFormBody == null
      ) {
        return res.json({
          status: 5,
        })
      }

      getTemporaryUser.firstName = firstNameFormBody.toString()
      getTemporaryUser.surName = surNameFormBody.toString()
      getTemporaryUser.accessHash = ''

      const savedTemporaryUser = await transactionalEntityManager
        .getRepository(TemporaryUser)
        .save(getTemporaryUser)

      const { firstName, surName, email, roomMember } = savedTemporaryUser

      const getGuessRole = await transactionalEntityManager
        .getRepository(Role)
        .createQueryBuilder('role')
        .where('role.name = :name', { name: 'guessRole' })
        .getOne()

      const tokenUser = {
        role: getGuessRole?.id,
        business: businessId,
        tempUser: savedTemporaryUser.id,
      }

      const accessToken = jwt.sign(tokenUser, process.env.TOKEN_SECRET, {
        expiresIn: '4h',
      })
      const roomId = roomMember.room.id
      const isInBusiness = false

      return res.json({
        status: 0,
        user: {
          accessToken,
          roomId,
          firstName,
          surName,
          email,
          businessId,
          isInBusiness,
        },
      })
    })
  } catch (error) {
    console.error(error.message)

    return res.json({
      status: 6,
      message: error.message,
    })
  }
}
