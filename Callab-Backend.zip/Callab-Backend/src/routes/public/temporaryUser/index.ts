import { Express } from 'express'
import { decodeLink } from './decodeLink'

export default (app: Express) => {
  /**
   * @openapi
   * /decode-meeting:
   *  post:
   *    tags:
   *      - meeting
   *    description: decode code
   *    summary: decode code
   *    requestBody:
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/definitions/decodeMeetingLink'
   *    responses:
   *      200:
   *        description: Ok
   *definitions:
   *  decodeMeetingLink:           # <----------
   *    type: object
   *    properties:
   *      token:
   *        type: string
   *      firstName:
   *        type: string
   *      surName:
   *        type: string
   */
  app.post('/decode-meeting/', decodeLink)
}
