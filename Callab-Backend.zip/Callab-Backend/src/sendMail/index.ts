import nodemailer from 'nodemailer'
import SMTPTransport from 'nodemailer/lib/smtp-transport'

class SendMail {
  #transporter: nodemailer.Transporter<SMTPTransport.SentMessageInfo>
  #mailTryList: {
    mailObject: {
      from: string
      to: string
      subject: string
      text: string
      html: string
    }
    count: number
  }[] = []
  #intervalSendMail = 30
  #checkEmailInterval: NodeJS.Timer
  constructor() {}

  initialize({ intervalSendMail }: { intervalSendMail?: number }) {
    try {
      this.#transporter = nodemailer.createTransport({
        host: process.env.MAIL_HOST,
        port: Number(process.env.MAIL_PORT as unknown as number),
        secure: true, // true for 465, false for other ports
        auth: {
          user: process.env.MAIL_USER, // generated ethereal user
          pass: process.env.MAIL_USER_PASSWORD, // generated ethereal password
        },
      })

      if (intervalSendMail && !process.env.IS_TEST) {
        this.#checkEmailInterval = setInterval(
          () => this.#checkEmail(),
          this.#intervalSendMail * 1000
        )
      }
    } catch (error) {
      console.error(error.message)
    }
  }

  async #checkEmail() {
    try {
      const newMailTryList: {
        mailObject: {
          from: string
          to: string
          subject: string
          text: string
          html: string
        }
        count: number
      }[] = []
      await Promise.all(
        this.#mailTryList.map(({ mailObject, count }) => {
          this.#transporter.sendMail(mailObject, (error, info) => {
            if (error) {
              newMailTryList.push({ mailObject, count: count - 1 })
              return
            }
          })
        })
      )
      this.#mailTryList = newMailTryList
    } catch (error) {
      console.error(error.message)
    }
  }

  sendMail({
    to,
    replyTo,
    subject,
    text,
    html,
  }: {
    to: string
    replyTo?: string
    subject: string
    text: string
    html: string
  }) {
    const mailObject = {
      from: '"Callab" <no-reply@callab.cba.pl>', // sender address
      to, // list of receivers
      subject, // Subject line
      text, // plain text body
      html, // html body
      replyTo: replyTo,
    }
    if (!process.env.IS_TEST) {
      this.#transporter.sendMail(mailObject, (error, info) => {
        if (error) {
          console.error(error.message)
          this.#mailTryList.push({ mailObject, count: 5 })
          return
        }
      })
    }
  }

  deleteSendMail() {
    clearInterval(this.#checkEmailInterval)
  }
}

export default new SendMail()
