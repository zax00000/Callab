export default (businessName: string) => `
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Activate admin Account</title>
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Manrope:wght@600&display=swap");

      body {
        max-width: 500px; 
        margin: 0 auto;
        font-family: "Manrope", system-ui, sans-serif;
        line-height: 1.6;
        padding: 1rem;
      }
    </style>
  </head>
  <body>
    <main style="text-align: center">
      <div style="display: flex; justify-content: center; flex-direction: row">
        <img
          style="display: block; margin-left: auto; margin-right: auto"
          src="https://callab.cba.pl/TemplateData/432x432.png"
          alt="Logo"
          width="200"
          height="200"
        />
      </div>
      <h2 style="text-align: center">Business ${businessName} has been added to the collab application</h2>
    </main>
  </body>
</html>

`
