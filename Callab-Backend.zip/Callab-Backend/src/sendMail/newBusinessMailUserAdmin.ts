export default (email: string, uuid: string, businessName: string) => `
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Activate admin Account</title>
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Manrope:wght@600&display=swap");

      body {
        max-width: 500px; 
        margin: 0 auto;
        font-family: "Manrope", system-ui, sans-serif;
        line-height: 1.6;
        padding: 1rem;
      }
    </style>
  </head>
  <body>
    <main style="text-align: center">
      <div style="display: flex; justify-content: center; flex-direction: row">
        <img
          style="display: block; margin-left: auto; margin-right: auto"
          src="https://callab.cba.pl/TemplateData/432x432.png"
          alt="Logo"
          width="200"
          height="200"
        />
      </div>
      <h2 style="text-align: center">Business ${businessName} with e-mail ${email} has been added to the collab application</h2>
      <p style="text-align: center">Click the button to go active admin account</p>
      <div style="width: 100%; text-align: center; margin: 24px 0px">
        <a
          href="${process.env.DASHBOARD_URL}/activation?active=${uuid}"
          target="_blank"
          style="
            background-color: #7a6eae;
            border: none;
            color: white;
            border-radius: 10px;
            padding: 16px 32px;
            text-decoration: none;
            margin: 8px 2px;
            cursor: pointer;
          "
        >
          Activate
        </a>
      </div>
      <p style="text-align: center">And click the button to go Login</p>
      <div style="width: 100%; text-align: center; margin: 24px 0px">
        <a
          href="${process.env.APP_URL}"
          target="_blank"
          style="
            background-color: #7a6eae;
            border: none;
            color: white;
            border-radius: 10px;
            padding: 16px 32px;
            text-decoration: none;
            margin: 8px 2px;
            cursor: pointer;
          "
        >
          Login
        </a>
      </div>
    </main>
  </body>
</html>

`
