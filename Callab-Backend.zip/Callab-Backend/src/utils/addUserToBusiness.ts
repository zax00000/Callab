import crypto from 'crypto'
import jwt from 'jsonwebtoken'
import { EntityManager } from 'typeorm/entity-manager/EntityManager'
import { Business } from '../database/entity/business'
import { Role } from '../database/entity/role'
import { User } from '../database/entity/user'
import { UserData } from '../database/entity/userData'
import { UserSettings } from '../database/entity/userSettings'
import sendMail from '../sendMail'
import newBusinessMail from '../sendMail/newBusinessMail'
import newBusinessMailUserAdmin from '../sendMail/newBusinessMailUserAdmin'
import { checkLicenseTime } from './checkLicenseTime'
import emailValidator from './emailValidator'

export default async ({
  email,
  userId,
  businessId,
  roleId,
  transactionalEntityManager,
}: {
  email: string
  userId: string
  businessId: string
  roleId: string
  transactionalEntityManager: EntityManager
}) => {
  email = email?.toLowerCase()
  if (email != null) {
    if (!(await emailValidator(email))) {
      return {
        status: 4,
      }
    }

    const userPromise = transactionalEntityManager
      .getRepository(User)
      .createQueryBuilder('user')
      .where('user.id = :id', { id: userId })
      .getOne()

    const getBusinessPromise = transactionalEntityManager
      .getRepository(Business)
      .createQueryBuilder('business')
      .leftJoinAndSelect('business.license', 'license')
      .leftJoinAndSelect('business.users', 'user')
      .where('business.id = :id', {
        id: businessId,
      })
      .getOne()

    const [user, getBusiness] = await Promise.all([
      userPromise,
      getBusinessPromise,
    ])
    if (checkLicenseTime(getBusiness.license)) {
      return {
        status: 7,
      }
    }
    if (
      getBusiness.license.maxUsersInBusiness !== 0 &&
      getBusiness.users &&
      getBusiness.users.length >= getBusiness.license.maxUsersInBusiness
    ) {
      return {
        status: 7,
      }
    }

    const getRolePromise = transactionalEntityManager
      .getRepository(Role)
      .createQueryBuilder('role')
      .where('role.id = :id', {
        id: roleId,
      })
      .getOne()

    const newUserPromise = transactionalEntityManager
      .getRepository(User)
      .createQueryBuilder('user')
      .leftJoinAndSelect('user.business', 'business')
      .leftJoinAndSelect('user.businessRoles', 'businessRoles')
      .leftJoinAndSelect('user.userData', 'userData')
      .where('user.email = :email', { email: email })
      .getOne()

    const getRole = await getRolePromise
    let newUser = await newUserPromise

    const newDate = new Date()

    const userNotExists = newUser == null
    if (userNotExists) {
      newUser = new User()

      newUser.email = email as string
      newUser.isActivated = false
      newUser.activatingHash = jwt.sign(
        { businessId: getBusiness.id, rand: crypto.randomUUID() },
        process.env.ACTIVATE_SECRET,
        {
          expiresIn: '9999y',
        }
      )
      newUser.idUserCreated = user
      newUser.dateCreated = newDate

      newUser.settings = new UserSettings()
      newUser.settings.alternateEmail = ''
      newUser.settings.defaultBusiness = null
      newUser.settings.phoneNumber = ''
      await transactionalEntityManager
        .getRepository(UserSettings)
        .save(newUser.settings)
    }

    newUser.idUserModified = user
    newUser.dateModified = newDate
    newUser.business = [
      ...(newUser && newUser.business ? newUser.business : []),
      getBusiness,
    ]
    newUser.businessRoles = [
      ...(newUser && newUser.businessRoles ? newUser.businessRoles : []),
      getRole,
    ]

    const newUserData = new UserData()
    newUserData.business = getBusiness
    newUserData.user = newUser

    if (newUser?.userData != null && newUser.userData.length > 0) {
      newUser.userData = [...newUser.userData, newUserData]
    } else {
      newUser.userData = [newUserData]
    }
    const newUserResponse = await transactionalEntityManager
      .getRepository(User)
      .save(newUser)

    sendMail.sendMail({
      to: newUserResponse.email,
      subject: 'New Business in Callab',
      text: 'New Business in Callab',
      html: newBusinessMail(getBusiness.name),
    })

    if (userNotExists) {
      sendMail.sendMail({
        to: newUserResponse.email,
        subject: 'Active Admin Account',
        text: 'Active Admin Account',
        html: newBusinessMailUserAdmin(
          newUserResponse.email,
          newUserResponse.activatingHash,
          getBusiness.name
        ),
      })
    }

    return {
      status: 0,
      userId: newUserResponse.id,
    }
  } else {
    return {
      status: 4,
    }
  }
}
