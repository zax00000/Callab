import { License } from '../database/entity/license'

export function checkLicenseTime(license: License) {
  const DateNow = new Date().getTime()
  return (
    license == null ||
    (license.endDate != null &&
      new Date(license.endDate).getTime() < DateNow) ||
    new Date(license.startDate).getTime() > DateNow
  )
}
