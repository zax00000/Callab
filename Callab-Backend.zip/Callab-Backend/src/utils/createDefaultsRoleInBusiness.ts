import { EntityManager } from 'typeorm/entity-manager/EntityManager'
import { Business } from '../database/entity/business'
import { PowersApp } from '../database/entity/powersApp'
import { Role } from '../database/entity/role'
import { User } from '../database/entity/user'

const POWERS_APP_NAME = ['User', 'Admin']

export default async (
  business: Business,
  getUser: User,
  transactionalEntityManager: EntityManager
) => {
  try {
    const getPowersApp = await transactionalEntityManager
      .getRepository(PowersApp)
      .createQueryBuilder('powersApp')
      .getMany()

    const powersAppIdBaseId = getPowersApp.filter(
      (powerApp) => powerApp.name === 'Base'
    )

    const powersAppIdAdminId = getPowersApp.filter(
      (powerApp) => powerApp.name !== 'SuperAdmin'
    )

    const PowerApp = await Promise.all(
      [powersAppIdBaseId, powersAppIdAdminId].map(async (powersApp, index) => {
        const newRole = new Role()
        newRole.business = business
        if (powersApp != null && powersApp.length > 0) {
          newRole.powersApp = powersApp
        }
        newRole.dateCreated = new Date()
        newRole.dateModified = new Date()
        newRole.idUserCreated = getUser
        newRole.idUserModified = getUser
        newRole.name = POWERS_APP_NAME[index]
        return transactionalEntityManager.getRepository(Role).save(newRole)
      })
    )
    return PowerApp[1]
  } catch (error) {
    console.error(error.message)
    return false
  }
}
