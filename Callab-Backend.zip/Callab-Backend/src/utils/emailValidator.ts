import { validate } from 'deep-email-validator'
import * as EmailValidator from 'email-validator'

export default async (email: string) => {
  try {
    let emailValidation = EmailValidator.validate(email)
    let emailValidationDeep = await validate({
      email: email,
      sender: email,
      validateRegex: true,
      validateMx: true,
      validateTypo: false,
      validateDisposable: true,
      validateSMTP: false,
    })

    return (
      Boolean(process.env.IS_TEST) || (emailValidation && emailValidationDeep)
    )
  } catch (error) {
    console.error(error.message)
  }
}
