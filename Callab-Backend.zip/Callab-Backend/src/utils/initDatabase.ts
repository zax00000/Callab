import bcrypt from 'bcryptjs'
import db from '../database'
import { User } from '../database/entity/user'

const adminUser = {
  email: process.env.SUPER_ADMIN_EMAIL,
  password: process.env.SUPER_ADMIN_PASSWORD,
  firstName: 'admin',
  surName: 'admin',
}

export default async () => {
  try {
    await db.initialize()
    console.log('\x1b[34m', 'Base Connected')

    const getUser = await db
      .getRepository(User)
      .createQueryBuilder('user')
      .leftJoinAndSelect('user.authentications', 'authentication')
      .leftJoinAndSelect('authentication.activeBusiness', 'business')
      .where('user.email = :email', { email: adminUser.email })
      .getOne()

    if (!getUser) {
      const hash = bcrypt.hashSync(adminUser.password, 10)
      const newUser = new User()

      const newDate = new Date()
      newUser.email = adminUser.email as string
      newUser.isActivated = true
      newUser.pass = hash
      newUser.idUserCreated = null
      newUser.idUserModified = null
      newUser.superAdmin = true
      newUser.dateCreated = newDate
      newUser.dateModified = newDate
      await db.getRepository(User).save(newUser)
      console.log('Admin Created')
    }

    return db
  } catch (error) {
    console.error(error.message)
  }
}
