import sendMail from '../sendMail'

export default async () => {
  try {
    sendMail.initialize({ intervalSendMail: 30 })
  } catch (error) {
    console.error(error.message)
  }
}
