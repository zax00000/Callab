import db from '../database'
import { RoomsMembers } from '../database/entity/roomsMembers'

export async function noManagerForRoom({ roomId }: { roomId: any }) {
  return await db.transaction(async (transactionalEntityManager) => {
    const getRoomMembers = await transactionalEntityManager
      .getRepository(RoomsMembers)
      .createQueryBuilder('roomsMembers')
      .leftJoinAndSelect('roomsMembers.room', 'room')
      .where('roomsMembers.room.id = :id', {
        id: roomId,
      })
      .getMany()

    const managers = getRoomMembers.filter((roomMember) => roomMember.isManager)

    return await Promise.all(
      managers.map(async (managers) => {
        managers.isManager = false
        managers.isModerator = true

        return await transactionalEntityManager
          .getRepository(RoomsMembers)
          .save(managers)
      })
    )
  })
}
