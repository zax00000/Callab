import { PowersApi } from '../database/entity/powersApi'
import { PowersApp } from '../database/entity/powersApp'
import { Role } from '../database/entity/role'
import { User } from '../database/entity/user'
import db from '../database/index'
import powers from './powers.json'

// const UpdateRolesTimeToNext: number = 1000 * 60 * 10
const powersRoles = class {
  #rolesApi: Record<string, any> = {}
  // #UpdateRolesTime: number = Date.now()
  constructor() {}

  async init() {
    try {
      await this.#CreatePowers()
      await this.#createBasicRoles()
      await this.#generateRoles()
    } catch (error) {
      console.error(error.message)
    }
  }

  async #CreatePowers() {
    return await db.transaction(async (transactionalEntityManager) => {
      const getAllPowersApp = await transactionalEntityManager
        .getRepository(PowersApp)
        .createQueryBuilder('powersApp')
        .leftJoinAndSelect('powersApp.powersApi', 'powersApi')
        .getMany()

      const powersObject = powers.powers
      const powersKeys = Object.keys(powersObject)
      const allPowersApiPromise = powersKeys.map(
        async (powersAppNameKey: 'Base') => {
          const powerApp = getAllPowersApp.find(
            (powersApp) => powersApp.name === powersAppNameKey
          )

          if (powerApp == null) {
            const newPowerApp = new PowersApp()
            newPowerApp.name = powersAppNameKey
            newPowerApp.powerEnum = powersObject[powersAppNameKey].powerEnum
            newPowerApp.powersApi = await Promise.all(
              powersObject[powersAppNameKey].powerApi.map(async (powerApi) => {
                const newPowerApi = new PowersApi()
                newPowerApi.name = powerApi
                return await transactionalEntityManager
                  .getRepository(PowersApi)
                  .save(newPowerApi)
              })
            )
            return transactionalEntityManager
              .getRepository(PowersApp)
              .save(newPowerApp)
          } else {
            powerApp.powersApi = await Promise.all(
              powersObject[powersAppNameKey].powerApi.map(async (powerApi) => {
                const findPowerApi = powerApp.powersApi.find(
                  (oldPowerApi) => oldPowerApi.name === powerApi
                )

                if (findPowerApi != null) {
                  return findPowerApi
                } else {
                  const newPowerApi = new PowersApi()
                  newPowerApi.name = powerApi
                  return transactionalEntityManager
                    .getRepository(PowersApi)
                    .save(newPowerApi)
                }
              })
            )
            return transactionalEntityManager
              .getRepository(PowersApp)
              .save(powerApp)
          }
        }
      )

      await Promise.all(allPowersApiPromise)
    })
  }

  async #createBasicRoles() {
    return await db.transaction(async (transactionalEntityManager) => {
      const superAdmin = await transactionalEntityManager
        .getRepository(Role)
        .createQueryBuilder('role')
        .where('role.name = :name', {
          name: 'superAdmin',
        })
        .getOne()
      if (!superAdmin) {
        const newDate = new Date()
        const newRole = new Role()
        newRole.name = 'superAdmin'
        newRole.dateCreated = newDate
        newRole.dateModified = newDate
        newRole.superAdminApi = true

        const roleAdmin = await transactionalEntityManager
          .getRepository(Role)
          .save(newRole)

        const superAdmin = await transactionalEntityManager
          .getRepository(User)
          .createQueryBuilder('user')
          .where('user.superAdmin = :superAdmin', {
            superAdmin: true,
          })
          .getOne()

        superAdmin.businessRoles = [roleAdmin]

        await transactionalEntityManager.getRepository(User).save(superAdmin)
      }

      const guessRole = await transactionalEntityManager
        .getRepository(Role)
        .createQueryBuilder('role')
        .where('role.name = :name', {
          name: 'guessRole',
        })
        .getOne()

      if (guessRole == null) {
        const newDate = new Date()
        const newRole = new Role()

        newRole.dateCreated = newDate
        newRole.dateModified = newDate
        newRole.name = 'guessRole'

        const guessPowerApp = await transactionalEntityManager
          .getRepository(PowersApp)
          .createQueryBuilder('powersApp')
          .where('powersApp.powerEnum = :powerEnum', {
            powerEnum: 2,
          })
          .getOne()

        newRole.powersApp = [guessPowerApp]

        await transactionalEntityManager.getRepository(Role).save(newRole)
      }
    })
  }

  async #generateRoles() {
    const getAllRoles = await db
      .getRepository(Role)
      .createQueryBuilder('role')
      .leftJoinAndSelect('role.powersApp', 'powersApp')
      .leftJoinAndSelect('powersApp.powersApi', 'powersApi')
      .getMany()

    getAllRoles.forEach((role) => {
      const powersApiForRole: Record<string, any> = {
        superAdminApi: role.superAdminApi,
      }
      role.powersApp.forEach((powerApp) => {
        powerApp.powersApi.forEach((powerApi) => {
          powersApiForRole[powerApi.name] = true
        })
      })

      this.#rolesApi[role.id] = powersApiForRole
    })
  }

  async checkRolesApi(powerName: string, userRole: string): Promise<boolean> {
    // if (this.#UpdateRolesTime + UpdateRolesTimeToNext < Date.now()) {
    //   await this.#generateRoles()
    //   this.#UpdateRolesTime = Date.now()
    // }
    const isSuperAdminRole =
      this.#rolesApi &&
      this.#rolesApi[userRole] &&
      this.#rolesApi[userRole]['superAdminApi']

    const isUserRole =
      this.#rolesApi &&
      this.#rolesApi[userRole] &&
      this.#rolesApi[userRole][powerName]
    if (!isSuperAdminRole && !isUserRole) {
      await this.#generateRoles()
    }

    return (
      (this.#rolesApi &&
        this.#rolesApi[userRole] &&
        this.#rolesApi[userRole]['superAdminApi']) ||
      (this.#rolesApi &&
        this.#rolesApi[userRole] &&
        this.#rolesApi[userRole][powerName]) ||
      false
    )
  }
}

export default new powersRoles()
