import { Express, Request, Response } from 'express'
import basicAuth from 'express-basic-auth'
import jetpack from 'fs-jetpack'
import path from 'path'
import swaggerJsdoc from 'swagger-jsdoc'
import swaggerUi from 'swagger-ui-express'
import { version } from '../../package.json'

let options: swaggerJsdoc.Options

options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'CallLab API',
      version: version,
    },
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
        },
      },
    },
    security: [
      {
        bearerAuth: [],
      },
    ],
    tags: [
      'tak',
      'authorization',
      'user',
      'business',
      'role',
      'powersApi',
      'powersApp',
      'floor',
      'room',
      'roomTypes',
      'license',
      'interface',
      'language',
      'userSettings',
      'statistics',
      'meeting',
      'messages',
      'item',
      'hrPoints',
      'email',
    ] as swaggerJsdoc.Tag['tak'],
  },
  apis: ['./src/routes/public/**/*.ts', './src/routes/private/**/*.ts'],
}

const swaggerDocs = async (app: Express, port: string) => {
  let swaggerSpec: object

  if (process.env.NODE_ENV === 'production') {
    const swaggerSpecPath = path.resolve(__dirname, './swagger.json')
    if (await jetpack.existsAsync(swaggerSpecPath)) {
      swaggerSpec = (await jetpack.readAsync(swaggerSpecPath, 'json')) || {}
    } else {
      console.log(`Swagger No loaded`)
    }
  } else {
    swaggerSpec = swaggerJsdoc(options)
  }
  app.use(
    '/docs',
    basicAuth({
      users: {
        [process.env.USER_NAME_DOCS_API]: process.env.USER_PASSWORD_DOCS_API,
      },
      challenge: true,
    }),
    swaggerUi.serve,
    swaggerUi.setup(swaggerSpec)
  )
  app.get('docs.json', (req: Request, res: Response) => {
    res.setHeader('Content-Type', 'application/json')
    res.send(swaggerSpec)
  })
  console.log(`Docs available  at http://localhost:${port}/docs`)
}

export default swaggerDocs
