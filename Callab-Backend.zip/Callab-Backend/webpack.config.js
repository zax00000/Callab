const webpack = require('webpack')
const path = require('path')
// const nodeExternals = require('webpack-node-externals');
const WebpackShellPluginNext = require('webpack-shell-plugin-next')
const { CleanWebpackPlugin } = require('clean-webpack-plugin')
const CopyWebpackPlugin = require('copy-webpack-plugin')
const TerserPlugin = require('terser-webpack-plugin')
const SwaggerJSDocWebpackPlugin = require('swagger-jsdoc-webpack-plugin')
const version = require('./package.json').version

const { NODE_ENV = 'production' } = process.env

module.exports = (env) => {
  const plugins = [
    new CleanWebpackPlugin({
      cleanOnceBeforeBuildPatterns: ['app.*.css', 'app.*.js', 'app.*.js.map'],
    }),
    new webpack.IgnorePlugin({ resourceRegExp: /^pg-native$/ }),
    new CopyWebpackPlugin({
      patterns: [
        './node_modules/swagger-ui-dist/swagger-ui.css',
        './node_modules/swagger-ui-dist/swagger-ui-bundle.js',
        './node_modules/swagger-ui-dist/swagger-ui-standalone-preset.js',
        './node_modules/swagger-ui-dist/favicon-16x16.png',
        './node_modules/swagger-ui-dist/favicon-32x32.png',
      ],
    }),
    new WebpackShellPluginNext({
      onBuildEnd: {
        scripts: NODE_ENV === 'development' ? ['yarn run dev'] : null,
        blocking: false,
        parallel: true,
      },
    }),
    new SwaggerJSDocWebpackPlugin({
      definition: {
        openapi: '3.0.0',
        info: {
          title: 'CallLab API',
          version: version,
        },
        components: {
          securitySchemes: {
            bearerAuth: {
              type: 'http',
              scheme: 'bearer',
              bearerFormat: 'JWT',
            },
          },
        },
        security: [
          {
            bearerAuth: [],
          },
        ],
        tags: [
          'tak',
          'authorization',
          'user',
          'business',
          'role',
          'powersApi',
          'powersApp',
          'floor',
          'room',
          'roomTypes',
          'license',
          'interface',
          'language',
          'userSettings',
          'statistics',
          'item',
          'hrPoints',
          'email',
        ],
      },
      apis: ['./src/routes/public/**/*.ts', './src/routes/private/**/*.ts'],
    }),
    // new webpack.DefinePlugin({ 'global.GENTLY': false }),
  ]

  // if (NODE_ENV === 'production') plugins.push(new CleanWebpackPlugin());

  return {
    entry: './src/index.ts',
    target: 'node',
    mode: NODE_ENV,
    output: {
      path: path.resolve(__dirname, 'build'),
      filename: 'index.js',
    },
    resolve: {
      extensions: ['.js', '.ts'],
    },
    module: {
      rules: [
        {
          test: /\.ts$/,
          loader: 'ts-loader',
          exclude: /node_modules/,
          options: {
            configFile: 'tsconfig.json',
          },
        },
      ],
    },
    optimization: {
      minimize: NODE_ENV === 'production',
      // minimize: false,
      minimizer: [
        new TerserPlugin({
          parallel: true,
          terserOptions: {
            keep_classnames: true,
          },
        }),
      ],
    },
    externals: { api: 'api' },
    devtool: NODE_ENV === 'development' ? 'inline-source-map' : 'source-map',
    watch: NODE_ENV === 'development',
    plugins,
    node: {
      __dirname: false,
      __filename: false,
    },
  }
}
